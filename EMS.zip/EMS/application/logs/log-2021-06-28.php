<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-28 17:39:19 --> Severity: error --> Exception: syntax error, unexpected '$response' (T_VARIABLE) D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 29

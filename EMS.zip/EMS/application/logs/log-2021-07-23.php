<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-23 16:27:37 --> Could not find the language line "update_batch() called with no data"
ERROR - 2021-07-23 16:29:30 --> Could not find the language line "update_batch() called with no data"
ERROR - 2021-07-23 17:16:09 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\selectexamView.php 50
ERROR - 2021-07-23 17:54:31 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-23 17:55:18 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\selectexamView.php 44
ERROR - 2021-07-23 17:55:19 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\selectexamView.php 44
ERROR - 2021-07-23 17:55:51 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-23 17:55:52 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-23 17:56:26 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-23 17:56:27 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-23 17:57:17 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-23 17:57:46 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-23 17:58:08 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-23 17:58:37 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-23 17:58:38 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-23 17:58:38 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-23 17:58:53 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\EMS\application\views\selectexamView.php 42
ERROR - 2021-07-23 17:59:16 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING) C:\xampp\htdocs\EMS\application\views\selectexamView.php 42
ERROR - 2021-07-23 17:59:38 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING) C:\xampp\htdocs\EMS\application\views\selectexamView.php 42
ERROR - 2021-07-23 17:59:38 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING) C:\xampp\htdocs\EMS\application\views\selectexamView.php 42
ERROR - 2021-07-23 18:00:43 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING) C:\xampp\htdocs\EMS\application\views\selectexamView.php 42
ERROR - 2021-07-23 18:00:44 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING) C:\xampp\htdocs\EMS\application\views\selectexamView.php 42
ERROR - 2021-07-23 18:00:51 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING) C:\xampp\htdocs\EMS\application\views\selectexamView.php 42
ERROR - 2021-07-23 18:00:52 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING) C:\xampp\htdocs\EMS\application\views\selectexamView.php 42
ERROR - 2021-07-23 18:01:14 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING) C:\xampp\htdocs\EMS\application\views\selectexamView.php 42
ERROR - 2021-07-23 18:02:06 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING) C:\xampp\htdocs\EMS\application\views\selectexamView.php 42
ERROR - 2021-07-23 18:02:07 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING) C:\xampp\htdocs\EMS\application\views\selectexamView.php 42
ERROR - 2021-07-23 18:02:08 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING) C:\xampp\htdocs\EMS\application\views\selectexamView.php 42
ERROR - 2021-07-23 18:02:08 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING) C:\xampp\htdocs\EMS\application\views\selectexamView.php 42
ERROR - 2021-07-23 18:02:08 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING) C:\xampp\htdocs\EMS\application\views\selectexamView.php 42
ERROR - 2021-07-23 18:04:31 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-23 18:05:44 --> Severity: error --> Exception: syntax error, unexpected '{' C:\xampp\htdocs\EMS\application\views\selectexamView.php 41
ERROR - 2021-07-23 18:05:46 --> Severity: error --> Exception: syntax error, unexpected '{' C:\xampp\htdocs\EMS\application\views\selectexamView.php 41
ERROR - 2021-07-23 18:46:57 --> 404 Page Not Found: Exam_Manage_Controller/Exam_Manage_Controller
ERROR - 2021-07-23 18:47:42 --> 404 Page Not Found: Exam_Manage_Controller/Exam_Manage_Controller
ERROR - 2021-07-23 18:47:57 --> 404 Page Not Found: Exam_Manage_Controller/Exam_Manage_Controller
ERROR - 2021-07-23 19:29:36 --> Query error: Duplicate entry '12-9' for key 'ST_EX_CO_ID' - Invalid query: INSERT INTO `student_exam_module` (`Is_assign`, `Is_attend`, `Is_repeat`, `Module_ID`, `ST_EX_CO_ID`) VALUES ('1','0','0','9','12')
ERROR - 2021-07-23 19:30:05 --> Query error: Duplicate entry '12-9' for key 'ST_EX_CO_ID' - Invalid query: INSERT INTO `student_exam_module` (`Is_assign`, `Is_attend`, `Is_repeat`, `Module_ID`, `ST_EX_CO_ID`) VALUES ('1','0','0','9','12')

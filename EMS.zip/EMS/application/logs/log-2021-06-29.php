<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-29 06:37:09 --> Severity: Notice --> Undefined variable: Course_ID D:\xampp\htdocs\EMS\application\views\add_studentView.php 43
ERROR - 2021-06-29 06:37:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\add_studentView.php 43
ERROR - 2021-06-29 06:37:38 --> Severity: Notice --> Undefined variable: Course_ID D:\xampp\htdocs\EMS\application\views\add_studentView.php 43
ERROR - 2021-06-29 06:37:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\add_studentView.php 43
ERROR - 2021-06-29 06:38:41 --> Severity: Notice --> Undefined variable: Course_ID D:\xampp\htdocs\EMS\application\views\add_studentView.php 43
ERROR - 2021-06-29 06:38:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\add_studentView.php 43
ERROR - 2021-06-29 06:39:50 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:50 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:50 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:50 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:50 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:50 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:50 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:50 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:50 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:50 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:50 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:50 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:50 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:50 --> Severity: Notice --> Undefined variable: TC_ID D:\xampp\htdocs\EMS\application\views\add_studentView.php 55
ERROR - 2021-06-29 06:39:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\add_studentView.php 55
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined variable: TC_ID D:\xampp\htdocs\EMS\application\views\add_studentView.php 55
ERROR - 2021-06-29 06:39:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\add_studentView.php 55
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined property: stdClass::$Course_Name D:\xampp\htdocs\EMS\application\views\add_studentView.php 44
ERROR - 2021-06-29 06:39:51 --> Severity: Notice --> Undefined variable: TC_ID D:\xampp\htdocs\EMS\application\views\add_studentView.php 55
ERROR - 2021-06-29 06:39:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\add_studentView.php 55
ERROR - 2021-06-29 07:49:07 --> Severity: Notice --> Undefined variable: Course_ID D:\xampp\htdocs\EMS\application\views\add_studentView.php 43
ERROR - 2021-06-29 07:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\add_studentView.php 43
ERROR - 2021-06-29 07:50:39 --> Severity: Notice --> Undefined variable: studentdata D:\xampp\htdocs\EMS\application\models\RegisterStudentModel.php 41
ERROR - 2021-06-29 07:51:43 --> Query error: Unknown column 'STD_ID' in 'field list' - Invalid query: INSERT INTO `course` (`STD_ID`, `Course_ID`) VALUES (NULL, 'K72T001')
ERROR - 2021-06-29 07:52:58 --> Query error: Column 'STD_ID' cannot be null - Invalid query: INSERT INTO `student_course` (`STD_ID`, `Course_ID`) VALUES (NULL, 'K72T001')
ERROR - 2021-06-29 07:56:29 --> Severity: error --> Exception: Function name must be a string D:\xampp\htdocs\EMS\application\models\RegisterStudentModel.php 35
ERROR - 2021-06-29 07:57:31 --> Severity: error --> Exception: Call to a member function result() on int D:\xampp\htdocs\EMS\application\models\RegisterStudentModel.php 35
ERROR - 2021-06-29 07:58:11 --> Query error: Column 'STD_ID' cannot be null - Invalid query: INSERT INTO `student_course` (`STD_ID`, `Course_ID`) VALUES (NULL, 'K72T001')
ERROR - 2021-06-29 07:59:32 --> Severity: Notice --> Undefined variable: insert_id D:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 40
ERROR - 2021-06-29 07:59:32 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\EMS\system\database\DB_driver.php 1471
ERROR - 2021-06-29 07:59:32 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `student_course` (`STD_ID`, `Course_ID`) VALUES (Array, 'K72T001')
ERROR - 2021-06-29 08:03:02 --> Query error: Column 'STD_ID' cannot be null - Invalid query: INSERT INTO `student_course` (`STD_ID`, `Course_ID`) VALUES (NULL, 'K72T001')
ERROR - 2021-06-29 09:49:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.Gender, student_registration.Contact_no, student_registration.Email, student...' at line 2 - Invalid query: SELECT student_registration.Std_NIC, student_registration.Name
         student_registration.Gender, student_registration.Contact_no, student_registration.Email, student_registration.TC_ID,
         student_course.Course_ID, student_registration.Active 
         FROM student_registration
         INNER JOIN student_course
         student_registration.STD_ID=student_course.STD_ID
ERROR - 2021-06-29 09:51:44 --> Query error: Not unique table/alias: 'student_registration' - Invalid query: SELECT student_registration.Std_NIC, student_registration.Name,
         student_registration.Gender, student_registration.Contact_no, student_registration.Email, student_registration.TC_ID,
         student_course.Course_ID, student_registration.Active 
         FROM student_registration
         INNER JOIN student_course
         student_registration.STD_ID=student_course.STD_ID
ERROR - 2021-06-29 09:54:18 --> Query error: Not unique table/alias: 'student_registration' - Invalid query: SELECT student_registration.Std_NIC, student_registration.Name,
         student_registration.Gender, student_registration.Contact_no, student_registration.Email, student_registration.TC_ID,
         student_course.Course_ID, student_registration.Active 
         FROM student_registration
         INNER JOIN student_course
         student_registration.STD_ID=student_course.STD_ID
ERROR - 2021-06-29 09:54:23 --> Query error: Not unique table/alias: 'student_registration' - Invalid query: SELECT student_registration.Std_NIC, student_registration.Name,
         student_registration.Gender, student_registration.Contact_no, student_registration.Email, student_registration.TC_ID,
         student_course.Course_ID, student_registration.Active 
         FROM student_registration
         INNER JOIN student_course
         student_registration.STD_ID=student_course.STD_ID
ERROR - 2021-06-29 09:57:12 --> Severity: Notice --> Undefined property: stdClass::$STD_ID D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-06-29 09:57:12 --> Severity: Notice --> Undefined property: stdClass::$STD_ID D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-06-29 09:57:12 --> Severity: Notice --> Undefined property: stdClass::$STD_ID D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-06-29 09:57:12 --> Severity: Notice --> Undefined property: stdClass::$STD_ID D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-06-29 11:31:55 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 44
ERROR - 2021-06-29 11:34:15 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 44
ERROR - 2021-06-29 11:34:16 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 44
ERROR - 2021-06-29 11:34:17 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 44
ERROR - 2021-06-29 11:34:17 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 44
ERROR - 2021-06-29 11:34:17 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 44
ERROR - 2021-06-29 11:34:17 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 44
ERROR - 2021-06-29 11:34:17 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 44
ERROR - 2021-06-29 11:34:18 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 44
ERROR - 2021-06-29 11:36:35 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 42
ERROR - 2021-06-29 11:36:36 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 42
ERROR - 2021-06-29 11:36:36 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 42
ERROR - 2021-06-29 11:36:36 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 42
ERROR - 2021-06-29 11:36:37 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 42
ERROR - 2021-06-29 11:38:06 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 42
ERROR - 2021-06-29 11:38:06 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 42
ERROR - 2021-06-29 11:38:07 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 42
ERROR - 2021-06-29 11:38:07 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 42
ERROR - 2021-06-29 11:38:07 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 42
ERROR - 2021-06-29 11:38:07 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 42
ERROR - 2021-06-29 11:38:07 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 42
ERROR - 2021-06-29 11:38:07 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 42
ERROR - 2021-06-29 11:38:08 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateStudentView.php 42
ERROR - 2021-06-29 11:40:44 --> Severity: Notice --> Undefined property: stdClass::$Course_ID D:\xampp\htdocs\EMS\application\views\updateStudentView.php 38
ERROR - 2021-06-29 11:40:44 --> Severity: Notice --> Undefined property: stdClass::$Course_ID D:\xampp\htdocs\EMS\application\views\updateStudentView.php 38
ERROR - 2021-06-29 11:43:24 --> Severity: Notice --> Undefined property: stdClass::$Course_ID D:\xampp\htdocs\EMS\application\views\updateStudentView.php 41
ERROR - 2021-06-29 11:50:11 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\updateStudentView.php 41
ERROR - 2021-06-29 11:50:11 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\updateStudentView.php 41
ERROR - 2021-06-29 11:50:11 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\updateStudentView.php 41
ERROR - 2021-06-29 11:50:11 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\updateStudentView.php 41
ERROR - 2021-06-29 11:50:11 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\updateStudentView.php 41
ERROR - 2021-06-29 11:50:11 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\updateStudentView.php 41
ERROR - 2021-06-29 11:50:11 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\updateStudentView.php 41
ERROR - 2021-06-29 11:50:11 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\updateStudentView.php 41
ERROR - 2021-06-29 11:50:11 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\updateStudentView.php 41
ERROR - 2021-06-29 11:50:11 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\updateStudentView.php 41
ERROR - 2021-06-29 11:50:11 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\updateStudentView.php 41
ERROR - 2021-06-29 11:50:11 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\updateStudentView.php 41
ERROR - 2021-06-29 11:50:11 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\updateStudentView.php 41
ERROR - 2021-06-29 12:00:59 --> Query error: Unknown column 'Course_code' in 'field list' - Invalid query: UPDATE student_course SET Course_code='F45T002' WHERE STD_ID='20'

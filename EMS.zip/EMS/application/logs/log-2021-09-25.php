<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-25 04:37:09 --> Severity: Notice --> Undefined index: Total D:\xampp\htdocs\EMS\application\views\dashboardView.php 173
ERROR - 2021-09-25 04:37:11 --> Severity: Notice --> Undefined index: Total D:\xampp\htdocs\EMS\application\views\dashboardView.php 173
ERROR - 2021-09-25 04:37:31 --> Severity: Notice --> Undefined index: Total D:\xampp\htdocs\EMS\application\views\dashboardView.php 173
ERROR - 2021-09-25 04:37:33 --> Severity: Notice --> Undefined index: Total D:\xampp\htdocs\EMS\application\views\dashboardView.php 173
ERROR - 2021-09-25 04:49:50 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-25 04:51:30 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-25 04:52:20 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-25 04:53:17 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-25 04:54:16 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-25 04:54:41 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-25 05:26:50 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-25 05:27:30 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-25 05:29:20 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-25 05:30:10 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-25 05:30:51 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-25 05:31:22 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-25 08:09:06 --> Severity: Notice --> Undefined index: User_ID  D:\xampp\htdocs\EMS\application\models\UserModel.php 80
ERROR - 2021-09-25 08:09:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Delete_Center'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Delete_Center'
ERROR - 2021-09-25 08:12:16 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-25 08:15:01 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-25 08:15:17 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-25 08:21:01 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-25 09:17:19 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\assignexamView.php 29
ERROR - 2021-09-25 09:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\assignexamView.php 29
ERROR - 2021-09-25 09:17:19 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\assignexamView.php 55
ERROR - 2021-09-25 09:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\assignexamView.php 55
ERROR - 2021-09-25 09:18:03 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\assignexamView.php 29
ERROR - 2021-09-25 09:18:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\assignexamView.php 29
ERROR - 2021-09-25 09:18:03 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\assignexamView.php 55
ERROR - 2021-09-25 09:18:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\assignexamView.php 55
ERROR - 2021-09-25 09:49:53 --> Query error: Duplicate entry '64-15' for key 'ST_EX_CO_ID' - Invalid query: INSERT INTO `student_exam_module` (`Is_assign`, `Is_attend`, `Is_repeat`, `Module_ID`, `ST_EX_CO_ID`) VALUES ('1','0','0','15','64')
ERROR - 2021-09-25 09:52:40 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 19
ERROR - 2021-09-25 09:52:40 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 21
ERROR - 2021-09-25 09:52:40 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 67
ERROR - 2021-09-25 09:52:40 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 67
ERROR - 2021-09-25 09:54:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 19
ERROR - 2021-09-25 09:54:51 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 21
ERROR - 2021-09-25 09:54:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 19
ERROR - 2021-09-25 09:54:55 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 21
ERROR - 2021-09-25 09:56:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 19
ERROR - 2021-09-25 09:56:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 21
ERROR - 2021-09-25 09:57:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 19
ERROR - 2021-09-25 09:57:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 21
ERROR - 2021-09-25 09:57:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 67
ERROR - 2021-09-25 09:57:17 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 67
ERROR - 2021-09-25 09:58:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 19
ERROR - 2021-09-25 09:58:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 21
ERROR - 2021-09-25 09:58:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 67
ERROR - 2021-09-25 09:58:14 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 67
ERROR - 2021-09-25 10:01:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 19
ERROR - 2021-09-25 10:01:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 21
ERROR - 2021-09-25 10:01:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 67
ERROR - 2021-09-25 10:01:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 67
ERROR - 2021-09-25 10:01:50 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 19
ERROR - 2021-09-25 10:01:50 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 21
ERROR - 2021-09-25 10:01:50 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 67
ERROR - 2021-09-25 10:01:50 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 67
ERROR - 2021-09-25 11:46:20 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-25 11:47:36 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-25 11:48:22 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-25 11:50:46 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-25 12:27:53 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\EMS\application\views\selectexamView.php 30
ERROR - 2021-09-25 12:27:53 --> Severity: Notice --> Trying to get property 'Address' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 30
ERROR - 2021-09-25 12:31:26 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 28
ERROR - 2021-09-25 12:31:26 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 28
ERROR - 2021-09-25 12:31:26 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 28
ERROR - 2021-09-25 12:32:01 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 29
ERROR - 2021-09-25 12:32:01 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 29
ERROR - 2021-09-25 12:32:01 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 29
ERROR - 2021-09-25 12:32:22 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 29
ERROR - 2021-09-25 12:32:22 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 29
ERROR - 2021-09-25 12:32:22 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 29
ERROR - 2021-09-25 12:32:57 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\xampp\htdocs\EMS\application\views\selectexamView.php 26
ERROR - 2021-09-25 12:34:35 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 29
ERROR - 2021-09-25 12:34:35 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 29
ERROR - 2021-09-25 12:34:35 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 29
ERROR - 2021-09-25 12:38:30 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 31
ERROR - 2021-09-25 12:38:30 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 31
ERROR - 2021-09-25 12:38:30 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 31
ERROR - 2021-09-25 12:41:11 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 31
ERROR - 2021-09-25 12:41:11 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 31
ERROR - 2021-09-25 12:41:11 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 31
ERROR - 2021-09-25 12:41:41 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 30
ERROR - 2021-09-25 12:41:41 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 30
ERROR - 2021-09-25 12:41:41 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\selectexamView.php 30
ERROR - 2021-09-25 12:43:53 --> Severity: Notice --> Undefined variable: training D:\xampp\htdocs\EMS\application\views\selectexamView.php 28
ERROR - 2021-09-25 12:47:04 --> Severity: Notice --> Undefined variable: training D:\xampp\htdocs\EMS\application\views\selectexamView.php 28
ERROR - 2021-09-25 13:08:14 --> Severity: Notice --> Undefined index: TC_Name D:\xampp\htdocs\EMS\application\views\examResultCourseModuleCenterPDF.php 33
ERROR - 2021-09-25 13:08:14 --> Severity: Notice --> Undefined index: Module D:\xampp\htdocs\EMS\application\views\examResultCourseModuleCenterPDF.php 35
ERROR - 2021-09-25 13:08:14 --> Severity: Notice --> Undefined index: Name D:\xampp\htdocs\EMS\application\views\examResultCourseModuleCenterPDF.php 43
ERROR - 2021-09-25 13:08:14 --> Severity: Notice --> Undefined index: Result D:\xampp\htdocs\EMS\application\views\examResultCourseModuleCenterPDF.php 43
ERROR - 2021-09-25 13:16:44 --> Severity: Notice --> Undefined variable: training D:\xampp\htdocs\EMS\application\views\selectexamView.php 28
ERROR - 2021-09-25 15:12:06 --> Severity: Notice --> Undefined variable: training D:\xampp\htdocs\EMS\application\views\selectexamView.php 28

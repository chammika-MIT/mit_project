<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-20 07:00:39 --> 404 Page Not Found: DdCourseModule_controller/add_CourseModule
ERROR - 2021-06-20 07:01:42 --> 404 Page Not Found: DdCourseModule_controller/add_CourseModule
ERROR - 2021-06-20 07:01:43 --> 404 Page Not Found: DdCourseModule_controller/add_CourseModule
ERROR - 2021-06-20 07:24:08 --> Severity: Notice --> Undefined property: AddCourseModule_controller::$View_institute_model D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 53
ERROR - 2021-06-20 07:24:08 --> Severity: error --> Exception: Call to a member function update_trainingcenter() on null D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 53
ERROR - 2021-06-20 07:25:13 --> Severity: Notice --> Undefined variable: Course_code D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 53
ERROR - 2021-06-20 07:25:13 --> Severity: Notice --> Undefined variable: Course_name D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 53
ERROR - 2021-06-20 07:25:13 --> Severity: Notice --> Undefined variable: Virsion D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 53
ERROR - 2021-06-20 07:25:13 --> Severity: Notice --> Undefined variable: Reg_No D:\xampp\htdocs\EMS\application\models\AddCourseModule_model.php 31
ERROR - 2021-06-20 07:25:13 --> Severity: Notice --> Undefined variable: CenterName D:\xampp\htdocs\EMS\application\models\AddCourseModule_model.php 31
ERROR - 2021-06-20 07:25:13 --> Severity: Notice --> Undefined variable: PermanentAddress D:\xampp\htdocs\EMS\application\models\AddCourseModule_model.php 31
ERROR - 2021-06-20 07:25:13 --> Severity: Notice --> Undefined variable: Email_address D:\xampp\htdocs\EMS\application\models\AddCourseModule_model.php 31
ERROR - 2021-06-20 07:25:13 --> Severity: Notice --> Undefined variable: ContactNo D:\xampp\htdocs\EMS\application\models\AddCourseModule_model.php 31
ERROR - 2021-06-20 07:25:13 --> Severity: Notice --> Undefined variable: TC_ID D:\xampp\htdocs\EMS\application\models\AddCourseModule_model.php 31
ERROR - 2021-06-20 07:25:13 --> Query error: Unknown column 'TC_ID' in 'where clause' - Invalid query: UPDATE course SET Reg_No='',Name='', Address='', Email='', ContactNo='' WHERE TC_ID=''
ERROR - 2021-06-20 07:25:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\EMS\system\core\Exceptions.php:271) D:\xampp\htdocs\EMS\system\core\Common.php 570
ERROR - 2021-06-20 07:26:05 --> Severity: Notice --> Undefined variable: Course_code D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 53
ERROR - 2021-06-20 07:26:05 --> Severity: Notice --> Undefined variable: Course_name D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 53
ERROR - 2021-06-20 07:26:05 --> Severity: Notice --> Undefined variable: Virsion D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 53
ERROR - 2021-06-20 07:26:05 --> Severity: error --> Exception: Too few arguments to function AddCourseModule_model::update_course(), 3 passed in D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php on line 53 and exactly 4 expected D:\xampp\htdocs\EMS\application\models\AddCourseModule_model.php 30
ERROR - 2021-06-20 07:27:59 --> Severity: Notice --> Undefined variable: Course_code D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 53
ERROR - 2021-06-20 07:27:59 --> Severity: Notice --> Undefined variable: Course_name D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 53
ERROR - 2021-06-20 07:27:59 --> Severity: Notice --> Undefined variable: Virsion D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 53
ERROR - 2021-06-20 07:27:59 --> Query error: Unknown column 'Virsion' in 'field list' - Invalid query: UPDATE course SET Course_code='',Course_name='', Virsion='' WHERE Course_ID='1'
ERROR - 2021-06-20 07:29:00 --> Severity: Notice --> Undefined variable: Course_name D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 53
ERROR - 2021-06-20 07:29:00 --> Query error: Unknown column 'Virsion' in 'field list' - Invalid query: UPDATE course SET Course_code='',Course_name='', Virsion='' WHERE Course_ID='1'
ERROR - 2021-06-20 07:29:37 --> Query error: Unknown column 'Virsion' in 'field list' - Invalid query: UPDATE course SET Course_code='',Course_name='', Virsion='' WHERE Course_ID='1'
ERROR - 2021-06-20 08:21:44 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\Module_view.php 19
ERROR - 2021-06-20 08:21:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\Module_view.php 19
ERROR - 2021-06-20 08:21:51 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\Module_view.php 19
ERROR - 2021-06-20 08:21:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\Module_view.php 19
ERROR - 2021-06-20 08:21:56 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\Module_view.php 19
ERROR - 2021-06-20 08:21:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\Module_view.php 19
ERROR - 2021-06-20 08:25:12 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\Module_view.php 19
ERROR - 2021-06-20 08:25:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\Module_view.php 19
ERROR - 2021-06-20 08:28:28 --> 404 Page Not Found: AddCourseModule_controller/add_Module
ERROR - 2021-06-20 08:28:30 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\Module_view.php 19
ERROR - 2021-06-20 08:28:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\Module_view.php 19
ERROR - 2021-06-20 08:34:06 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\Module_view.php 19
ERROR - 2021-06-20 08:34:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\Module_view.php 19
ERROR - 2021-06-20 08:34:12 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\Module_view.php 19
ERROR - 2021-06-20 08:34:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\Module_view.php 19
ERROR - 2021-06-20 08:34:16 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\Module_view.php 19
ERROR - 2021-06-20 08:34:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\Module_view.php 19
ERROR - 2021-06-20 08:40:22 --> Severity: error --> Exception: syntax error, unexpected 'return' (T_RETURN), expecting ')' D:\xampp\htdocs\EMS\application\models\AddCourseModule_model.php 42
ERROR - 2021-06-20 08:53:39 --> Severity: Notice --> Undefined variable: Course_ID D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 88
ERROR - 2021-06-20 08:57:19 --> Severity: Notice --> Undefined variable: Course_ID D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 88
ERROR - 2021-06-20 08:58:50 --> 404 Page Not Found: AddCourseModule_controller/addModule_view
ERROR - 2021-06-20 08:59:51 --> 404 Page Not Found: AddCourseModule_controller/addModule_view
ERROR - 2021-06-20 08:59:55 --> 404 Page Not Found: AddCourseModule_controller/%20add_module
ERROR - 2021-06-20 09:11:39 --> Query error: Unknown column 'Module_ID' in 'where clause' - Invalid query: SELECT * FROM course WHERE Module_ID='6'
ERROR - 2021-06-20 09:14:50 --> Query error: Unknown column 'Module_ID' in 'where clause' - Invalid query: SELECT * FROM course WHERE Module_ID='6'
ERROR - 2021-06-20 09:15:22 --> Query error: Unknown column 'Module_ID' in 'where clause' - Invalid query: SELECT * FROM course WHERE Module_ID='6'
ERROR - 2021-06-20 09:15:31 --> Query error: Unknown column 'Module_ID' in 'where clause' - Invalid query: SELECT * FROM course WHERE Module_ID='6'
ERROR - 2021-06-20 09:16:03 --> Query error: Unknown column 'Moudle_code' in 'field list' - Invalid query: UPDATE module SET Moudle_code='k72',Module_name='Databse II' WHERE Module_ID='6'
ERROR - 2021-06-20 09:17:17 --> Query error: Unknown column 'Moudle_code' in 'field list' - Invalid query: UPDATE module SET Moudle_code='k72',Module_name='Databse II' WHERE Module_ID='6'

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 30
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 30
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 30
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 30
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 48
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 64
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 48
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 64
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 48
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 64
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 48
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 64
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 48
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 64
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 48
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 64
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 48
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 64
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 48
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 64
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 48
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 64
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 48
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 64
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 48
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 64
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 48
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 64
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 48
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 64
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 48
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 64
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 48
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 64
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 48
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 64
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$Module_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:18:47 --> Severity: Notice --> Undefined property: stdClass::$ST_EX_MO_ID C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 65
ERROR - 2021-07-25 08:34:34 --> Severity: Notice --> Undefined property: stdClass::$Name C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 50
ERROR - 2021-07-25 09:04:57 --> Severity: error --> Exception: syntax error, unexpected ')', expecting variable (T_VARIABLE) C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 165
ERROR - 2021-07-25 09:05:17 --> Severity: error --> Exception: syntax error, unexpected ')', expecting variable (T_VARIABLE) C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 165
ERROR - 2021-07-25 09:09:45 --> Severity: Notice --> Undefined variable: trainingcourse C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 165
ERROR - 2021-07-25 09:09:45 --> Severity: Notice --> Undefined variable: trainingcenter C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 166
ERROR - 2021-07-25 09:09:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND student_registration.TC_ID=  AND student_exam_course.Exam_ID=1
        O...' at line 6 - Invalid query: SELECT student_registration.STD_ID,student_registration.Name AS `student_name` , examination_center.EXC_ID,examination_center.Name, 
        student_exam_course.ST_EX_CO_ID, student_exam_course.Exam_ID, student_exam_course.EXC_ID  FROM student_registration INNER JOIN
        training_center ON student_registration.TC_ID= training_center.TC_ID INNER JOIN examination_center 
        ON training_center.District_ID= examination_center.District_ID INNER JOIN 
        student_exam_course ON student_registration.STD_ID=student_exam_course.STD_ID  WHERE student_exam_course.Course_ID= 
        AND student_registration.TC_ID=  AND student_exam_course.Exam_ID=1
        ORDER BY student_registration.STD_ID
ERROR - 2021-07-25 09:10:48 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_Name C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 32
ERROR - 2021-07-25 09:10:48 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_Name C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 32
ERROR - 2021-07-25 09:10:48 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 44
ERROR - 2021-07-25 09:10:48 --> Severity: Notice --> Undefined property: stdClass::$Student_Name C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 50
ERROR - 2021-07-25 09:10:48 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 44
ERROR - 2021-07-25 09:10:48 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 44
ERROR - 2021-07-25 09:10:48 --> Severity: Notice --> Undefined property: stdClass::$Student_Name C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 58
ERROR - 2021-07-25 09:10:48 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 44
ERROR - 2021-07-25 09:11:48 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_Name C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 32
ERROR - 2021-07-25 09:11:48 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_Name C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 32
ERROR - 2021-07-25 09:11:48 --> Severity: Notice --> Undefined property: stdClass::$Student_Name C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 50
ERROR - 2021-07-25 09:11:48 --> Severity: Notice --> Undefined property: stdClass::$Student_Name C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 58
ERROR - 2021-07-25 09:12:31 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_Name C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 32
ERROR - 2021-07-25 09:12:31 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_Name C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 32
ERROR - 2021-07-25 09:12:31 --> Severity: Notice --> Undefined property: stdClass::$Student_Name C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 50
ERROR - 2021-07-25 09:12:31 --> Severity: Notice --> Undefined property: stdClass::$Student_Name C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 58
ERROR - 2021-07-25 09:18:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 76
ERROR - 2021-07-25 09:18:31 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 77
ERROR - 2021-07-25 09:18:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 76
ERROR - 2021-07-25 09:18:31 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 77
ERROR - 2021-07-25 10:33:02 --> Severity: Notice --> Undefined variable: studentModuleDelete C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 218
ERROR - 2021-07-25 10:33:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 218
ERROR - 2021-07-25 10:33:20 --> Severity: Notice --> Undefined variable: studentModuleDelete C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 218
ERROR - 2021-07-25 10:33:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 218
ERROR - 2021-07-25 10:33:44 --> Severity: Notice --> Undefined variable: studentModuleDelete C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 218
ERROR - 2021-07-25 10:33:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 218
ERROR - 2021-07-25 10:45:57 --> Could not find the language line "update_batch() called with no data"
ERROR - 2021-07-25 10:49:13 --> Severity: Notice --> Undefined variable: respone C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 192
ERROR - 2021-07-25 11:00:55 --> Severity: Notice --> Undefined variable: studentExamCenterDelete C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 201
ERROR - 2021-07-25 11:00:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 201
ERROR - 2021-07-25 11:00:55 --> Severity: Notice --> Undefined variable: studentExamCenterDelete C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 202
ERROR - 2021-07-25 11:00:55 --> Severity: Notice --> Undefined variable: studentExamCenterDelete C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 201
ERROR - 2021-07-25 11:00:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 201
ERROR - 2021-07-25 11:00:55 --> Severity: Notice --> Undefined variable: studentExamCenterDelete C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 202
ERROR - 2021-07-25 12:10:06 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 9
ERROR - 2021-07-25 12:12:10 --> Severity: error --> Exception: Call to undefined function set_breadcrumb() C:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 5

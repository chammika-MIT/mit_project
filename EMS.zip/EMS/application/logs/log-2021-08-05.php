<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-05 06:56:38 --> 404 Page Not Found: User_Controller/add_CourseModule
ERROR - 2021-08-05 06:58:01 --> 404 Page Not Found: User_Controller/add_CourseModule
ERROR - 2021-08-05 06:58:04 --> 404 Page Not Found: User_Controller/add_CourseModule
ERROR - 2021-08-05 06:58:09 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-05 06:59:02 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-05 06:59:03 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-05 07:00:11 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-05 07:00:12 --> 404 Page Not Found: User_Controller/add_User

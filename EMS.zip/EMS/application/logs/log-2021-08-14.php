<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-14 07:28:11 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 171
ERROR - 2021-08-14 07:28:27 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 171
ERROR - 2021-08-14 07:29:42 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 171
ERROR - 2021-08-14 07:30:22 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 186
ERROR - 2021-08-14 07:30:43 --> Severity: Notice --> Undefined variable: studentExamCourseId C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 330
ERROR - 2021-08-14 07:30:43 --> Severity: Notice --> Undefined variable: studentExamCourseId C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 330
ERROR - 2021-08-14 07:44:42 --> Severity: error --> Exception: Call to undefined method CI_Loader::SetFillColor() C:\xampp\htdocs\EMS\application\views\pdfreport.php 20
ERROR - 2021-08-14 07:45:06 --> Severity: error --> Exception: Call to undefined method CI_Loader::SetTextColor() C:\xampp\htdocs\EMS\application\views\pdfreport.php 21
ERROR - 2021-08-14 07:45:13 --> Severity: error --> Exception: Call to undefined method CI_Loader::SetDrawColor() C:\xampp\htdocs\EMS\application\views\pdfreport.php 22
ERROR - 2021-08-14 07:52:10 --> Severity: error --> Exception: syntax error, unexpected '.1' (T_DNUMBER), expecting ')' C:\xampp\htdocs\EMS\application\views\pdfreport.php 27
ERROR - 2021-08-14 07:52:33 --> Severity: error --> Exception: syntax error, unexpected '.1' (T_DNUMBER), expecting ')' C:\xampp\htdocs\EMS\application\views\pdfreport.php 27
ERROR - 2021-08-14 07:52:34 --> Severity: error --> Exception: syntax error, unexpected '.1' (T_DNUMBER), expecting ')' C:\xampp\htdocs\EMS\application\views\pdfreport.php 27
ERROR - 2021-08-14 07:53:20 --> Severity: error --> Exception: Call to undefined method CI_Loader::Ln() C:\xampp\htdocs\EMS\application\views\pdfreport.php 29
ERROR - 2021-08-14 11:38:31 --> Severity: Notice --> Undefined variable: pdf C:\xampp\htdocs\EMS\application\views\pdfreport.php 49
ERROR - 2021-08-14 11:38:31 --> Severity: error --> Exception: Call to a member function MultiCell() on null C:\xampp\htdocs\EMS\application\views\pdfreport.php 49
ERROR - 2021-08-14 12:17:53 --> Severity: Notice --> Undefined index: rows C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16980
ERROR - 2021-08-14 12:17:53 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16982
ERROR - 2021-08-14 12:17:53 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16562
ERROR - 2021-08-14 12:27:22 --> Severity: error --> Exception: syntax error, unexpected '<<' (T_SL) C:\xampp\htdocs\EMS\application\views\pdfreport.php 147
ERROR - 2021-08-14 12:28:27 --> Severity: error --> Exception: syntax error, unexpected '<<' (T_SL) C:\xampp\htdocs\EMS\application\views\pdfreport.php 147
ERROR - 2021-08-14 12:28:28 --> Severity: error --> Exception: syntax error, unexpected '<<' (T_SL) C:\xampp\htdocs\EMS\application\views\pdfreport.php 147
ERROR - 2021-08-14 12:29:00 --> Severity: error --> Exception: syntax error, unexpected '$obj_pdf' (T_VARIABLE) C:\xampp\htdocs\EMS\application\views\pdfreport.php 150

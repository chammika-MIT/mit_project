<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-08 05:20:12 --> 404 Page Not Found: Exam_Manage_Controller/add_student_attendance
ERROR - 2021-08-08 05:22:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND 
        student_registration.TC_ID =' at line 5 - Invalid query: SELECT CONCAT(student_exam_course.STD_ID,'-',student_exam_module.Module_ID,'-',student_exam_course.ST_EX_CO_ID,'-',student_exam_module.ST_EX_MO_ID)  
        as `Exam_Module_Ids` FROM `student_exam_course` INNER JOIN  `student_exam_module`  ON 
        student_exam_course.ST_EX_CO_ID=student_exam_module.ST_EX_CO_ID INNER JOIN student_registration ON
        student_exam_course.STD_ID = student_registration.STD_ID 
        WHERE student_exam_module.Is_assign=1 AND  student_exam_course.Course_ID= AND 
        student_registration.TC_ID =
ERROR - 2021-08-08 05:24:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND 
        student_registration.TC_ID =' at line 5 - Invalid query: SELECT CONCAT(student_exam_course.STD_ID,'-',student_exam_module.Module_ID,'-',student_exam_course.ST_EX_CO_ID,'-',student_exam_module.ST_EX_MO_ID)  
        as `Exam_Module_Ids` FROM `student_exam_course` INNER JOIN  `student_exam_module`  ON 
        student_exam_course.ST_EX_CO_ID=student_exam_module.ST_EX_CO_ID INNER JOIN student_registration ON
        student_exam_course.STD_ID = student_registration.STD_ID 
        WHERE student_exam_module.Is_assign=1 AND  student_exam_course.Course_ID= AND 
        student_registration.TC_ID =
ERROR - 2021-08-08 05:29:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND 
        student_registration.TC_ID =' at line 5 - Invalid query: SELECT CONCAT(student_exam_course.STD_ID,'-',student_exam_module.Module_ID,'-',student_exam_course.ST_EX_CO_ID,'-',student_exam_module.ST_EX_MO_ID)  
        as `Exam_Module_Ids` FROM `student_exam_course` INNER JOIN  `student_exam_module`  ON 
        student_exam_course.ST_EX_CO_ID=student_exam_module.ST_EX_CO_ID INNER JOIN student_registration ON
        student_exam_course.STD_ID = student_registration.STD_ID 
        WHERE student_exam_module.Is_assign=1 AND  student_exam_course.Course_ID= AND 
        student_registration.TC_ID =
ERROR - 2021-08-08 06:13:20 --> Severity: Notice --> Undefined property: stdClass::$Is_attend C:\xampp\htdocs\EMS\application\views\attendanceView.php 65
ERROR - 2021-08-08 06:13:20 --> Severity: Notice --> Undefined property: stdClass::$Is_attend C:\xampp\htdocs\EMS\application\views\attendanceView.php 65
ERROR - 2021-08-08 06:13:20 --> Severity: Notice --> Undefined property: stdClass::$Is_attend C:\xampp\htdocs\EMS\application\views\attendanceView.php 65
ERROR - 2021-08-08 06:13:20 --> Severity: Notice --> Undefined property: stdClass::$Is_attend C:\xampp\htdocs\EMS\application\views\attendanceView.php 65
ERROR - 2021-08-08 06:13:20 --> Severity: Notice --> Undefined property: stdClass::$Is_attend C:\xampp\htdocs\EMS\application\views\attendanceView.php 65
ERROR - 2021-08-08 06:13:20 --> Severity: Notice --> Undefined property: stdClass::$Is_attend C:\xampp\htdocs\EMS\application\views\attendanceView.php 65
ERROR - 2021-08-08 06:13:20 --> Severity: Notice --> Undefined property: stdClass::$Is_attend C:\xampp\htdocs\EMS\application\views\attendanceView.php 65
ERROR - 2021-08-08 06:13:20 --> Severity: Notice --> Undefined property: stdClass::$Is_attend C:\xampp\htdocs\EMS\application\views\attendanceView.php 65
ERROR - 2021-08-08 06:13:20 --> Severity: Notice --> Undefined property: stdClass::$Is_attend C:\xampp\htdocs\EMS\application\views\attendanceView.php 65
ERROR - 2021-08-08 06:13:20 --> Severity: Notice --> Undefined property: stdClass::$Is_attend C:\xampp\htdocs\EMS\application\views\attendanceView.php 65
ERROR - 2021-08-08 06:13:20 --> Severity: Notice --> Undefined property: stdClass::$Is_attend C:\xampp\htdocs\EMS\application\views\attendanceView.php 65
ERROR - 2021-08-08 07:26:07 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\EMS\application\views\layouts\side_menu.php 47
ERROR - 2021-08-08 07:26:11 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\EMS\application\views\layouts\side_menu.php 47
ERROR - 2021-08-08 07:26:15 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\EMS\application\views\layouts\side_menu.php 47
ERROR - 2021-08-08 07:28:11 --> Severity: error --> Exception: C:\xampp\htdocs\EMS\application\models/ResultModel.php exists, but doesn't declare class ResultModel C:\xampp\htdocs\EMS\system\core\Loader.php 340
ERROR - 2021-08-08 07:29:23 --> Severity: error --> Exception: Too few arguments to function Result_Controller::result_view(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 10
ERROR - 2021-08-08 07:29:48 --> Severity: Notice --> Undefined property: Result_Controller::$Exam_manage_Model C:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 17
ERROR - 2021-08-08 07:29:48 --> Severity: error --> Exception: Call to a member function displaytrainingcenter() on null C:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 17
ERROR - 2021-08-08 07:30:24 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 20
ERROR - 2021-08-08 07:43:16 --> 404 Page Not Found: Result_Controller/result_view
ERROR - 2021-08-08 07:43:23 --> 404 Page Not Found: Result_Controller/result_view
ERROR - 2021-08-08 07:57:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\EMS\application\views\selectResultCenter.php 19
ERROR - 2021-08-08 07:57:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\selectResultCenter.php 19
ERROR - 2021-08-08 08:03:19 --> Severity: Compile Error --> Cannot redeclare Exam_manage_Model::displaytrainingmodule() C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-08-08 08:49:48 --> 404 Page Not Found: Result_Controller/add_student_attendance
ERROR - 2021-08-08 08:50:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\EMS\application\views\resultView.php 22
ERROR - 2021-08-08 08:50:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\resultView.php 22
ERROR - 2021-08-08 08:51:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\EMS\application\views\resultView.php 22
ERROR - 2021-08-08 08:51:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\resultView.php 22
ERROR - 2021-08-08 08:52:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\EMS\application\views\resultView.php 22
ERROR - 2021-08-08 08:52:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\resultView.php 22
ERROR - 2021-08-08 08:59:50 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 08:59:50 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 9
ERROR - 2021-08-08 08:59:50 --> Severity: Notice --> Undefined variable: training_center C:\xampp\htdocs\EMS\application\views\addResultView.php 9
ERROR - 2021-08-08 09:06:36 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:07:53 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:11:15 --> Severity: Notice --> Undefined variable: checked C:\xampp\htdocs\EMS\application\views\addResultView.php 64
ERROR - 2021-08-08 09:12:14 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:12:59 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:13:12 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:14:09 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:14:31 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:15:23 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:17:33 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:18:51 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:19:28 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:20:06 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:21:36 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:21:51 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:22:29 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:23:34 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:24:07 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:24:58 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:25:06 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:26:10 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:28:09 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:28:26 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:28:38 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:28:58 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:30:23 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:30:44 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:31:47 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:32:02 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:32:16 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:32:35 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:32:44 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 09:33:08 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 11:22:29 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 11:23:14 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 11:29:47 --> Severity: error --> Exception: Too few arguments to function ResultModel::displayexamresultmodule(), 2 passed in C:\xampp\htdocs\EMS\application\controllers\Result_Controller.php on line 49 and exactly 3 expected C:\xampp\htdocs\EMS\application\models\ResultModel.php 4
ERROR - 2021-08-08 11:39:49 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\EMS\application\models\ResultModel.php 22
ERROR - 2021-08-08 11:39:49 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\EMS\application\models\ResultModel.php 22
ERROR - 2021-08-08 11:40:02 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 11:40:18 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 11:45:26 --> Severity: error --> Exception: syntax error, unexpected '?>', expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 76
ERROR - 2021-08-08 11:46:13 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 11:46:20 --> 404 Page Not Found: Exam_Manage_Controller/update_student_result
ERROR - 2021-08-08 11:46:58 --> 404 Page Not Found: Exam_Manage_Controller/update_student_result
ERROR - 2021-08-08 11:47:02 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 12:29:50 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\EMS\application\models\ResultModel.php 31
ERROR - 2021-08-08 12:30:24 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 12:31:33 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 12:33:36 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 12:34:00 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 12:34:49 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 12:38:20 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 12:39:53 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 12:40:02 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 12:40:11 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 12:41:30 --> Severity: error --> Exception: Call to undefined method Exam_manage_Model::insert_student_result() C:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 65
ERROR - 2021-08-08 12:42:09 --> Query error: Unknown column 'Proper' in 'where clause' - Invalid query: SELECT * FROM result_type WHERE Result_type=`Proper`
ERROR - 2021-08-08 12:43:04 --> Severity: error --> Exception: syntax error, unexpected 'Proper' (T_STRING), expecting ')' C:\xampp\htdocs\EMS\application\models\ResultModel.php 38
ERROR - 2021-08-08 12:43:15 --> Severity: error --> Exception: Call to undefined method Exam_manage_Model::getStudentExamResultAssign() C:\xampp\htdocs\EMS\application\models\ResultModel.php 48
ERROR - 2021-08-08 12:53:02 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `result` (`Marks`, `RE_TY_ID`, `ST_EX_MO_ID`) VALUES ('12','1','12'), ('','1','28'), ('','1','29')
ERROR - 2021-08-08 12:57:51 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 13:04:40 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 13:05:08 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 13:05:39 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 13:07:20 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 13:10:07 --> Severity: Warning --> Use of undefined constant studentExamResultUpdate - assumed 'studentExamResultUpdate' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\EMS\application\models\ResultModel.php 83
ERROR - 2021-08-08 13:13:55 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-08 13:14:11 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7

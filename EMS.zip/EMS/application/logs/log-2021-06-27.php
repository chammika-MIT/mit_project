<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-27 20:15:34 --> Query error: Unknown column 'Name' in 'field list' - Invalid query: INSERT INTO `course` (`Name`, `Address`, `Capacity`) VALUES ('D S Senanayake College', 'Ampara', '900')
ERROR - 2021-06-27 20:39:00 --> Query error: Unknown column 'Course_ID' in 'where clause' - Invalid query: SELECT * FROM examination_center WHERE Course_ID='1'
ERROR - 2021-06-27 20:40:46 --> Query error: Unknown column 'Course_ID' in 'where clause' - Invalid query: SELECT * FROM examination_center WHERE Course_ID='1'
ERROR - 2021-06-27 20:41:20 --> Severity: Notice --> Undefined property: stdClass::$CName D:\xampp\htdocs\EMS\application\views\updateExamCenterView.php 13
ERROR - 2021-06-27 20:42:12 --> Severity: Notice --> Undefined property: Exam_Center_Controller::$AddCourseModule_model D:\xampp\htdocs\EMS\application\controllers\Exam_Center_Controller.php 52
ERROR - 2021-06-27 20:42:12 --> Severity: error --> Exception: Call to a member function update_course() on null D:\xampp\htdocs\EMS\application\controllers\Exam_Center_Controller.php 52

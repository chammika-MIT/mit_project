<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-21 09:59:47 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `course` (`Course_code`, `Course_name`, `Version`) VALUES ('G50', 'Automobile', '3')
ERROR - 2021-06-21 10:00:57 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `course` (`Course_code`, `Course_name`, `Version`) VALUES ('K52', 'Beauty', '1')
ERROR - 2021-06-21 10:08:57 --> Severity: error --> Exception: Too few arguments to function AddCourseModule_model::displaymodule(), 0 passed in D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php on line 61 and exactly 1 expected D:\xampp\htdocs\EMS\application\models\AddCourseModule_model.php 45
ERROR - 2021-06-21 10:09:02 --> Severity: error --> Exception: Too few arguments to function AddCourseModule_model::displaymodule(), 0 passed in D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php on line 61 and exactly 1 expected D:\xampp\htdocs\EMS\application\models\AddCourseModule_model.php 45
ERROR - 2021-06-21 10:10:31 --> Severity: Notice --> Undefined variable: Course_ID D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 61
ERROR - 2021-06-21 10:20:53 --> Severity: error --> Exception: Too few arguments to function AddCourseModule_controller::moduleView(), 0 passed in D:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 60
ERROR - 2021-06-21 10:21:04 --> Severity: error --> Exception: Too few arguments to function AddCourseModule_controller::moduleView(), 0 passed in D:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 60
ERROR - 2021-06-21 10:22:12 --> Severity: error --> Exception: Too few arguments to function AddCourseModule_controller::moduleView(), 0 passed in D:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 60
ERROR - 2021-06-21 10:25:30 --> Severity: error --> Exception: Too few arguments to function AddCourseModule_controller::moduleView(), 0 passed in D:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 60
ERROR - 2021-06-21 10:36:18 --> Severity: error --> Exception: Too few arguments to function AddCourseModule_model::displaymodule(), 0 passed in D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php on line 61 and exactly 1 expected D:\xampp\htdocs\EMS\application\models\AddCourseModule_model.php 46
ERROR - 2021-06-21 10:56:20 --> Severity: Notice --> Undefined variable: groups D:\xampp\htdocs\EMS\application\views\addModule_view.php 16
ERROR - 2021-06-21 10:56:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addModule_view.php 16
ERROR - 2021-06-21 11:03:49 --> Severity: Notice --> Undefined variable: category D:\xampp\htdocs\EMS\application\views\addModule_view.php 15
ERROR - 2021-06-21 11:03:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addModule_view.php 15
ERROR - 2021-06-21 11:11:35 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 68
ERROR - 2021-06-21 11:13:47 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\addModule_view.php 15
ERROR - 2021-06-21 11:13:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addModule_view.php 15
ERROR - 2021-06-21 11:20:20 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\addModule_view.php 15
ERROR - 2021-06-21 11:20:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addModule_view.php 15
ERROR - 2021-06-21 11:21:40 --> Severity: Compile Error --> Cannot use temporary expression in write context D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 74

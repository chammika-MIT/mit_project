<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-12 17:52:13 --> Severity: Notice --> Undefined property: Add_institutes_Controller::$Add_institute_modell D:\xampp\htdocs\EMS\application\controllers\Add_institutes_Controller.php 23
ERROR - 2021-07-12 17:52:13 --> Severity: error --> Exception: Call to a member function get_district() on null D:\xampp\htdocs\EMS\application\controllers\Add_institutes_Controller.php 23
ERROR - 2021-07-12 18:00:02 --> Query error: Column 'District_ID' cannot be null - Invalid query: INSERT INTO `training_center` (`Reg_No`, `Name`, `Address`, `District_ID`, `Email`, `ContactNo`) VALUES ('P12/0135', 'IT Pro', 'Kurunegala', NULL, 'info@itpro.org', '0352260800')
ERROR - 2021-07-12 18:09:17 --> Severity: error --> Exception: syntax error, unexpected 'glyphicon' (T_STRING), expecting ')' D:\xampp\htdocs\EMS\application\views\institute_reg.php 31
ERROR - 2021-07-12 18:09:19 --> Severity: error --> Exception: syntax error, unexpected 'glyphicon' (T_STRING), expecting ')' D:\xampp\htdocs\EMS\application\views\institute_reg.php 31

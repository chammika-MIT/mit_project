<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-22 05:03:56 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 29
ERROR - 2021-09-22 05:03:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 29
ERROR - 2021-09-22 05:04:07 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-22 05:04:07 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-22 05:07:10 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 34
ERROR - 2021-09-22 05:07:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 34
ERROR - 2021-09-22 05:07:42 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 34
ERROR - 2021-09-22 05:07:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 34
ERROR - 2021-09-22 05:07:51 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 34
ERROR - 2021-09-22 05:07:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 34
ERROR - 2021-09-22 05:09:33 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 34
ERROR - 2021-09-22 05:09:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 34
ERROR - 2021-09-22 05:12:53 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 32
ERROR - 2021-09-22 05:12:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 32
ERROR - 2021-09-22 05:13:52 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 31
ERROR - 2021-09-22 05:13:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 31
ERROR - 2021-09-22 05:18:26 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 05:18:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 05:19:04 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 47
ERROR - 2021-09-22 05:19:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 47
ERROR - 2021-09-22 05:19:10 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 47
ERROR - 2021-09-22 05:19:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 47
ERROR - 2021-09-22 05:19:57 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 47
ERROR - 2021-09-22 05:19:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 47
ERROR - 2021-09-22 05:20:27 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 47
ERROR - 2021-09-22 05:20:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 47
ERROR - 2021-09-22 08:12:32 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 47
ERROR - 2021-09-22 08:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 47
ERROR - 2021-09-22 08:12:41 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 47
ERROR - 2021-09-22 08:12:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 47
ERROR - 2021-09-22 08:15:08 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 47
ERROR - 2021-09-22 08:15:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 47
ERROR - 2021-09-22 08:15:30 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 47
ERROR - 2021-09-22 08:15:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 47
ERROR - 2021-09-22 08:18:30 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:18:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:18:32 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 43
ERROR - 2021-09-22 08:18:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 43
ERROR - 2021-09-22 08:19:13 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:19:35 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:19:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:19:36 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 43
ERROR - 2021-09-22 08:19:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 43
ERROR - 2021-09-22 08:20:09 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:20:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:20:12 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 43
ERROR - 2021-09-22 08:20:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 43
ERROR - 2021-09-22 08:20:18 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:20:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:20:20 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:20:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:20:30 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:20:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:20:34 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:20:37 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:20:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:20:42 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 43
ERROR - 2021-09-22 08:20:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 43
ERROR - 2021-09-22 08:23:04 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 43
ERROR - 2021-09-22 08:23:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 43
ERROR - 2021-09-22 08:23:48 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:23:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:23:50 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 43
ERROR - 2021-09-22 08:23:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 43
ERROR - 2021-09-22 08:23:53 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:23:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:24:01 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:24:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 08:24:04 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 43
ERROR - 2021-09-22 08:24:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 43
ERROR - 2021-09-22 08:28:29 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 54
ERROR - 2021-09-22 08:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 54
ERROR - 2021-09-22 08:28:51 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 54
ERROR - 2021-09-22 08:28:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 54
ERROR - 2021-09-22 08:29:24 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 54
ERROR - 2021-09-22 08:29:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 54
ERROR - 2021-09-22 08:30:30 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 54
ERROR - 2021-09-22 08:30:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 54
ERROR - 2021-09-22 08:30:46 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 54
ERROR - 2021-09-22 08:30:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 54
ERROR - 2021-09-22 08:31:58 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 60
ERROR - 2021-09-22 08:31:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 60
ERROR - 2021-09-22 09:01:01 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 09:01:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 09:01:12 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 09:01:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 09:02:53 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 09:02:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 09:02:58 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 09:02:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 09:03:01 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 09:03:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 09:03:09 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 09:03:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 09:12:10 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 09:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 09:38:00 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 09:38:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 46
ERROR - 2021-09-22 09:45:35 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 60
ERROR - 2021-09-22 09:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 60
ERROR - 2021-09-22 09:45:53 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 60
ERROR - 2021-09-22 09:45:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 60
ERROR - 2021-09-22 09:47:37 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 60
ERROR - 2021-09-22 09:47:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 60
ERROR - 2021-09-22 09:56:28 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 66
ERROR - 2021-09-22 09:56:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 66
ERROR - 2021-09-22 09:57:09 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 65
ERROR - 2021-09-22 09:57:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 65
ERROR - 2021-09-22 09:59:58 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 09:59:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 10:02:09 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 82
ERROR - 2021-09-22 10:02:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 82
ERROR - 2021-09-22 10:02:42 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 82
ERROR - 2021-09-22 10:02:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 82
ERROR - 2021-09-22 10:02:54 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 82
ERROR - 2021-09-22 10:02:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 82
ERROR - 2021-09-22 10:03:52 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 82
ERROR - 2021-09-22 10:03:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 82
ERROR - 2021-09-22 10:11:35 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:11:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:11:38 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:11:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:17:11 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:17:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:17:19 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:17:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:37:01 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:37:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:37:18 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 17
ERROR - 2021-09-22 10:37:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 17
ERROR - 2021-09-22 10:38:15 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 193
ERROR - 2021-09-22 10:38:15 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 17
ERROR - 2021-09-22 10:38:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 17
ERROR - 2021-09-22 10:44:56 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:44:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:45:17 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:45:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:46:11 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:46:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:47:35 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:49:30 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:49:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 81
ERROR - 2021-09-22 10:51:36 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 10:51:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 10:53:00 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 10:53:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 10:53:02 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 10:53:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:04:59 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:04:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:08:37 --> Severity: Notice --> Trying to get property 'std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 21
ERROR - 2021-09-22 11:08:37 --> Severity: Notice --> Trying to get property 'std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 21
ERROR - 2021-09-22 11:08:37 --> Severity: Notice --> Trying to get property 'std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 21
ERROR - 2021-09-22 11:09:02 --> Severity: error --> Exception: syntax error, unexpected ''std_NIC'' (T_CONSTANT_ENCAPSED_STRING), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 21
ERROR - 2021-09-22 11:09:55 --> Severity: Notice --> Trying to get property 'std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 21
ERROR - 2021-09-22 11:09:55 --> Severity: Notice --> Trying to get property 'std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 21
ERROR - 2021-09-22 11:09:55 --> Severity: Notice --> Trying to get property 'std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 21
ERROR - 2021-09-22 11:11:30 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 21
ERROR - 2021-09-22 11:12:53 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 21
ERROR - 2021-09-22 11:12:53 --> Severity: Notice --> Trying to get property 'std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 21
ERROR - 2021-09-22 11:14:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 21
ERROR - 2021-09-22 11:15:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 21
ERROR - 2021-09-22 11:16:15 --> Severity: Notice --> Trying to get property 'std_nic' of non-object D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 21
ERROR - 2021-09-22 11:16:29 --> Severity: Notice --> Trying to get property 'std_nic' of non-object D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 21
ERROR - 2021-09-22 11:17:31 --> Severity: Warning --> Illegal string offset 'std_nic' D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 21
ERROR - 2021-09-22 11:17:31 --> Severity: Notice --> Trying to get property 'std_nic' of non-object D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 21
ERROR - 2021-09-22 11:35:07 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:35:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:36:36 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:36:36 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:36:58 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:36:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:37:34 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:37:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:37:47 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 11:37:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 11:37:47 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 11:37:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 11:38:31 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 11:38:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 11:38:31 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 11:38:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 11:39:28 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:39:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:39:43 --> Severity: Notice --> Undefined variable: std_NIC D:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 203
ERROR - 2021-09-22 11:39:43 --> Severity: Notice --> Undefined variable: std_Course D:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 203
ERROR - 2021-09-22 11:39:43 --> Severity: Notice --> Undefined variable: MC_Semester D:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 203
ERROR - 2021-09-22 11:39:43 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 11:39:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 11:39:43 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 11:39:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 11:40:24 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 11:40:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 11:40:24 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 11:40:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 11:40:29 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:40:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:40:31 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:40:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:42:20 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:42:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:42:37 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:42:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:46:51 --> Severity: Notice --> Undefined variable: std_NIC D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 16
ERROR - 2021-09-22 11:46:51 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:46:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:47:32 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:47:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:47:46 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:47:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:48:51 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:48:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:49:05 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:49:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:49:17 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 204
ERROR - 2021-09-22 11:49:17 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 11:49:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 11:49:17 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 11:49:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 11:49:34 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 11:49:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 11:49:34 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 11:49:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 11:53:13 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:53:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:53:24 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:53:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:57:52 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:57:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:58:11 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 11:58:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:08:34 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:08:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:12:37 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:12:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:12:37 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:12:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:13:08 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:13:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:13:26 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:13:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:13:26 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:13:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:15:44 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:15:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:16:01 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:16:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:16:01 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:16:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:16:48 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:16:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:17:05 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:17:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:17:05 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:17:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:17:23 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:17:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:17:38 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:17:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:17:38 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:17:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:19:16 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:19:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:19:16 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:19:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:19:17 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:19:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:19:17 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:19:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:19:19 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:19:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:19:19 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:19:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:19:23 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:19:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:19:34 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:19:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 18
ERROR - 2021-09-22 12:19:34 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:19:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addDisciplinaryView.php 44
ERROR - 2021-09-22 12:20:03 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:20:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:20:19 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:20:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:41:57 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:41:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 70
ERROR - 2021-09-22 12:42:50 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 67
ERROR - 2021-09-22 12:42:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 67
ERROR - 2021-09-22 12:45:13 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 68
ERROR - 2021-09-22 12:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 68
ERROR - 2021-09-22 13:08:09 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 133
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 133
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 133
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 133
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 133
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 133
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 133
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 133
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 133
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 133
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 133
ERROR - 2021-09-22 13:10:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 133
ERROR - 2021-09-22 13:10:31 --> Severity: Notice --> Undefined variable: rr D:\xampp\htdocs\EMS\application\views\examStudentCountModulePDF.php 27
ERROR - 2021-09-22 13:30:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Group BY student_exam_module.Module_ID) as `pass_table` INNER JOIN (SELECT mo...' at line 4 - Invalid query: SELECT `pass_table`.Module_ID, `pass_table`.Module_name as 'Module_name',total_student,pass_student,
        CAST(((pass_student/total_student)*100) AS DECIMAL(11,2))  as 'pass_rate'  FROM (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `pass_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID WHERE  result.Marks>=40 AND module.Course_ID=
        Group BY student_exam_module.Module_ID) as `pass_table` INNER JOIN (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `total_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID Group BY student_exam_module.Module_ID) AS `total_table` ON `pass_table`.Module_ID=`total_table`.Module_ID ORDER BY `pass_table`.Module_ID
        
ERROR - 2021-09-22 13:39:07 --> Severity: Notice --> Undefined variable: rr D:\xampp\htdocs\EMS\application\views\examStudentCountModulePDF.php 27
ERROR - 2021-09-22 15:01:56 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 15:01:56 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 15:01:56 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 15:01:56 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 15:01:56 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 15:01:56 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 15:01:56 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 15:01:56 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 15:01:56 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 15:01:56 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 15:01:56 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 15:01:56 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 15:54:02 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-22 15:54:02 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-22 15:54:16 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-22 15:54:16 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-22 15:54:44 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-22 15:54:44 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined index: thead D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16563
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined index: trids D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19566
ERROR - 2021-09-22 16:43:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19566
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined index: trids D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19595
ERROR - 2021-09-22 16:43:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19595
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined index: trids D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19598
ERROR - 2021-09-22 16:43:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19598
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined index: old_cell_padding D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19808
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-22 16:43:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-22 16:44:28 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-22 16:45:48 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-22 16:46:40 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-22 16:47:27 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-22 16:48:53 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-22 16:49:34 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-22 16:50:11 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-22 17:22:23 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-22 17:27:51 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-22 17:28:13 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-22 17:28:45 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-22 17:29:19 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-22 17:29:45 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-22 17:31:24 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-22 17:32:29 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:32:29 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:32:29 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:32:29 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:32:29 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:32:29 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:32:29 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:32:29 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:32:29 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:32:29 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:32:29 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:32:29 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:34:35 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:34:35 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:34:35 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:34:35 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:34:35 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:34:35 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:34:35 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:34:35 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:34:35 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:34:35 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:34:35 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:34:35 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:44:00 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:44:00 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:44:00 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:44:00 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:44:00 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:44:00 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:44:00 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:44:00 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:44:00 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:44:00 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:44:00 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:44:00 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-22 17:52:24 --> Severity: Warning --> Illegal string offset 'Course_name' D:\xampp\htdocs\EMS\application\views\examStudentCountModulePDF.php 28
ERROR - 2021-09-22 18:13:15 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-22 18:15:22 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 14
ERROR - 2021-09-22 18:16:12 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-22 18:16:19 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 14
ERROR - 2021-09-22 18:45:29 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 14
ERROR - 2021-09-22 20:07:57 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-22 20:08:31 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-22 20:08:38 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-22 20:21:46 --> Severity: error --> Exception: syntax error, unexpected 'exit' (T_EXIT) D:\xampp\htdocs\EMS\application\views\selectexamView.php 60
ERROR - 2021-09-22 20:24:27 --> Severity: Warning --> Use of undefined constant Application_end_date - assumed 'Application_end_date' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\selectexamView.php 60
ERROR - 2021-09-22 21:09:14 --> Severity: Notice --> Undefined variable: exam D:\xampp\htdocs\EMS\application\views\selectexamView.php 61
ERROR - 2021-09-22 21:09:37 --> Severity: Notice --> Undefined variable: exam D:\xampp\htdocs\EMS\application\views\selectexamView.php 61
ERROR - 2021-09-22 21:09:55 --> Severity: Notice --> Undefined variable: exam D:\xampp\htdocs\EMS\application\views\selectexamView.php 61
ERROR - 2021-09-22 21:11:02 --> Severity: Notice --> Undefined variable: exam D:\xampp\htdocs\EMS\application\views\selectexamView.php 61
ERROR - 2021-09-22 21:12:54 --> Severity: Notice --> Undefined variable: exam D:\xampp\htdocs\EMS\application\views\selectexamView.php 61
ERROR - 2021-09-22 21:14:51 --> Severity: Notice --> Undefined variable: exam D:\xampp\htdocs\EMS\application\views\selectexamView.php 61
ERROR - 2021-09-22 21:15:45 --> Severity: Notice --> Undefined variable: exam D:\xampp\htdocs\EMS\application\views\selectexamView.php 61
ERROR - 2021-09-22 21:27:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 17
ERROR - 2021-09-22 21:27:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 19
ERROR - 2021-09-22 21:27:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 65
ERROR - 2021-09-22 21:27:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 65

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-19 05:17:39 --> Could not find the language line "update_batch() called with no data"

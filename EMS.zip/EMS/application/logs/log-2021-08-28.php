<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-28 05:40:01 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 05:44:43 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 222
ERROR - 2021-08-28 05:45:03 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 05:45:03 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 05:49:23 --> Severity: Notice --> Undefined variable: ExamID C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 230
ERROR - 2021-08-28 05:49:23 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 205
ERROR - 2021-08-28 05:49:58 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 205
ERROR - 2021-08-28 05:50:00 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 205
ERROR - 2021-08-28 05:50:02 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 205
ERROR - 2021-08-28 05:56:38 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 244
ERROR - 2021-08-28 05:57:23 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 205
ERROR - 2021-08-28 05:57:47 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 205
ERROR - 2021-08-28 05:58:10 --> Could not find the language line "form_validation_date_check"
ERROR - 2021-08-28 05:58:10 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 05:59:19 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:00:09 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:00:13 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:02:34 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:02:44 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:02:51 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:02:57 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:03:08 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:05:12 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:05:20 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:07:42 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:08:00 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:17:48 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:18:06 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:18:43 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:18:43 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\EMS\application\views\examScheduleView.php 15
ERROR - 2021-08-28 06:19:30 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:19:46 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:19:46 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\EMS\application\views\examScheduleView.php 15
ERROR - 2021-08-28 06:20:20 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:20:47 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:21:20 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:21:37 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:22:16 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:24:01 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:26:57 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:26:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\EMS\application\views\examScheduleView.php 37
ERROR - 2021-08-28 06:27:47 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:28:05 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:28:08 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:28:16 --> Severity: Notice --> Undefined variable: Date_Time C:\xampp\htdocs\EMS\application\views\examScheduleView.php 37
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 06:29:33 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:29:39 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:29:50 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:31:36 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:32:12 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:33:38 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:34:02 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:34:26 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:35:39 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:36:23 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 62
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 63
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 62
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 63
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 62
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 63
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 62
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 63
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 62
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 63
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 62
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 63
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 62
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 63
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 62
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 63
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 62
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 63
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 62
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 63
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 62
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 63
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 62
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 63
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 62
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 63
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 62
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 63
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 62
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 63
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 62
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 63
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 62
ERROR - 2021-08-28 06:38:04 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 63
ERROR - 2021-08-28 06:38:51 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:39:27 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:39:56 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:46:05 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 1 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 205
ERROR - 2021-08-28 06:46:44 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 1 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 205
ERROR - 2021-08-28 06:47:02 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 1 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 205
ERROR - 2021-08-28 06:47:03 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 1 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 205
ERROR - 2021-08-28 06:47:38 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 1 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 205
ERROR - 2021-08-28 06:48:12 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 1 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 205
ERROR - 2021-08-28 06:48:19 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 1 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 205
ERROR - 2021-08-28 06:49:43 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 1 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 205
ERROR - 2021-08-28 06:50:04 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:59:43 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 06:59:45 --> 404 Page Not Found: Exam_Center_Controller/update_exam_schedule
ERROR - 2021-08-28 07:00:52 --> 404 Page Not Found: Exam_Center_Controller/update_exam_schedule
ERROR - 2021-08-28 07:02:22 --> 404 Page Not Found: Exam_Center_Controller/update_exam_schedule
ERROR - 2021-08-28 07:02:27 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 07:02:29 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 277
ERROR - 2021-08-28 07:02:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY exam_schedule.Date_Time, exam_schedule.Course_ID, exam_schedule.Modu...' at line 3 - Invalid query: SELECT exam_schedule.EX_SCH_ID, exam_schedule.Exam_ID, exam_schedule.Course_ID, course.Course_name, exam_schedule.Module_ID, module.Module_name, 
        exam_schedule.Date_Time  FROM exam_schedule INNER JOIN course ON exam_schedule.Course_ID=course.Course_ID INNER JOIN module ON 
        exam_schedule.Module_ID=module.Module_ID WHERE exam_schedule.Exam_ID= ORDER BY exam_schedule.Date_Time, exam_schedule.Course_ID, exam_schedule.Module_ID
ERROR - 2021-08-28 07:03:38 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 07:03:38 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 07:07:16 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 07:11:40 --> Severity: Notice --> Undefined property: stdClass::$object_property C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 281
ERROR - 2021-08-28 07:13:03 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 281
ERROR - 2021-08-28 10:29:22 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 10:29:27 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:29:27 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:30:58 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 10:31:50 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:31:50 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:31:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 35
ERROR - 2021-08-28 10:32:05 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:32:05 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:35:00 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 10:35:03 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 10:35:10 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 10:36:02 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:36:02 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:36:17 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:36:17 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:36:48 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:36:48 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:37:41 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:37:41 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:38:39 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:38:39 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:38:44 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:38:44 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:38:44 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:38:44 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:38:49 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 10:38:52 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:38:52 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:39:41 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:39:41 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:39:41 --> Severity: Notice --> Undefined variable: Date_Time C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 36
ERROR - 2021-08-28 10:40:17 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:40:17 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:40:36 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 10:40:46 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 10:41:05 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:41:05 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:41:22 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 10:48:24 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:48:24 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:54:18 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:54:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 41
ERROR - 2021-08-28 10:54:40 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:55:02 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 10:55:04 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:56:22 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 10:56:26 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:56:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\system\database\DB_query_builder.php 2013
ERROR - 2021-08-28 10:57:19 --> 404 Page Not Found: Exam_Manage_Controller/examcenterview
ERROR - 2021-08-28 10:58:47 --> 404 Page Not Found: Exam_Manage_Controller/examcenterview
ERROR - 2021-08-28 10:58:49 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 10:58:51 --> 404 Page Not Found: Exam_Manage_Controller/examcenterview
ERROR - 2021-08-28 11:00:31 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 296
ERROR - 2021-08-28 11:01:30 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 297
ERROR - 2021-08-28 11:01:47 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 297
ERROR - 2021-08-28 11:01:48 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 297
ERROR - 2021-08-28 11:01:54 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 297
ERROR - 2021-08-28 11:02:00 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 297
ERROR - 2021-08-28 11:02:15 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:02:40 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 11:03:41 --> 404 Page Not Found: Exam_Manage_Controller/updateExamScheduleView
ERROR - 2021-08-28 11:04:34 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 298
ERROR - 2021-08-28 11:04:54 --> 404 Page Not Found: Exam_Manage_Controller/updateExamScheduleView
ERROR - 2021-08-28 11:04:58 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 11:05:02 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:05:12 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 11:05:17 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:05:21 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 11:05:27 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:05:38 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 11:05:44 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:06:30 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 11:07:10 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:07:15 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 11:07:20 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:07:45 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 11:07:50 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:09:06 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 11:09:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\system\database\DB_query_builder.php 2013
ERROR - 2021-08-28 11:11:53 --> Severity: 4096 --> Object of class CI_Input could not be converted to string C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 385
ERROR - 2021-08-28 11:11:53 --> Severity: 4096 --> Object of class CI_Input could not be converted to string C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 385
ERROR - 2021-08-28 11:11:53 --> Severity: 4096 --> Object of class CI_Input could not be converted to string C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 385
ERROR - 2021-08-28 11:11:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Course')', Module_ID='->post('Module')',Date_Time='->post('Date_Time')' WHERE...' at line 1 - Invalid query: UPDATE exam_schedule SET Course_ID='->post('Course')', Module_ID='->post('Module')',Date_Time='->post('Date_Time')' WHERE EX_SCH_ID='1'
ERROR - 2021-08-28 11:13:33 --> Severity: 4096 --> Object of class CI_Input could not be converted to string C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 385
ERROR - 2021-08-28 11:13:33 --> Severity: 4096 --> Object of class CI_Input could not be converted to string C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 385
ERROR - 2021-08-28 11:13:33 --> Severity: 4096 --> Object of class CI_Input could not be converted to string C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 385
ERROR - 2021-08-28 11:15:53 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 401
ERROR - 2021-08-28 11:17:27 --> Severity: error --> Exception: Too few arguments to function CI_DB_driver::query(), 0 passed in C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php on line 390 and at least 1 expected C:\xampp\htdocs\EMS\system\database\DB_driver.php 608
ERROR - 2021-08-28 11:18:58 --> Severity: error --> Exception: Too few arguments to function CI_DB_driver::query(), 0 passed in C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php on line 390 and at least 1 expected C:\xampp\htdocs\EMS\system\database\DB_driver.php 608
ERROR - 2021-08-28 11:20:11 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:20:14 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 11:20:19 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:20:28 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 11:20:35 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:20:48 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 11:20:55 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:20:59 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 11:21:04 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:24:53 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:25:14 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:26:02 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:26:06 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:26:09 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 11:26:11 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:24:43 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:26:22 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:37:16 --> Severity: Compile Error --> Cannot redeclare Exam_Manage_Controller::download_exam_schedule_pdf() C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 322
ERROR - 2021-08-28 12:37:33 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:37:37 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:38:12 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:39:51 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:39:53 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:39:57 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:42:08 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:42:13 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:42:17 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:43:21 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:43:22 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:45:29 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:45:30 --> Severity: Notice --> Undefined variable: Date_Time C:\xampp\htdocs\EMS\application\views\examScheduleView.php 37
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 12:48:00 --> Severity: Notice --> Undefined variable: Date_Time C:\xampp\htdocs\EMS\application\views\examScheduleView.php 37
ERROR - 2021-08-28 12:48:14 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:48:28 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:48:29 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:48:35 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:48:36 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:48:45 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:49:23 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:49:28 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:49:31 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:49:36 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:49:37 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:50:41 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:50:45 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:50:47 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:52:26 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:52:28 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:52:32 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:52:34 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:53:27 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:59:48 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 12:59:48 --> Severity: Notice --> Undefined variable: course C:\xampp\htdocs\EMS\application\views\examScheduleView.php 18
ERROR - 2021-08-28 12:59:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\examScheduleView.php 18
ERROR - 2021-08-28 12:59:48 --> Severity: Notice --> Undefined variable: module C:\xampp\htdocs\EMS\application\views\examScheduleView.php 29
ERROR - 2021-08-28 12:59:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\examScheduleView.php 29
ERROR - 2021-08-28 12:59:48 --> Severity: Notice --> Undefined variable: Date_Time C:\xampp\htdocs\EMS\application\views\examScheduleView.php 37
ERROR - 2021-08-28 12:59:48 --> Severity: Notice --> Undefined variable: schedule C:\xampp\htdocs\EMS\application\views\examScheduleView.php 53
ERROR - 2021-08-28 12:59:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\examScheduleView.php 53
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 30
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 31
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 36
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 59
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 64
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 66
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Std_NIC C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 67
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Student_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 68
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Address C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 30
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 31
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 36
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 59
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 64
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 66
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Std_NIC C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 67
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Student_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 68
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Address C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 30
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 31
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 36
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 59
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 64
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 66
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Std_NIC C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 67
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Student_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 68
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Address C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 30
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 31
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 36
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 59
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 64
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 66
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Std_NIC C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 67
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Student_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 68
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Address C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 30
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 31
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 36
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 59
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 64
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 66
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Std_NIC C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 67
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Student_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 68
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Address C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 30
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 31
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 36
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 59
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 64
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 66
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Std_NIC C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 67
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Student_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 68
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Address C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 30
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 31
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 36
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 59
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 64
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 66
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Std_NIC C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 67
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Student_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 68
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Address C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 30
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 31
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 36
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 59
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 64
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 66
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Std_NIC C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 67
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Student_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 68
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Address C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 30
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 31
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 36
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 59
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 64
ERROR - 2021-08-28 13:00:36 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 66
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Std_NIC C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 67
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Student_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 68
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Address C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 30
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 31
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 36
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 59
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 64
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 66
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Std_NIC C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 67
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Student_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 68
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Address C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 30
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 31
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 36
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 59
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 64
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 66
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Std_NIC C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 67
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Student_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 68
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Address C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 30
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 31
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 36
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 59
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 64
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 66
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Std_NIC C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 67
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Student_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 68
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Address C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 30
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 31
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 36
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 59
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 64
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 66
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Std_NIC C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 67
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Student_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 68
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Address C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 30
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 31
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 36
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 59
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 64
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 66
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Std_NIC C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 67
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Student_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 68
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Address C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 30
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 31
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Module_code C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 36
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 59
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 64
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Index_number C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 66
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Std_NIC C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 67
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Student_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 68
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Exam_Center_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 13:00:37 --> Severity: Notice --> Undefined property: stdClass::$Address C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 72
ERROR - 2021-08-28 16:45:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 41
ERROR - 2021-08-28 16:47:57 --> Severity: Notice --> Trying to get property 'EX_SCH_ID' of non-object C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 41
ERROR - 2021-08-28 16:49:50 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING) C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 42
ERROR - 2021-08-28 16:52:10 --> Severity: Notice --> Trying to get property 'EX_SCH_ID' of non-object C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 42
ERROR - 2021-08-28 17:32:44 --> Severity: error --> Exception: syntax error, unexpected '$tbl' (T_VARIABLE) C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 56
ERROR - 2021-08-28 17:34:14 --> Severity: error --> Exception: syntax error, unexpected '$tbl' (T_VARIABLE) C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 56
ERROR - 2021-08-28 17:34:28 --> Severity: error --> Exception: syntax error, unexpected '$tbl' (T_VARIABLE) C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 56
ERROR - 2021-08-28 17:34:53 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 73
ERROR - 2021-08-28 17:35:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-08-28 17:35:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-08-28 17:44:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-08-28 17:44:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-08-28 17:44:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-08-28 17:44:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-08-28 17:44:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-08-28 17:44:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-08-28 17:44:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-08-28 17:44:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-08-28 17:44:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-08-28 17:44:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-08-28 17:44:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-08-28 17:44:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-08-28 17:48:24 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 17:48:44 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 17:48:47 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 17:48:50 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 17:48:54 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 17:48:56 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 17:48:58 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 17:49:01 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 17:49:04 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 17:49:12 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 17:49:16 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 17:55:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-08-28 17:55:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-08-28 17:55:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-08-28 17:55:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-08-28 17:55:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-08-28 17:55:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-08-28 17:55:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-08-28 17:55:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-08-28 17:55:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-08-28 17:55:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-08-28 17:55:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-08-28 17:55:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-08-28 18:07:09 --> Severity: Notice --> Undefined index: course.Course_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 52
ERROR - 2021-08-28 18:07:09 --> Severity: Notice --> Undefined index: course.Course_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 53
ERROR - 2021-08-28 18:07:09 --> Severity: Notice --> Undefined index: course.Course_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 52
ERROR - 2021-08-28 18:07:09 --> Severity: Notice --> Undefined index: course.Course_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 53
ERROR - 2021-08-28 18:07:09 --> Severity: Notice --> Undefined index: course.Course_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 52
ERROR - 2021-08-28 18:07:09 --> Severity: Notice --> Undefined index: course.Course_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 53
ERROR - 2021-08-28 18:07:09 --> Severity: Notice --> Undefined index: course.Course_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 52
ERROR - 2021-08-28 18:07:09 --> Severity: Notice --> Undefined index: course.Course_name C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 53
ERROR - 2021-08-28 18:22:52 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 61
ERROR - 2021-08-28 18:40:29 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 50
ERROR - 2021-08-28 18:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 50
ERROR - 2021-08-28 18:40:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 50
ERROR - 2021-08-28 18:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 50
ERROR - 2021-08-28 18:40:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 50
ERROR - 2021-08-28 18:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 50
ERROR - 2021-08-28 18:40:47 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 50
ERROR - 2021-08-28 18:40:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 50
ERROR - 2021-08-28 18:40:47 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 50
ERROR - 2021-08-28 18:40:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 50
ERROR - 2021-08-28 18:40:47 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 50
ERROR - 2021-08-28 18:40:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 50
ERROR - 2021-08-28 18:41:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 51
ERROR - 2021-08-28 18:41:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 51
ERROR - 2021-08-28 18:41:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 51
ERROR - 2021-08-28 18:41:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 51
ERROR - 2021-08-28 18:41:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 51
ERROR - 2021-08-28 18:41:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 51
ERROR - 2021-08-28 18:42:54 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 77
ERROR - 2021-08-28 19:12:54 --> Severity: error --> Exception: syntax error, unexpected ''End_Time'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 380
ERROR - 2021-08-28 19:13:47 --> Query error: Unknown column 'exam_schedule.Date_Time' in 'order clause' - Invalid query: SELECT exam_schedule.EX_SCH_ID, exam_schedule.Exam_ID, exam_schedule.Course_ID, course.Course_name, exam_schedule.Module_ID, module.Module_name, 
        exam_schedule.Start_Time, exam_schedule.End_Time, create_exam.Level, create_exam.Semester, create_exam.Year   FROM exam_schedule INNER JOIN course ON exam_schedule.Course_ID=course.Course_ID INNER JOIN module ON 
        exam_schedule.Module_ID=module.Module_ID INNER JOIN create_exam ON exam_schedule.Exam_ID=create_exam.Exam_ID  WHERE exam_schedule.Exam_ID=1 ORDER BY exam_schedule.Date_Time, exam_schedule.Course_ID, exam_schedule.Module_ID
ERROR - 2021-08-28 19:14:21 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:14:21 --> Severity: Notice --> Undefined variable: Date_Time C:\xampp\htdocs\EMS\application\views\examScheduleView.php 37
ERROR - 2021-08-28 19:15:26 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:15:26 --> Severity: Notice --> Undefined variable: Date_Time C:\xampp\htdocs\EMS\application\views\examScheduleView.php 37
ERROR - 2021-08-28 19:15:26 --> Severity: Notice --> Undefined variable: Date_Time C:\xampp\htdocs\EMS\application\views\examScheduleView.php 42
ERROR - 2021-08-28 19:15:40 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:15:40 --> Severity: Notice --> Undefined variable: Date_Time C:\xampp\htdocs\EMS\application\views\examScheduleView.php 37
ERROR - 2021-08-28 19:15:40 --> Severity: Notice --> Undefined variable: Date_Time C:\xampp\htdocs\EMS\application\views\examScheduleView.php 42
ERROR - 2021-08-28 19:16:02 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:16:25 --> Could not find the language line "form_validation_start_date_check"
ERROR - 2021-08-28 19:16:25 --> Could not find the language line "form_validation_end_date_check"
ERROR - 2021-08-28 19:16:25 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:18:01 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:18:17 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:18:19 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:19:16 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:22:21 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:22:27 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:22:29 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:23:04 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 19
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: module_id C:\xampp\htdocs\EMS\application\views\examScheduleView.php 30
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: Start_Time C:\xampp\htdocs\EMS\application\views\examScheduleView.php 37
ERROR - 2021-08-28 19:23:56 --> Severity: Notice --> Undefined variable: End_Time C:\xampp\htdocs\EMS\application\views\examScheduleView.php 42
ERROR - 2021-08-28 19:24:13 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:24:24 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:24:33 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:31:36 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 266
ERROR - 2021-08-28 19:32:09 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 267
ERROR - 2021-08-28 19:32:46 --> Severity: error --> Exception: syntax error, unexpected 'DateTime' (T_STRING) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 267
ERROR - 2021-08-28 19:32:54 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:33:00 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:33:07 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:33:18 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:33:34 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:33:53 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:34:11 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 19:34:11 --> Severity: Notice --> Undefined variable: Date_Time C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 36
ERROR - 2021-08-28 19:38:19 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 19:39:31 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 19:40:56 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 19:41:02 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:43:49 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:43:51 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 19:43:57 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 314
ERROR - 2021-08-28 19:43:57 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 315
ERROR - 2021-08-28 19:43:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY exam_schedule.Start_Time, exam_schedule.Course_ID, exam_schedule.Mod...' at line 3 - Invalid query: SELECT exam_schedule.EX_SCH_ID, exam_schedule.Exam_ID, exam_schedule.Course_ID, course.Course_name, exam_schedule.Module_ID, module.Module_name, 
        exam_schedule.Start_Time, exam_schedule.End_Time, create_exam.Level, create_exam.Semester, create_exam.Year   FROM exam_schedule INNER JOIN course ON exam_schedule.Course_ID=course.Course_ID INNER JOIN module ON 
        exam_schedule.Module_ID=module.Module_ID INNER JOIN create_exam ON exam_schedule.Exam_ID=create_exam.Exam_ID  WHERE exam_schedule.Exam_ID= ORDER BY exam_schedule.Start_Time, exam_schedule.Course_ID, exam_schedule.Module_ID
ERROR - 2021-08-28 19:44:42 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:44:46 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 19:44:48 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:45:06 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 19:45:52 --> Severity: Notice --> Undefined variable: Exam_ID C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 323
ERROR - 2021-08-28 19:45:52 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 204
ERROR - 2021-08-28 19:47:33 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 204
ERROR - 2021-08-28 19:47:52 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 204
ERROR - 2021-08-28 19:48:09 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 204
ERROR - 2021-08-28 19:48:31 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 204
ERROR - 2021-08-28 19:48:56 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 204
ERROR - 2021-08-28 19:49:24 --> Severity: error --> Exception: Too few arguments to function Exam_Manage_Controller::view_exam_schedule(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 204
ERROR - 2021-08-28 19:50:19 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 321
ERROR - 2021-08-28 19:50:21 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 321
ERROR - 2021-08-28 19:50:23 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 321
ERROR - 2021-08-28 19:50:27 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 321
ERROR - 2021-08-28 19:50:31 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 321
ERROR - 2021-08-28 19:50:35 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 321
ERROR - 2021-08-28 19:51:13 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:51:19 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 19:51:23 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 19:52:09 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 19:53:38 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 19:53:44 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 7
ERROR - 2021-08-28 19:54:03 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:54:41 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:55:03 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:55:27 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:56:00 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:56:27 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-28 19:56:40 --> Severity: Notice --> Undefined index: Date_Time C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 77
ERROR - 2021-08-28 19:56:40 --> Severity: Notice --> Undefined index: Date_Time C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 77
ERROR - 2021-08-28 19:56:40 --> Severity: Notice --> Undefined index: Date_Time C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 63
ERROR - 2021-08-28 19:56:40 --> Severity: Notice --> Undefined index: Date_Time C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 63
ERROR - 2021-08-28 19:56:40 --> Severity: Notice --> Undefined index: Date_Time C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 77
ERROR - 2021-08-28 19:56:40 --> Severity: Notice --> Undefined index: Date_Time C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 77
ERROR - 2021-08-28 19:56:40 --> Severity: Notice --> Undefined index: Date_Time C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 77
ERROR - 2021-08-28 19:56:40 --> Severity: Notice --> Undefined index: Date_Time C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 77
ERROR - 2021-08-28 19:56:40 --> Severity: Notice --> Undefined index: Date_Time C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 77
ERROR - 2021-08-28 19:56:40 --> Severity: Notice --> Undefined index: Date_Time C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 77
ERROR - 2021-08-28 19:56:40 --> Severity: Notice --> Undefined index: Date_Time C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 63
ERROR - 2021-08-28 19:56:40 --> Severity: Notice --> Undefined index: Date_Time C:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 63
ERROR - 2021-08-28 20:43:57 --> Severity: Notice --> Undefined index: User_ID C:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 11
ERROR - 2021-08-28 20:44:39 --> Severity: Notice --> Undefined index: User_ID C:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 11
ERROR - 2021-08-28 20:46:54 --> Severity: Notice --> Trying to get property 'User_ID' of non-object C:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 11
ERROR - 2021-08-28 20:49:32 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 11
ERROR - 2021-08-28 20:49:54 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 11
ERROR - 2021-08-28 20:51:30 --> Severity: Notice --> Undefined variable: userData C:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 10
ERROR - 2021-08-28 20:52:10 --> Severity: Notice --> Trying to get property 'User_ID' of non-object C:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 11
ERROR - 2021-08-28 20:52:28 --> Severity: error --> Exception: syntax error, unexpected ']', expecting ')' C:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 11
ERROR - 2021-08-28 20:52:36 --> Severity: Warning --> Illegal string offset 'User_ID' C:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 11
ERROR - 2021-08-28 20:52:37 --> Severity: Warning --> Illegal string offset 'User_ID' C:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 11
ERROR - 2021-08-28 20:55:11 --> Severity: Notice --> Undefined variable: userData C:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 11
ERROR - 2021-08-28 20:56:36 --> Severity: Notice --> Undefined index: User_ID C:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 11
ERROR - 2021-08-28 20:57:48 --> Severity: Notice --> Undefined index: User_ID C:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 11
ERROR - 2021-08-28 20:58:15 --> Severity: Notice --> Undefined index: User_ID C:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 11
ERROR - 2021-08-28 20:58:16 --> Severity: Notice --> Undefined index: User_ID C:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 11
ERROR - 2021-08-28 20:58:59 --> Severity: Notice --> Undefined index: User_ID C:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 11
ERROR - 2021-08-28 21:03:10 --> Severity: error --> Exception: Call to undefined method RegisterStudentModel::getUserRoleComponentAccess() C:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 13
ERROR - 2021-08-28 21:03:27 --> Severity: Notice --> Undefined variable: user_data C:\xampp\htdocs\EMS\application\views\registerStudentView.php 8

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-12 21:26:25 --> Severity: Warning --> Use of undefined constant testView - assumed 'testView' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\controllers\Unit_test_Controller.php 21

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-26 10:45:08 --> Severity: Notice --> Undefined variable: training D:\xampp\htdocs\EMS\application\views\selectexamView.php 28
ERROR - 2021-11-26 10:51:54 --> Severity: Notice --> Undefined variable: training D:\xampp\htdocs\EMS\application\views\selectexamView.php 28
ERROR - 2021-11-26 14:27:39 --> Severity: Notice --> Undefined variable: training D:\xampp\htdocs\EMS\application\views\selectexamView.php 28
ERROR - 2021-11-26 14:28:48 --> Severity: Notice --> Undefined variable: training D:\xampp\htdocs\EMS\application\views\selectexamView.php 28

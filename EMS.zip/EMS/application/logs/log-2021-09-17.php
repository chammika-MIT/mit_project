<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-17 10:22:11 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 10:22:11 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 10:22:11 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 10
ERROR - 2021-09-17 10:22:11 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 10:22:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 10:22:11 --> Severity: Notice --> Undefined variable: schedule D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 10:22:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 11:29:11 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 11:29:11 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 11:29:11 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 10
ERROR - 2021-09-17 11:29:11 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 11:29:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 11:29:11 --> Severity: Notice --> Undefined variable: schedule D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 11:29:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 11:30:51 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 11:30:51 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 11:30:51 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 10
ERROR - 2021-09-17 11:30:51 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 11:30:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 11:30:51 --> Severity: Notice --> Undefined variable: schedule D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 11:30:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 11:30:52 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 11:30:52 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 11:30:52 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 10
ERROR - 2021-09-17 11:30:52 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 11:30:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 11:30:52 --> Severity: Notice --> Undefined variable: schedule D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 11:30:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 11:34:44 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 11:34:44 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 11:34:44 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 10
ERROR - 2021-09-17 11:34:44 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 11:34:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 11:34:44 --> Severity: Notice --> Undefined variable: schedule D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 11:34:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 11:35:30 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 11:35:30 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 11:35:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 11:35:30 --> Severity: Notice --> Undefined variable: schedule D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 11:35:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 11:36:32 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 11:36:32 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 11:36:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 11:36:32 --> Severity: Notice --> Undefined variable: schedule D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 11:36:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 11:39:23 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 11:39:23 --> Severity: Notice --> Undefined variable: course_id D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 20
ERROR - 2021-09-17 11:39:23 --> Severity: Notice --> Undefined variable: course_id D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 20
ERROR - 2021-09-17 11:39:23 --> Severity: Notice --> Undefined variable: course_id D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 20
ERROR - 2021-09-17 11:39:23 --> Severity: Notice --> Undefined variable: course_id D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 20
ERROR - 2021-09-17 11:39:23 --> Severity: Notice --> Undefined variable: course_id D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 20
ERROR - 2021-09-17 11:39:23 --> Severity: Notice --> Undefined variable: course_id D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 20
ERROR - 2021-09-17 11:39:23 --> Severity: Notice --> Undefined variable: course_id D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 20
ERROR - 2021-09-17 11:39:23 --> Severity: Notice --> Undefined variable: course_id D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 20
ERROR - 2021-09-17 11:39:23 --> Severity: Notice --> Undefined variable: course_id D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 20
ERROR - 2021-09-17 11:39:23 --> Severity: Notice --> Undefined variable: course_id D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 20
ERROR - 2021-09-17 11:39:23 --> Severity: Notice --> Undefined variable: course_id D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 20
ERROR - 2021-09-17 11:39:23 --> Severity: Notice --> Undefined variable: course_id D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 20
ERROR - 2021-09-17 11:39:23 --> Severity: Notice --> Undefined variable: course_id D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 20
ERROR - 2021-09-17 11:39:23 --> Severity: Notice --> Undefined variable: schedule D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 11:39:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 11:46:15 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 11:46:15 --> Severity: Notice --> Undefined variable: schedule D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 11:46:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 11:46:50 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-17 11:46:53 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 11:46:53 --> Severity: Notice --> Undefined variable: schedule D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 11:46:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 11:52:15 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 11:52:15 --> Severity: Notice --> Undefined variable: schedule D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 11:52:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 11:52:21 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 11:52:21 --> Severity: Notice --> Undefined variable: schedule D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 11:52:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 11:52:38 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 11:52:38 --> Severity: Notice --> Undefined variable: schedule D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 11:52:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 14:14:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM module WHERE Course_ID=
ERROR - 2021-09-17 14:17:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM module WHERE Course_ID=
ERROR - 2021-09-17 14:20:21 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:20:21 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 14:20:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 14:27:09 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-17 14:31:44 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:31:44 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 14:31:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 14:34:00 --> Severity: Notice --> Undefined index: Course D:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 87
ERROR - 2021-09-17 14:34:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM module WHERE Course_ID=
ERROR - 2021-09-17 14:34:39 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:34:39 --> Severity: Notice --> Undefined variable: module D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 14:34:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 40
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 43
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 46
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 47
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 43
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 46
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 47
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 43
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 46
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 47
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 43
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 46
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 47
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 43
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 46
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 47
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 43
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 46
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 47
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 43
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 46
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 47
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 43
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 46
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 47
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 43
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 46
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 47
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 43
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 46
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 47
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 43
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 46
ERROR - 2021-09-17 14:34:50 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 47
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 44
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 45
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 44
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 45
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 44
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 45
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 44
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 45
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 44
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 45
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 44
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 45
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 44
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 45
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 44
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 45
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 44
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 45
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 44
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 45
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 41
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 44
ERROR - 2021-09-17 14:36:48 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 45
ERROR - 2021-09-17 14:52:04 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:52:04 --> Severity: Notice --> Undefined variable: module D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 38
ERROR - 2021-09-17 14:52:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 38
ERROR - 2021-09-17 14:52:50 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:52:50 --> Severity: Notice --> Undefined variable: marks D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 38
ERROR - 2021-09-17 14:52:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 38
ERROR - 2021-09-17 14:53:09 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:53:09 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 14:53:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 14:53:13 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:53:13 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 14:53:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 14:53:13 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 44
ERROR - 2021-09-17 14:53:13 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 45
ERROR - 2021-09-17 14:53:16 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:53:16 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 14:53:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 14:53:16 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 44
ERROR - 2021-09-17 14:53:16 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 45
ERROR - 2021-09-17 14:53:17 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:53:17 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 14:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 14:53:17 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 44
ERROR - 2021-09-17 14:53:17 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 45
ERROR - 2021-09-17 14:54:05 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:54:05 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 14:54:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 14:54:05 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 44
ERROR - 2021-09-17 14:54:05 --> Severity: Notice --> Undefined property: stdClass::$EX_SCH_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 45
ERROR - 2021-09-17 14:55:04 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:55:04 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 14:55:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 19
ERROR - 2021-09-17 14:55:48 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:56:01 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:56:06 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:56:12 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:57:45 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:57:45 --> Severity: Notice --> Undefined variable: marks D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 38
ERROR - 2021-09-17 14:57:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 38
ERROR - 2021-09-17 14:58:17 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 14:58:17 --> Severity: Notice --> Undefined variable: marks D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 38
ERROR - 2021-09-17 14:58:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 38
ERROR - 2021-09-17 14:58:51 --> Severity: Notice --> Undefined variable: trainingcourse D:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 79
ERROR - 2021-09-17 14:58:51 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:00:24 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:00:24 --> Severity: Notice --> Undefined variable: marks D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 38
ERROR - 2021-09-17 15:00:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 38
ERROR - 2021-09-17 15:00:36 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:00:46 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:02:45 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:02:51 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:03:11 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:03:18 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:03:18 --> Severity: Notice --> Undefined variable: marks D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 38
ERROR - 2021-09-17 15:03:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 38
ERROR - 2021-09-17 15:05:47 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:05:47 --> Severity: Notice --> Undefined variable: marks D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 38
ERROR - 2021-09-17 15:05:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 38
ERROR - 2021-09-17 15:05:56 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:06:51 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:06:56 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:06:58 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:07:00 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:07:01 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:07:02 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:07:03 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:07:08 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:07:10 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:08:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM module WHERE Course_ID=
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:09:09 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:43 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:45 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:10:58 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:11:04 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:11:08 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:11:12 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:11:16 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:11:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 42
ERROR - 2021-09-17 15:14:59 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:15:07 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:15:12 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:15:17 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:15:29 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:20:33 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:20:37 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:57:04 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:57:17 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:57:22 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 15:58:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 4 - Invalid query: SELECT module.Module_name as 'Module_name',module_pass_mark.Minimum_mark as 
        'Minimum_mark' FROM module INNER JOIN module_pass_mark ON 
        module_pass_mark.Module_ID =module.Module_ID WHERE 
        module.Course_ID=
ERROR - 2021-09-17 16:01:31 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:01:36 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:01:38 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:01:38 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:01:38 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 10
ERROR - 2021-09-17 16:01:38 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 45
ERROR - 2021-09-17 16:01:38 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 46
ERROR - 2021-09-17 16:02:12 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:02:15 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:03:21 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:03:21 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:03:21 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 45
ERROR - 2021-09-17 16:03:21 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 46
ERROR - 2021-09-17 16:07:17 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:07:17 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:08:22 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:08:22 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:09:11 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:09:11 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:16:43 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:16:43 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:16:44 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:16:44 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:18:16 --> Severity: error --> Exception: Too few arguments to function Result_Controller::dispaymodulemarks(), 0 passed in D:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected D:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 84
ERROR - 2021-09-17 16:18:41 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:18:41 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:19:40 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:19:40 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:19:49 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:19:49 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:20:03 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:20:03 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:20:08 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:20:08 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:20:12 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:20:12 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:20:16 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:20:16 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:20:20 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:20:20 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:20:25 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:20:25 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:21:01 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:21:01 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:35:38 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 16:35:38 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:00:20 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:00:20 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:00:25 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:00:25 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:00:32 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:00:32 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:02:15 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:02:15 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:02:17 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:02:17 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:02:21 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:02:21 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:02:25 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:02:25 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:02:47 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:02:47 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:33 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:33 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:37 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:37 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:38 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:38 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:41 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:41 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:45 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:45 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:46 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:46 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:50 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:50 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:54 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:54 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:56 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:03:56 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:04:54 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:04:54 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:05:38 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:05:38 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:05:40 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:05:40 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:05:44 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:05:44 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:05:48 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:05:48 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:08:00 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:08:00 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:08:28 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:08:28 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:09:54 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:09:54 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:18 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:18 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:22 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:22 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:22 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:22 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:23 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:23 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:23 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:23 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:51 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:51 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:54 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:54 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:54 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:54 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:54 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:10:54 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:11:16 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:11:16 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:11:17 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:11:17 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:11:18 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:11:18 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:11:19 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:11:19 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:11:22 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:11:23 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:11:24 --> Severity: error --> Exception: Cannot use object of type CI_Form_validation as array D:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 111
ERROR - 2021-09-17 17:12:20 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:12:20 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:12:22 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:12:22 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:12:24 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:12:24 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:12:32 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:12:32 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:12:34 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:12:34 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:13:17 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:13:17 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:13:18 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:13:18 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:13:23 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:13:23 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:13:25 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:13:25 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:13:28 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:13:28 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:14:48 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:14:48 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:14:50 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:14:50 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:14:52 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:14:52 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:14:54 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:14:54 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:14:55 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:14:55 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:14:57 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:14:57 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:15:47 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:15:47 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:15:50 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:15:50 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:15:52 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:15:52 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:15:55 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:15:55 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:17:35 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:17:35 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:18:07 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:18:07 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:18:18 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:18:18 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:18:54 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:18:54 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:46:43 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 17:46:43 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 18:23:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ASE' at line 2 - Invalid query: SELECT module.Course_ID as 'Course_ID', module.Module_ID as 'Module_ID', module.Module_name as 'Module_name'
        FROM module INNER JOIN module_pass_mark ON module_pass_mark.Module_ID !=module.Module_ID ORDER BY module.Course_ID ASE
ERROR - 2021-09-17 18:25:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ASE INNER JOIN module_pass_mark ON module_pass_mark.Module_ID !=module.Module_ID' at line 2 - Invalid query: SELECT module.Course_ID as 'Course_ID', module.Module_ID as 'Module_ID', module.Module_name as 'Module_name'
        FROM module ORDER BY module.Course_ID ASE INNER JOIN module_pass_mark ON module_pass_mark.Module_ID !=module.Module_ID 
ERROR - 2021-09-17 18:51:06 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\addPassMarkModuleView.php 21
ERROR - 2021-09-17 18:51:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addPassMarkModuleView.php 21
ERROR - 2021-09-17 18:51:12 --> Could not find the language line "form_validation_grater_than"
ERROR - 2021-09-17 18:51:12 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\addPassMarkModuleView.php 21
ERROR - 2021-09-17 18:51:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addPassMarkModuleView.php 21
ERROR - 2021-09-17 18:52:09 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\addPassMarkModuleView.php 21
ERROR - 2021-09-17 18:52:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addPassMarkModuleView.php 21
ERROR - 2021-09-17 18:52:15 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\addPassMarkModuleView.php 21
ERROR - 2021-09-17 18:52:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addPassMarkModuleView.php 21
ERROR - 2021-09-17 18:54:43 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 18:54:43 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 18:56:18 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 18:56:18 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 19:36:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Add_institute_model D:\xampp\htdocs\EMS\system\core\Loader.php 348
ERROR - 2021-09-17 19:38:57 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-17 19:39:50 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-17 19:40:20 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-17 19:40:54 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-17 19:41:45 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-17 19:43:08 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-17 19:58:08 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 19:58:08 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 20:17:23 --> Severity: Notice --> Undefined property: ExamFeeController::$upload D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 30
ERROR - 2021-09-17 20:17:23 --> Severity: error --> Exception: Call to a member function data() on null D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 30
ERROR - 2021-09-17 20:50:24 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 20:50:24 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:12:10 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:12:10 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:13:19 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:13:19 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:13:49 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:13:49 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:14:01 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:14:01 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:16:17 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:16:17 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:16:22 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:16:22 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:16:39 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:16:39 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:17:23 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:17:23 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:17:34 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:17:34 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 8
ERROR - 2021-09-17 21:18:52 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 21:18:52 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 21:19:09 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 21:19:09 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 21:51:18 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 21:51:18 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 21:52:13 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 21:52:13 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:52:19 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 60
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 21:57:12 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 60
ERROR - 2021-09-17 22:00:01 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:00:02 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:00:37 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 31
ERROR - 2021-09-17 22:00:38 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 31
ERROR - 2021-09-17 22:01:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:01:10 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 22:01:10 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 22:01:12 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> Use of undefined constant Module_ID - assumed 'Module_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Object of class stdClass could not be converted to number D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 44
ERROR - 2021-09-17 22:03:19 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 60
ERROR - 2021-09-17 22:03:56 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:56 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:56 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:56 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:56 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:56 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:56 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:56 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:56 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 60
ERROR - 2021-09-17 22:03:58 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:58 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:58 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:58 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:58 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:58 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:58 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:58 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:03:58 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 60
ERROR - 2021-09-17 22:05:22 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:05:22 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:05:22 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:05:22 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:05:22 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:05:22 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:05:22 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:05:22 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:05:22 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 60
ERROR - 2021-09-17 22:05:23 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:05:23 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:05:23 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:05:23 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:05:23 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:05:23 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:05:23 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:05:23 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:05:23 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 60
ERROR - 2021-09-17 22:13:21 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:13:21 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:13:21 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:13:21 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:13:21 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:13:21 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:13:21 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:13:21 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:18:51 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:18:51 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:18:51 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:18:51 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:18:51 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:18:51 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:18:51 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:18:51 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:18:51 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 60
ERROR - 2021-09-17 22:18:52 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:18:52 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:18:52 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:18:52 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:18:52 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:18:52 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:18:52 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:18:52 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 32
ERROR - 2021-09-17 22:18:52 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 60
ERROR - 2021-09-17 22:21:30 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 22:21:30 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 22:24:33 --> Severity: Notice --> Trying to get property 'Course_name' of non-object D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 26
ERROR - 2021-09-17 22:24:33 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 60
ERROR - 2021-09-17 22:25:54 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 60
ERROR - 2021-09-17 22:28:03 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 60
ERROR - 2021-09-17 22:30:10 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 60
ERROR - 2021-09-17 22:32:13 --> Severity: Notice --> Undefined property: stdClass::$Minimum_mark D:\xampp\htdocs\EMS\application\views\updateModulePassMarkView.php 60
ERROR - 2021-09-17 22:34:08 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 22:34:08 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 22:34:14 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 22:34:14 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 22:34:20 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 22:34:20 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 22:34:25 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-17 22:34:25 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13

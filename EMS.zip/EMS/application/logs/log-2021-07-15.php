<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-15 16:20:36 --> Severity: error --> Exception: Call to undefined function get() D:\xampp\htdocs\EMS\application\models\ExamCenterModel.php 13
ERROR - 2021-07-15 16:28:12 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\updateExamCenterView.php 24
ERROR - 2021-07-15 16:28:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateExamCenterView.php 24
ERROR - 2021-07-15 16:31:08 --> Severity: Notice --> Undefined property: stdClass::$Capacity D:\xampp\htdocs\EMS\application\views\updateExamCenterView.php 37
ERROR - 2021-07-15 16:31:27 --> Severity: Notice --> Undefined property: stdClass::$Capacity D:\xampp\htdocs\EMS\application\views\updateExamCenterView.php 33
ERROR - 2021-07-15 16:31:29 --> Severity: Notice --> Undefined property: stdClass::$Capacity D:\xampp\htdocs\EMS\application\views\updateExamCenterView.php 33
ERROR - 2021-07-15 16:31:52 --> Severity: Notice --> Undefined property: stdClass::$Capacity D:\xampp\htdocs\EMS\application\views\updateExamCenterView.php 31
ERROR - 2021-07-15 16:37:21 --> Severity: error --> Exception: Call to undefined function selected() D:\xampp\htdocs\EMS\application\views\updateExamCenterView.php 26
ERROR - 2021-07-15 16:37:22 --> Severity: error --> Exception: Call to undefined function selected() D:\xampp\htdocs\EMS\application\views\updateExamCenterView.php 26
ERROR - 2021-07-15 16:37:23 --> Severity: error --> Exception: Call to undefined function selected() D:\xampp\htdocs\EMS\application\views\updateExamCenterView.php 26
ERROR - 2021-07-15 16:37:23 --> Severity: error --> Exception: Call to undefined function selected() D:\xampp\htdocs\EMS\application\views\updateExamCenterView.php 26
ERROR - 2021-07-15 16:37:23 --> Severity: error --> Exception: Call to undefined function selected() D:\xampp\htdocs\EMS\application\views\updateExamCenterView.php 26
ERROR - 2021-07-15 16:37:47 --> Severity: error --> Exception: Call to undefined function selected() D:\xampp\htdocs\EMS\application\views\updateExamCenterView.php 26
ERROR - 2021-07-15 16:44:44 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\updateExamCenterView.php 31
ERROR - 2021-07-15 16:46:16 --> Severity: Notice --> Undefined property: stdClass::$Capacity D:\xampp\htdocs\EMS\application\views\updateExamCenterView.php 31
ERROR - 2021-07-15 20:13:10 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:10 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:10 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:11 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:11 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:16 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:16 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:16 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:16 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:16 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:27 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:27 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:27 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:27 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:27 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:13:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:14:23 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:14:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:14:23 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:14:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:14:23 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:14:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:14:23 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:14:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:14:23 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:14:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:07 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:07 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:07 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:07 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:07 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:07 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:09 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:09 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:09 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:09 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:09 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:11 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:11 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:11 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:11 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:11 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:15 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:15 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:15 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:15 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:15 --> Severity: Notice --> Undefined variable: district D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 29
ERROR - 2021-07-15 20:19:05 --> Severity: error --> Exception: Call to undefined method View_institute_model::get_district() D:\xampp\htdocs\EMS\application\controllers\Institute_reg.php 11
ERROR - 2021-07-15 20:19:06 --> Severity: error --> Exception: Call to undefined method View_institute_model::get_district() D:\xampp\htdocs\EMS\application\controllers\Institute_reg.php 11
ERROR - 2021-07-15 20:20:03 --> Severity: Notice --> Undefined property: Institute_reg::$Add_institute_model D:\xampp\htdocs\EMS\application\controllers\Institute_reg.php 11
ERROR - 2021-07-15 20:20:03 --> Severity: error --> Exception: Call to a member function get_district() on null D:\xampp\htdocs\EMS\application\controllers\Institute_reg.php 11
ERROR - 2021-07-15 20:20:04 --> Severity: Notice --> Undefined property: Institute_reg::$Add_institute_model D:\xampp\htdocs\EMS\application\controllers\Institute_reg.php 11
ERROR - 2021-07-15 20:20:04 --> Severity: error --> Exception: Call to a member function get_district() on null D:\xampp\htdocs\EMS\application\controllers\Institute_reg.php 11
ERROR - 2021-07-15 20:44:18 --> Severity: error --> Exception: syntax error, unexpected '$response' (T_VARIABLE) D:\xampp\htdocs\EMS\application\controllers\Add_institutes_Controller.php 30
ERROR - 2021-07-15 20:51:59 --> Severity: error --> Exception: Call to undefined function pirnt_r() D:\xampp\htdocs\EMS\application\controllers\Add_institutes_Controller.php 25
ERROR - 2021-07-15 21:13:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Email='', ContactNo='' WHERE TC_ID='1'' at line 1 - Invalid query: UPDATE training_center SET Reg_No='P01/0023',Name='SOFT IT training', Address='Colombo 07', District_ID='5' Email='', ContactNo='' WHERE TC_ID='1'
ERROR - 2021-07-15 21:18:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Email='soft@yahoo.com', ContactNo='0112893556444' WHERE TC_ID='1'' at line 1 - Invalid query: UPDATE training_center SET Reg_No='P01/0023',Name='SOFT IT training', Address='Colombo 07', District_ID='5' Email='soft@yahoo.com', ContactNo='0112893556444' WHERE TC_ID='1'
ERROR - 2021-07-15 21:19:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Email='chammika@tvec.gov.lk', ContactNo='0117608008' WHERE TC_ID='1'' at line 1 - Invalid query: UPDATE training_center SET Reg_No='P01/0023',Name='SOFT IT training', Address='354/2, Elvitigala Mw, Narahenpita', District_ID='5' Email='chammika@tvec.gov.lk', ContactNo='0117608008' WHERE TC_ID='1'
ERROR - 2021-07-15 21:22:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Email='chammika@tvec.gov.lk', ContactNo='0117608008' WHERE TC_ID='1'' at line 1 - Invalid query: UPDATE training_center SET Reg_No='P01/0023',Name='SOFT IT training', Address='354/2, Elvitigala Mw, Narahenpita', District_ID='5' Email='chammika@tvec.gov.lk', ContactNo='0117608008' WHERE TC_ID='1'

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-25 07:01:01 --> Severity: Notice --> Undefined variable: training D:\xampp\htdocs\EMS\application\views\selectexamView.php 28
ERROR - 2021-11-25 07:01:33 --> Severity: Notice --> Undefined variable: training D:\xampp\htdocs\EMS\application\views\selectexamView.php 28
ERROR - 2021-11-25 18:42:45 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-19 06:57:52 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 06:57:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 06:58:31 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 06:58:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 06:59:15 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 06:59:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 06:59:15 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 52
ERROR - 2021-06-19 06:59:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 52
ERROR - 2021-06-19 06:59:20 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 06:59:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 06:59:20 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 52
ERROR - 2021-06-19 06:59:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 52
ERROR - 2021-06-19 07:00:20 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:00:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:00:20 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 54
ERROR - 2021-06-19 07:00:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 54
ERROR - 2021-06-19 07:00:22 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:00:22 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 54
ERROR - 2021-06-19 07:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 54
ERROR - 2021-06-19 07:01:21 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:01:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:01:21 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:01:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:01:21 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:01:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:01:21 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:01:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:01:22 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:01:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:01:22 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:01:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:01:22 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:01:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:01:22 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:01:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:01:22 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:01:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:01:22 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:01:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:01:23 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:01:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:01:23 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:01:23 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:02:49 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:02:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:02:49 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 54
ERROR - 2021-06-19 07:02:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 54
ERROR - 2021-06-19 07:03:46 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:03:46 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:03:47 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:03:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:03:47 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:03:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:03:47 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:03:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:03:47 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:03:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:03:47 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:03:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:03:47 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:03:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:03:47 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:03:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:03:47 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:03:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:03:48 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:03:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:03:48 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:03:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 56
ERROR - 2021-06-19 07:04:12 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:04:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:04:13 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:04:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:05:05 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:05:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 22
ERROR - 2021-06-19 07:05:47 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 21
ERROR - 2021-06-19 07:05:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 21
ERROR - 2021-06-19 07:12:12 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 07:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 07:12:43 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 07:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:34:52 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:34:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:37:15 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:37:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:43:09 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:43:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:43:10 --> 404 Page Not Found: AddCourseModule_controller/aadd_Course
ERROR - 2021-06-19 15:43:19 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:43:19 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:43:30 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:43:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:43:50 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:43:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:45:50 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:45:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:46:30 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:46:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:47:52 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 15:47:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 16:03:58 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 16:03:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 20
ERROR - 2021-06-19 16:25:20 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' D:\xampp\htdocs\EMS\application\models\AddCourseModule_model.php 13
ERROR - 2021-06-19 16:34:08 --> Severity: Notice --> Undefined property: stdClass::$TC_ID D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 29
ERROR - 2021-06-19 16:34:08 --> Severity: Notice --> Undefined property: stdClass::$TC_ID D:\xampp\htdocs\EMS\application\views\addCourseModule_view.php 30
ERROR - 2021-06-19 16:49:49 --> Query error: Unknown column 'Reg_No' in 'where clause' - Invalid query: SELECT *
FROM `course`
WHERE `Reg_No` = 'K52'
 LIMIT 1

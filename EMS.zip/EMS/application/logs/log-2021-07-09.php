<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-09 17:39:01 --> Severity: Notice --> Undefined property: Add_institutes_Controller::$Add_institute_modell D:\xampp\htdocs\EMS\application\controllers\Add_institutes_Controller.php 23
ERROR - 2021-07-09 17:39:01 --> Severity: error --> Exception: Call to a member function get_district() on null D:\xampp\htdocs\EMS\application\controllers\Add_institutes_Controller.php 23

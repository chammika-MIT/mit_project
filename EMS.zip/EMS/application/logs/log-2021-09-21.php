<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-21 09:27:06 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-21 10:59:28 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-21 15:08:22 --> Query error: Unknown column '890103023V' in 'where clause' - Invalid query: SELECT module.Module_name as 'Module', result.Marks as 'marks', student_registration.Std_NIC FROM `result` 
        INNER JOIN student_exam_module ON result.ST_EX_MO_ID=student_exam_module.ST_EX_MO_ID
        INNER JOIN module ON student_exam_module.Module_ID=module.Module_ID
        INNER JOIN student_exam_course ON student_exam_module.ST_EX_CO_ID=student_exam_course.ST_EX_CO_ID
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID WHERE student_registration.Std_NIC=890103023V
ERROR - 2021-09-21 15:09:00 --> Query error: Unknown column '931550918V' in 'where clause' - Invalid query: SELECT module.Module_name as 'Module', result.Marks as 'marks', student_registration.Std_NIC FROM `result` 
        INNER JOIN student_exam_module ON result.ST_EX_MO_ID=student_exam_module.ST_EX_MO_ID
        INNER JOIN module ON student_exam_module.Module_ID=module.Module_ID
        INNER JOIN student_exam_course ON student_exam_module.ST_EX_CO_ID=student_exam_course.ST_EX_CO_ID
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID WHERE student_registration.Std_NIC=931550918V
ERROR - 2021-09-21 15:09:33 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\EMS\application\models\studentInfoModel.php 36
ERROR - 2021-09-21 15:09:53 --> Query error: Unknown column '931550918V' in 'where clause' - Invalid query: SELECT module.Module_name as 'Module', result.Marks as 'marks', student_registration.Std_NIC FROM `result` 
        INNER JOIN student_exam_module ON result.ST_EX_MO_ID=student_exam_module.ST_EX_MO_ID
        INNER JOIN module ON student_exam_module.Module_ID=module.Module_ID
        INNER JOIN student_exam_course ON student_exam_module.ST_EX_CO_ID=student_exam_course.ST_EX_CO_ID
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID WHERE student_registration.Std_NIC=931550918V
ERROR - 2021-09-21 15:51:16 --> Query error: Unknown column '931550918V' in 'where clause' - Invalid query: SELECT module.Module_name as 'Module', result.Marks as 'marks', student_registration.Std_NIC FROM `result` 
        INNER JOIN student_exam_module ON result.ST_EX_MO_ID=student_exam_module.ST_EX_MO_ID
        INNER JOIN module ON student_exam_module.Module_ID=module.Module_ID
        INNER JOIN student_exam_course ON student_exam_module.ST_EX_CO_ID=student_exam_course.ST_EX_CO_ID
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID WHERE student_registration.Std_NIC=931550918V
ERROR - 2021-09-21 15:51:24 --> Query error: Unknown column '931550918V' in 'where clause' - Invalid query: SELECT module.Module_name as 'Module', result.Marks as 'marks', student_registration.Std_NIC FROM `result` 
        INNER JOIN student_exam_module ON result.ST_EX_MO_ID=student_exam_module.ST_EX_MO_ID
        INNER JOIN module ON student_exam_module.Module_ID=module.Module_ID
        INNER JOIN student_exam_course ON student_exam_module.ST_EX_CO_ID=student_exam_course.ST_EX_CO_ID
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID WHERE student_registration.Std_NIC=931550918V
ERROR - 2021-09-21 16:06:37 --> Severity: Notice --> Undefined property: stdClass::$Semester_No D:\xampp\htdocs\EMS\application\views\studentInfoView.php 98
ERROR - 2021-09-21 16:06:37 --> Severity: Notice --> Undefined property: stdClass::$Semester_No D:\xampp\htdocs\EMS\application\views\studentInfoView.php 98
ERROR - 2021-09-21 16:06:37 --> Severity: Notice --> Undefined property: stdClass::$Semester_No D:\xampp\htdocs\EMS\application\views\studentInfoView.php 98
ERROR - 2021-09-21 16:06:37 --> Severity: Notice --> Undefined property: stdClass::$Semester_No D:\xampp\htdocs\EMS\application\views\studentInfoView.php 98
ERROR - 2021-09-21 16:06:37 --> Severity: Notice --> Undefined property: stdClass::$Semester_No D:\xampp\htdocs\EMS\application\views\studentInfoView.php 98
ERROR - 2021-09-21 16:07:22 --> Severity: Notice --> Undefined property: stdClass::$Semester_No D:\xampp\htdocs\EMS\application\views\studentInfoView.php 98
ERROR - 2021-09-21 16:07:22 --> Severity: Notice --> Undefined property: stdClass::$Semester_No D:\xampp\htdocs\EMS\application\views\studentInfoView.php 98
ERROR - 2021-09-21 16:07:22 --> Severity: Notice --> Undefined property: stdClass::$Semester_No D:\xampp\htdocs\EMS\application\views\studentInfoView.php 98
ERROR - 2021-09-21 16:07:22 --> Severity: Notice --> Undefined property: stdClass::$Semester_No D:\xampp\htdocs\EMS\application\views\studentInfoView.php 98
ERROR - 2021-09-21 16:07:22 --> Severity: Notice --> Undefined property: stdClass::$Semester_No D:\xampp\htdocs\EMS\application\views\studentInfoView.php 98
ERROR - 2021-09-21 16:07:32 --> Severity: Notice --> Undefined property: stdClass::$Semester_No D:\xampp\htdocs\EMS\application\views\studentInfoView.php 98
ERROR - 2021-09-21 16:07:32 --> Severity: Notice --> Undefined property: stdClass::$Semester_No D:\xampp\htdocs\EMS\application\views\studentInfoView.php 98
ERROR - 2021-09-21 16:07:32 --> Severity: Notice --> Undefined property: stdClass::$Semester_No D:\xampp\htdocs\EMS\application\views\studentInfoView.php 98
ERROR - 2021-09-21 16:07:32 --> Severity: Notice --> Undefined property: stdClass::$Semester_No D:\xampp\htdocs\EMS\application\views\studentInfoView.php 98
ERROR - 2021-09-21 16:07:32 --> Severity: Notice --> Undefined property: stdClass::$Semester_No D:\xampp\htdocs\EMS\application\views\studentInfoView.php 98
ERROR - 2021-09-21 17:28:34 --> Severity: Notice --> Undefined property: stdClass::$Module_Name D:\xampp\htdocs\EMS\application\views\studentInfoView.php 128
ERROR - 2021-09-21 17:28:34 --> Severity: Notice --> Undefined property: stdClass::$Start_Date_Time D:\xampp\htdocs\EMS\application\views\studentInfoView.php 129
ERROR - 2021-09-21 17:28:34 --> Severity: Notice --> Undefined property: stdClass::$End_Date_Time D:\xampp\htdocs\EMS\application\views\studentInfoView.php 130
ERROR - 2021-09-21 17:28:34 --> Severity: Notice --> Undefined property: stdClass::$Semester D:\xampp\htdocs\EMS\application\views\studentInfoView.php 131
ERROR - 2021-09-21 17:28:34 --> Severity: Notice --> Undefined property: stdClass::$Module_Name D:\xampp\htdocs\EMS\application\views\studentInfoView.php 128
ERROR - 2021-09-21 17:28:34 --> Severity: Notice --> Undefined property: stdClass::$Start_Date_Time D:\xampp\htdocs\EMS\application\views\studentInfoView.php 129
ERROR - 2021-09-21 17:28:34 --> Severity: Notice --> Undefined property: stdClass::$End_Date_Time D:\xampp\htdocs\EMS\application\views\studentInfoView.php 130
ERROR - 2021-09-21 17:28:34 --> Severity: Notice --> Undefined property: stdClass::$Semester D:\xampp\htdocs\EMS\application\views\studentInfoView.php 131
ERROR - 2021-09-21 17:28:34 --> Severity: Notice --> Undefined property: stdClass::$Module_Name D:\xampp\htdocs\EMS\application\views\studentInfoView.php 128
ERROR - 2021-09-21 17:28:34 --> Severity: Notice --> Undefined property: stdClass::$Start_Date_Time D:\xampp\htdocs\EMS\application\views\studentInfoView.php 129
ERROR - 2021-09-21 17:28:34 --> Severity: Notice --> Undefined property: stdClass::$End_Date_Time D:\xampp\htdocs\EMS\application\views\studentInfoView.php 130
ERROR - 2021-09-21 17:28:34 --> Severity: Notice --> Undefined property: stdClass::$Semester D:\xampp\htdocs\EMS\application\views\studentInfoView.php 131
ERROR - 2021-09-21 17:28:34 --> Severity: Notice --> Undefined property: stdClass::$Module_Name D:\xampp\htdocs\EMS\application\views\studentInfoView.php 128
ERROR - 2021-09-21 17:28:34 --> Severity: Notice --> Undefined property: stdClass::$Start_Date_Time D:\xampp\htdocs\EMS\application\views\studentInfoView.php 129
ERROR - 2021-09-21 17:28:34 --> Severity: Notice --> Undefined property: stdClass::$End_Date_Time D:\xampp\htdocs\EMS\application\views\studentInfoView.php 130
ERROR - 2021-09-21 17:28:34 --> Severity: Notice --> Undefined property: stdClass::$Semester D:\xampp\htdocs\EMS\application\views\studentInfoView.php 131
ERROR - 2021-09-21 20:30:04 --> Severity: Notice --> Undefined variable: Module_ID D:\xampp\htdocs\EMS\application\models\LoginManagModel.php 36
ERROR - 2021-09-21 20:31:02 --> Severity: Notice --> Undefined variable: Module_ID D:\xampp\htdocs\EMS\application\models\LoginManagModel.php 36
ERROR - 2021-09-21 20:31:02 --> Severity: error --> Exception: Call to a member function row() on bool D:\xampp\htdocs\EMS\application\models\LoginManagModel.php 37
ERROR - 2021-09-21 20:32:12 --> Severity: error --> Exception: Call to a member function row() on bool D:\xampp\htdocs\EMS\application\models\LoginManagModel.php 37

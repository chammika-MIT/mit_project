<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-04 21:41:46 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\views\examStudentCountModulePDF.php 24
ERROR - 2021-09-04 22:58:37 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID D:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 53
ERROR - 2021-09-04 22:58:37 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID D:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 53
ERROR - 2021-09-04 22:58:37 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID D:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 53
ERROR - 2021-09-04 22:58:37 --> Severity: Notice --> Undefined property: stdClass::$EXC_ID D:\xampp\htdocs\EMS\application\views\assignExamCenterView.php 53
ERROR - 2021-09-04 23:06:08 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-04 23:08:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-09-04 23:08:05 --> Severity: Notice --> Undefined index: rows D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16981
ERROR - 2021-09-04 23:08:05 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16983
ERROR - 2021-09-04 23:08:05 --> Severity: Notice --> Undefined index: thead D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16563
ERROR - 2021-09-04 23:08:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-04 23:08:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-04 23:08:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-04 23:08:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-04 23:08:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-04 23:08:05 --> Severity: Notice --> Undefined variable: cellspacingx D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18179
ERROR - 2021-09-04 23:08:05 --> Severity: Notice --> Undefined variable: cellspacing D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18246
ERROR - 2021-09-04 23:08:05 --> Severity: Notice --> Undefined variable: cellspacing D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18272
ERROR - 2021-09-04 23:08:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-09-04 23:08:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-04 23:08:05 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040

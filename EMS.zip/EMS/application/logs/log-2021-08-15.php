<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-15 19:34:40 --> Severity: error --> Exception: syntax error, unexpected '1' (T_LNUMBER) C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 31
ERROR - 2021-08-15 19:35:07 --> Severity: error --> Exception: syntax error, unexpected '$obj_pdf' (T_VARIABLE) C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 61
ERROR - 2021-08-15 19:35:17 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:35:17 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:35:17 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:35:17 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:35:17 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:35:17 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:35:17 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:35:17 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:35:17 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:35:17 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:35:17 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:35:17 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:36:32 --> Severity: error --> Exception: syntax error, unexpected '0' (T_LNUMBER) C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 55
ERROR - 2021-08-15 19:36:49 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:36:49 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:36:49 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:36:49 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:36:49 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:36:49 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:36:49 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:36:49 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:36:49 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:36:49 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:36:49 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:36:49 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 24
ERROR - 2021-08-15 19:48:47 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 30
ERROR - 2021-08-15 19:49:04 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 27
ERROR - 2021-08-15 19:49:04 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 27
ERROR - 2021-08-15 19:49:04 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 27
ERROR - 2021-08-15 19:49:04 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 27
ERROR - 2021-08-15 19:49:04 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 27
ERROR - 2021-08-15 19:49:04 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 27
ERROR - 2021-08-15 19:49:04 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 27
ERROR - 2021-08-15 19:49:04 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 27
ERROR - 2021-08-15 19:49:04 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 27
ERROR - 2021-08-15 19:49:04 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 27
ERROR - 2021-08-15 19:49:04 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 27
ERROR - 2021-08-15 19:49:04 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 27
ERROR - 2021-08-15 19:50:16 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 28
ERROR - 2021-08-15 19:50:16 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 28
ERROR - 2021-08-15 19:50:16 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 28
ERROR - 2021-08-15 19:50:16 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 28
ERROR - 2021-08-15 19:50:16 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 28
ERROR - 2021-08-15 19:50:16 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 28
ERROR - 2021-08-15 19:50:16 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 28
ERROR - 2021-08-15 19:50:16 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 28
ERROR - 2021-08-15 19:50:16 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 28
ERROR - 2021-08-15 19:50:16 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 28
ERROR - 2021-08-15 19:50:16 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 28
ERROR - 2021-08-15 19:50:16 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 28
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16562
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16562
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16562
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16562
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16562
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16562
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16562
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16562
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: old_cell_padding C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19807
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: old_cell_padding C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19807
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: old_cell_padding C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19807
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: old_cell_padding C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19807
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: old_cell_padding C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19807
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: old_cell_padding C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19807
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: old_cell_padding C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19807
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-15 19:52:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-15 19:52:39 --> Severity: Notice --> Undefined index: old_cell_padding C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19807
ERROR - 2021-08-15 20:01:54 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16562
ERROR - 2021-08-15 20:01:54 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16562
ERROR - 2021-08-15 20:02:42 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16562
ERROR - 2021-08-15 20:02:42 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16562
ERROR - 2021-08-15 20:15:05 --> Severity: error --> Exception: syntax error, unexpected '$modules' (T_VARIABLE) C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 32
ERROR - 2021-08-15 20:31:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 83
ERROR - 2021-08-15 20:33:26 --> Severity: Notice --> Undefined variable: row_count C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 61
ERROR - 2021-08-15 20:33:26 --> Severity: Notice --> Undefined variable: row_count C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 61

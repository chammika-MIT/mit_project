<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-07 05:31:17 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-07 05:34:38 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-07 05:34:39 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-07 05:35:07 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-07 05:38:07 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-07 05:38:08 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-07 05:39:59 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-07 05:40:00 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-07 05:40:01 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-07 05:40:26 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model C:\xampp\htdocs\EMS\system\core\Loader.php 348
ERROR - 2021-08-07 05:43:38 --> Severity: Notice --> Undefined property: User_Controller::$User_model C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 12
ERROR - 2021-08-07 05:43:38 --> Severity: error --> Exception: Call to a member function displaycourse() on null C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 12
ERROR - 2021-08-07 06:02:05 --> Severity: error --> Exception: syntax error, unexpected 'Center_Name' (T_STRING), expecting ')' C:\xampp\htdocs\EMS\application\models\UserModel.php 5
ERROR - 2021-08-07 06:17:45 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-07 06:24:49 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-07 06:26:49 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-07 06:26:50 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-07 06:57:43 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-07 07:01:59 --> 404 Page Not Found: User_Controller/add_User
ERROR - 2021-08-07 07:02:35 --> Severity: Notice --> Undefined property: User_Controller::$RegisterStudentModel C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 35
ERROR - 2021-08-07 07:02:35 --> Severity: error --> Exception: Call to a member function getTrainingCenters() on null C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 35
ERROR - 2021-08-07 07:02:59 --> Severity: Notice --> Undefined property: User_Controller::$RegisterStudentModel C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 35
ERROR - 2021-08-07 07:02:59 --> Severity: error --> Exception: Call to a member function getTrainingCenters() on null C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 35
ERROR - 2021-08-07 07:04:29 --> Severity: Notice --> Undefined variable: Staff_ID C:\xampp\htdocs\EMS\application\views\addUserView.php 28
ERROR - 2021-08-07 07:04:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\addUserView.php 28
ERROR - 2021-08-07 07:04:29 --> Severity: Notice --> Undefined property: stdClass::$Availability C:\xampp\htdocs\EMS\application\views\addUserView.php 56
ERROR - 2021-08-07 07:04:29 --> Severity: Notice --> Undefined property: stdClass::$Availability C:\xampp\htdocs\EMS\application\views\addUserView.php 60
ERROR - 2021-08-07 07:15:41 --> Severity: Notice --> Undefined variable: Staff_ID C:\xampp\htdocs\EMS\application\views\addUserView.php 28
ERROR - 2021-08-07 07:15:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\addUserView.php 28
ERROR - 2021-08-07 07:15:41 --> Severity: Notice --> Undefined property: stdClass::$Availability C:\xampp\htdocs\EMS\application\views\addUserView.php 56
ERROR - 2021-08-07 07:15:41 --> Severity: Notice --> Undefined property: stdClass::$Availability C:\xampp\htdocs\EMS\application\views\addUserView.php 60
ERROR - 2021-08-07 07:16:02 --> Severity: Notice --> Undefined property: stdClass::$Availability C:\xampp\htdocs\EMS\application\views\addUserView.php 56
ERROR - 2021-08-07 07:16:02 --> Severity: Notice --> Undefined property: stdClass::$Availability C:\xampp\htdocs\EMS\application\views\addUserView.php 60
ERROR - 2021-08-07 07:20:00 --> Severity: Notice --> Undefined property: stdClass::$Availability C:\xampp\htdocs\EMS\application\views\addUserView.php 55
ERROR - 2021-08-07 07:20:00 --> Severity: Notice --> Undefined property: stdClass::$Availability C:\xampp\htdocs\EMS\application\views\addUserView.php 57
ERROR - 2021-08-07 07:20:48 --> Severity: Notice --> Undefined property: stdClass::$Availability C:\xampp\htdocs\EMS\application\views\addUserView.php 55
ERROR - 2021-08-07 07:20:48 --> Severity: Notice --> Undefined property: stdClass::$Availability C:\xampp\htdocs\EMS\application\views\addUserView.php 57
ERROR - 2021-08-07 07:21:18 --> Severity: Notice --> Undefined property: stdClass::$Availability C:\xampp\htdocs\EMS\application\views\addUserView.php 55
ERROR - 2021-08-07 07:21:18 --> Severity: Notice --> Undefined property: stdClass::$Availability C:\xampp\htdocs\EMS\application\views\addUserView.php 57
ERROR - 2021-08-07 07:26:49 --> 404 Page Not Found: User_Controller/reg_student_validation
ERROR - 2021-08-07 07:47:19 --> Severity: error --> Exception: Call to undefined method UserModel::insert_student_data() C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 37
ERROR - 2021-08-07 07:53:58 --> Query error: Unknown column 'Confirm_Password' in 'field list' - Invalid query: INSERT INTO `users` (`TC_ID`, `STF_ID`, `Username`, `Password`, `Confirm_Password`, `Availability`) VALUES ('4', '1', 'qwe', '123', '123', '1')
ERROR - 2021-08-07 07:56:08 --> Severity: Notice --> Undefined variable: arr1 C:\xampp\htdocs\EMS\application\models\UserModel.php 29
ERROR - 2021-08-07 07:56:08 --> Query error: Unknown column 'Confirm_Password' in 'field list' - Invalid query: INSERT INTO `users` (`TC_ID`, `STF_ID`, `Username`, `Password`, `Confirm_Password`, `Availability`) VALUES ('4', '1', 'qwe', '123', '123', '1')
ERROR - 2021-08-07 07:56:53 --> Query error: Unknown column 'Confirm_Password' in 'field list' - Invalid query: INSERT INTO `users` (`TC_ID`, `STF_ID`, `Username`, `Password`, `Confirm_Password`, `Availability`) VALUES ('4', '1', 'qwe', '123', '123', '1')
ERROR - 2021-08-07 08:12:35 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\EMS\application\models\UserModel.php 11
ERROR - 2021-08-07 08:12:51 --> Severity: Notice --> Undefined property: User_Controller::$RegisterStudentModel C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 52
ERROR - 2021-08-07 08:12:51 --> Severity: error --> Exception: Call to a member function getUserById() on null C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 52
ERROR - 2021-08-07 08:13:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE User_ID=2' at line 1 - Invalid query: SELECT * FROM WHERE User_ID=2
ERROR - 2021-08-07 08:41:41 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\updateUserView.php 29
ERROR - 2021-08-07 08:41:49 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\EMS\application\views\updateUserView.php 29
ERROR - 2021-08-07 08:46:42 --> 404 Page Not Found: User_Controller/add_users
ERROR - 2021-08-07 08:47:05 --> 404 Page Not Found: User_Controller/update_users
ERROR - 2021-08-07 08:48:56 --> 404 Page Not Found: User_Controller/update_users
ERROR - 2021-08-07 08:51:06 --> Severity: Notice --> Undefined property: User_Controller::$RegisterStudentModel C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 67
ERROR - 2021-08-07 08:51:06 --> Severity: error --> Exception: Call to a member function update_student() on null C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 67
ERROR - 2021-08-07 08:59:48 --> Query error: Unknown column 'Update' in 'field list' - Invalid query: UPDATE `users` SET `TC_ID` = '4', `STF_ID` = '1', `Username` = 'qwe', `Password` = '123', `Availability` = '1', `Update` = 'Update'
ERROR - 2021-08-07 09:00:01 --> Severity: Notice --> Undefined variable: insert_id C:\xampp\htdocs\EMS\application\models\UserModel.php 51
ERROR - 2021-08-07 09:03:30 --> Severity: error --> Exception: Too few arguments to function UserModel::update_user(), 0 passed in C:\xampp\htdocs\EMS\application\controllers\User_Controller.php on line 68 and exactly 1 expected C:\xampp\htdocs\EMS\application\models\UserModel.php 42
ERROR - 2021-08-07 09:49:52 --> Severity: Notice --> Undefined property: User_Controller::$encrypt C:\xampp\htdocs\EMS\system\core\Model.php 73
ERROR - 2021-08-07 09:49:52 --> Severity: error --> Exception: Call to a member function encode() on null C:\xampp\htdocs\EMS\application\models\UserModel.php 13
ERROR - 2021-08-07 09:50:47 --> Severity: Notice --> Undefined property: CI_Loader::$encrypt C:\xampp\htdocs\EMS\application\views\updateUserView.php 45
ERROR - 2021-08-07 09:50:47 --> Severity: error --> Exception: Call to a member function decode() on null C:\xampp\htdocs\EMS\application\views\updateUserView.php 45
ERROR - 2021-08-07 09:51:41 --> Severity: Notice --> Undefined property: CI_Loader::$encrypt C:\xampp\htdocs\EMS\application\views\updateUserView.php 45
ERROR - 2021-08-07 09:51:41 --> Severity: error --> Exception: Call to a member function decode() on null C:\xampp\htdocs\EMS\application\views\updateUserView.php 45
ERROR - 2021-08-07 09:52:12 --> Severity: Notice --> Undefined property: CI_Loader::$encrypt C:\xampp\htdocs\EMS\application\views\updateUserView.php 45
ERROR - 2021-08-07 09:52:12 --> Severity: error --> Exception: Call to a member function decode() on null C:\xampp\htdocs\EMS\application\views\updateUserView.php 45
ERROR - 2021-08-07 09:52:15 --> Severity: Notice --> Undefined property: CI_Loader::$encrypt C:\xampp\htdocs\EMS\application\views\updateUserView.php 45
ERROR - 2021-08-07 09:52:15 --> Severity: error --> Exception: Call to a member function decode() on null C:\xampp\htdocs\EMS\application\views\updateUserView.php 45
ERROR - 2021-08-07 09:56:26 --> Severity: Notice --> Undefined property: User_Controller::$encrypt C:\xampp\htdocs\EMS\system\core\Model.php 73
ERROR - 2021-08-07 09:56:26 --> Severity: error --> Exception: Call to a member function encode() on null C:\xampp\htdocs\EMS\application\models\UserModel.php 51
ERROR - 2021-08-07 09:58:00 --> Severity: Notice --> Undefined property: User_Controller::$encrypt C:\xampp\htdocs\EMS\system\core\Model.php 73
ERROR - 2021-08-07 09:58:00 --> Severity: error --> Exception: Call to a member function encode() on null C:\xampp\htdocs\EMS\application\models\UserModel.php 51
ERROR - 2021-08-07 10:00:13 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\EMS\application\models\UserModel.php 51
ERROR - 2021-08-07 10:00:24 --> Severity: Notice --> Undefined property: User_Controller::$encrypt C:\xampp\htdocs\EMS\system\core\Model.php 73
ERROR - 2021-08-07 10:00:24 --> Severity: error --> Exception: Call to a member function encode() on null C:\xampp\htdocs\EMS\application\models\UserModel.php 51
ERROR - 2021-08-07 10:08:36 --> Severity: Notice --> Undefined property: User_Controller::$encrypt C:\xampp\htdocs\EMS\system\core\Model.php 73
ERROR - 2021-08-07 10:08:36 --> Severity: error --> Exception: Call to a member function encode() on null C:\xampp\htdocs\EMS\application\models\UserModel.php 51
ERROR - 2021-08-07 10:10:20 --> Severity: Notice --> Undefined property: User_Controller::$EE C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 50
ERROR - 2021-08-07 10:10:20 --> Severity: Notice --> Trying to get property 'TMPL' of non-object C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 50
ERROR - 2021-08-07 10:10:20 --> Severity: error --> Exception: Call to a member function fetch_param() on null C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 50
ERROR - 2021-08-07 10:10:33 --> Severity: Notice --> Undefined property: User_Controller::$encrypt C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 51
ERROR - 2021-08-07 10:10:33 --> Severity: error --> Exception: Call to a member function encode() on null C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 51
ERROR - 2021-08-07 10:13:08 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 51
ERROR - 2021-08-07 10:13:17 --> Severity: error --> Exception: syntax error, unexpected 'Password' (T_STRING), expecting ')' C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 53
ERROR - 2021-08-07 10:13:30 --> Severity: error --> Exception: Class 'Config\Services' not found C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 49
ERROR - 2021-08-07 17:17:16 --> Severity: error --> Exception: Call to undefined method UserModel::delete_student() C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 44
ERROR - 2021-08-07 17:20:31 --> Severity: error --> Exception: Call to undefined method UserModel::delete_student() C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 44
ERROR - 2021-08-07 17:23:52 --> 404 Page Not Found: User_Controller/add_users
ERROR - 2021-08-07 18:11:25 --> Severity: error --> Exception: Too few arguments to function User_Controller::add_user_role(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 81
ERROR - 2021-08-07 18:23:02 --> 404 Page Not Found: User_Controller/index
ERROR - 2021-08-07 18:26:41 --> Severity: error --> Exception: Too few arguments to function User_Controller::user_role(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 75
ERROR - 2021-08-07 18:29:31 --> Severity: Notice --> Undefined property: stdClass::$Username C:\xampp\htdocs\EMS\application\views\userRoleView.php 25
ERROR - 2021-08-07 18:29:31 --> Severity: Notice --> Undefined property: stdClass::$Username C:\xampp\htdocs\EMS\application\views\userRoleView.php 25
ERROR - 2021-08-07 18:32:22 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\EMS\application\views\userRoleView.php 15
ERROR - 2021-08-07 18:32:22 --> Severity: Notice --> Trying to get property 'Username' of non-object C:\xampp\htdocs\EMS\application\views\userRoleView.php 15
ERROR - 2021-08-07 18:39:13 --> Query error: Unknown column 'users.User_ID1' in 'where clause' - Invalid query: SELECT users.User_ID,user_role.Role_ID,role.Name,role.Description,staff.Name FROM user_role INNER JOIN users ON 
                user_role.User_ID=users.User_ID INNER JOIN role ON user_role.Role_ID=role.Role_ID INNER JOIN staff ON users.STF_ID=staff.STF_ID WHERE users.User_ID1
ERROR - 2021-08-07 18:40:27 --> Severity: Warning --> Use of undefined constant Name - assumed 'Name' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 78
ERROR - 2021-08-07 18:40:27 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 78
ERROR - 2021-08-07 18:49:59 --> Query error: Duplicate entry '1-3' for key 'PRIMARY' - Invalid query: INSERT INTO `user_role` (`Role_ID`, `User_Id`) VALUES ('3', '1')
ERROR - 2021-08-07 18:56:02 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::_error_message() C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 93
ERROR - 2021-08-07 19:05:02 --> Severity: Notice --> Undefined variable: Role_Id C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 96
ERROR - 2021-08-07 19:05:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'user_role.Role_ID=' at line 1 - Invalid query: SELECT user_role.User_ID FROM user_role WHERE user_role.User_ID=2AND user_role.Role_ID=
ERROR - 2021-08-07 19:05:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'user_role.Role_ID=' at line 1 - Invalid query: SELECT user_role.User_ID FROM user_role WHERE user_role.User_ID=2AND user_role.Role_ID=
ERROR - 2021-08-07 19:08:42 --> Severity: Warning --> Use of undefined constant userRoleExists - assumed 'userRoleExists' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 97
ERROR - 2021-08-07 19:08:50 --> Severity: Warning --> Use of undefined constant userRoleExists - assumed 'userRoleExists' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 97
ERROR - 2021-08-07 19:09:02 --> Severity: Warning --> Use of undefined constant userRoleExists - assumed 'userRoleExists' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 97
ERROR - 2021-08-07 19:09:06 --> Severity: Warning --> Use of undefined constant userRoleExists - assumed 'userRoleExists' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 97
ERROR - 2021-08-07 19:13:42 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\userRoleView.php 41
ERROR - 2021-08-07 19:13:42 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\userRoleView.php 41
ERROR - 2021-08-07 19:13:42 --> Severity: Notice --> Undefined property: stdClass::$STD_ID C:\xampp\htdocs\EMS\application\views\userRoleView.php 41
ERROR - 2021-08-07 19:14:50 --> Severity: error --> Exception: Too few arguments to function UserModel::delete_user_role(), 1 passed in C:\xampp\htdocs\EMS\application\controllers\User_Controller.php on line 108 and exactly 2 expected C:\xampp\htdocs\EMS\application\models\UserModel.php 69
ERROR - 2021-08-07 19:15:30 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\EMS\application\models\UserModel.php 71
ERROR - 2021-08-07 19:15:54 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\EMS\application\models\UserModel.php 71
ERROR - 2021-08-07 19:16:25 --> Severity: error --> Exception: Call to a member function result() on bool C:\xampp\htdocs\EMS\application\models\UserModel.php 71
ERROR - 2021-08-07 19:16:56 --> Severity: Notice --> Undefined variable: User_Id C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 110
ERROR - 2021-08-07 19:16:56 --> Severity: error --> Exception: Too few arguments to function User_Controller::user_role(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 75
ERROR - 2021-08-07 19:19:57 --> Severity: error --> Exception: Too few arguments to function User_Controller::user_role(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 75
ERROR - 2021-08-07 19:20:08 --> Severity: Warning --> Use of undefined constant userRoleExists - assumed 'userRoleExists' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 92
ERROR - 2021-08-07 19:20:15 --> Severity: Warning --> Use of undefined constant userRoleExists - assumed 'userRoleExists' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 92
ERROR - 2021-08-07 19:20:47 --> Severity: Warning --> Use of undefined constant userRoleExists - assumed 'userRoleExists' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 92
ERROR - 2021-08-07 19:21:21 --> Severity: Warning --> Use of undefined constant userRoleExists - assumed 'userRoleExists' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 92
ERROR - 2021-08-07 19:22:50 --> Severity: Warning --> Use of undefined constant userRoleExists - assumed 'userRoleExists' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 93
ERROR - 2021-08-07 19:36:02 --> Severity: Notice --> Undefined variable: User_Id C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 113
ERROR - 2021-08-07 19:36:03 --> Severity: error --> Exception: Too few arguments to function User_Controller::user_role(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 75
ERROR - 2021-08-07 19:36:29 --> Severity: error --> Exception: Too few arguments to function User_Controller::user_role(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 75
ERROR - 2021-08-07 19:36:30 --> Severity: error --> Exception: Too few arguments to function User_Controller::user_role(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 75
ERROR - 2021-08-07 19:37:34 --> Severity: error --> Exception: Too few arguments to function User_Controller::user_role(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 75
ERROR - 2021-08-07 19:37:35 --> Severity: error --> Exception: Too few arguments to function User_Controller::user_role(), 0 passed in C:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\EMS\application\controllers\User_Controller.php 75

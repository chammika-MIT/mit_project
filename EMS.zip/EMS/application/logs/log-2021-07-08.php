<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-08 13:07:18 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-08 13:07:18 --> Severity: Notice --> Undefined variable: Exam_course D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-08 13:07:18 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:07:18 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:07:18 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:07:18 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:07:18 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:07:18 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:07:18 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:07:18 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:07:18 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 75
ERROR - 2021-07-08 13:07:38 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-08 13:07:38 --> Severity: Notice --> Undefined variable: Exam_course D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-08 13:07:38 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:07:38 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:07:38 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:07:38 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:07:38 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:07:38 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:07:38 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:07:38 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:07:38 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 75
ERROR - 2021-07-08 13:12:28 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-08 13:12:28 --> Severity: Notice --> Undefined variable: Exam_course D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-08 13:12:28 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:12:28 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:12:29 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:12:29 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:12:29 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:12:29 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:12:29 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:12:29 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:12:29 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 75
ERROR - 2021-07-08 13:14:11 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-08 13:14:11 --> Severity: Notice --> Undefined variable: Exam_course D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-08 13:14:11 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:14:11 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:14:11 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:14:11 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:14:11 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:14:11 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:14:11 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:14:11 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:14:11 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 75
ERROR - 2021-07-08 13:15:04 --> Severity: Notice --> Undefined variable: insert_student_course_id D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 64
ERROR - 2021-07-08 13:15:04 --> Severity: Notice --> Undefined variable: insert_student_course_id D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 64
ERROR - 2021-07-08 13:15:04 --> Severity: Notice --> Undefined variable: insert_student_course_id D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 64
ERROR - 2021-07-08 13:15:04 --> Severity: Notice --> Undefined variable: insert_student_course_id D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 64
ERROR - 2021-07-08 13:15:04 --> Severity: Notice --> Undefined variable: insert_student_course_id D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 64
ERROR - 2021-07-08 13:15:04 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-08 13:15:04 --> Severity: Notice --> Undefined variable: Exam_course D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-08 13:15:04 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:15:04 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:15:04 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:15:04 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:15:04 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:15:04 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:15:04 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-08 13:15:04 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-08 13:15:04 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 75
ERROR - 2021-07-08 13:55:36 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 115
ERROR - 2021-07-08 13:59:36 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 115
ERROR - 2021-07-08 14:01:00 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 115
ERROR - 2021-07-08 14:01:02 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 115
ERROR - 2021-07-08 14:01:02 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 115
ERROR - 2021-07-08 14:01:54 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 14:07:34 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 64
ERROR - 2021-07-08 14:07:53 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 14:07:59 --> Severity: error --> Exception: Call to undefined function pint_r() D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 64
ERROR - 2021-07-08 14:08:20 --> Severity: Notice --> Undefined property: Exam_Manage_Controller::$get D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 64
ERROR - 2021-07-08 14:08:20 --> Severity: error --> Exception: Call to a member function post() on null D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 64
ERROR - 2021-07-08 14:16:38 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 14:17:13 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 97
ERROR - 2021-07-08 14:17:13 --> Severity: error --> Exception: Too few arguments to function Exam_manage_Model::getStudentExamModuleID(), 0 passed in D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php on line 49 and exactly 2 expected D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 30
ERROR - 2021-07-08 14:18:35 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 97
ERROR - 2021-07-08 14:18:35 --> Severity: Notice --> Undefined offset: 2 D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 98
ERROR - 2021-07-08 14:18:35 --> Severity: error --> Exception: Too few arguments to function Exam_manage_Model::getStudentExamModuleID(), 0 passed in D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php on line 49 and exactly 2 expected D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 30
ERROR - 2021-07-08 14:19:51 --> Severity: Notice --> Undefined variable: examID D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 96
ERROR - 2021-07-08 14:25:54 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 94
ERROR - 2021-07-08 14:32:06 --> Severity: error --> Exception: syntax error, unexpected ';' D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 97
ERROR - 2021-07-08 14:32:10 --> Severity: error --> Exception: syntax error, unexpected ';' D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 97
ERROR - 2021-07-08 14:33:28 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 14:36:36 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 14:38:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'student_exam_module.Module_ID,-,student_exam_course.ST_EX_CO_ID,-,student_exa...' at line 1 - Invalid query: SELECT CONCAT(student_exam_course.STD_ID,-,student_exam_module.Module_ID,-,student_exam_course.ST_EX_CO_ID,-,student_exam_module.ST_EX_MO_ID)  
        FROM `student_exam_course` INNER JOIN  `student_exam_module`  ON 
        student_exam_course.ST_EX_CO_ID=student_exam_module.ST_EX_CO_ID INNER JOIN student_registration ON
        student_exam_course.STD_ID = student_registration.STD_ID 
        WHERE student_exam_course.Course_ID=10 AND 
        student_registration.TC_ID =4
ERROR - 2021-07-08 14:47:18 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 14:51:40 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 58
ERROR - 2021-07-08 14:51:40 --> Severity: Notice --> Undefined variable: Array D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 58
ERROR - 2021-07-08 14:51:57 --> Severity: Notice --> Undefined index: 10-2-18-38 D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 58
ERROR - 2021-07-08 15:05:21 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 63
ERROR - 2021-07-08 15:05:49 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 63
ERROR - 2021-07-08 15:09:00 --> Severity: Notice --> Undefined variable: insert_student_course_id D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 90
ERROR - 2021-07-08 15:09:00 --> Severity: Notice --> Undefined variable: insert_student_course_id D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 90
ERROR - 2021-07-08 15:09:00 --> Severity: Notice --> Undefined variable: insert_student_course_id D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 90
ERROR - 2021-07-08 15:09:00 --> Severity: Notice --> Undefined variable: insert_student_course_id D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 90
ERROR - 2021-07-08 15:09:01 --> Severity: Notice --> Undefined variable: insert_student_course_id D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 90
ERROR - 2021-07-08 15:09:01 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 15:12:01 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 15:16:18 --> Severity: Warning --> array_diff(): Expected parameter 2 to be an array, string given D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 64
ERROR - 2021-07-08 15:35:24 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 15:35:54 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 15:35:57 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 15:37:36 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 15:39:33 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 15:40:41 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 15:40:55 --> Severity: Notice --> Undefined variable: studentMduleResult D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 51
ERROR - 2021-07-08 15:40:55 --> Severity: Notice --> Undefined variable: studentMduleResult D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 53
ERROR - 2021-07-08 15:40:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 53
ERROR - 2021-07-08 15:40:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 63
ERROR - 2021-07-08 15:40:55 --> Severity: Notice --> Undefined variable: insert_student_course_id D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 91
ERROR - 2021-07-08 15:40:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 63
ERROR - 2021-07-08 15:40:55 --> Severity: Notice --> Undefined variable: insert_student_course_id D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 91
ERROR - 2021-07-08 15:40:55 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 63
ERROR - 2021-07-08 15:40:55 --> Severity: Notice --> Undefined variable: insert_student_course_id D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 91
ERROR - 2021-07-08 15:42:06 --> Severity: Notice --> Undefined variable: insert_student_course_id D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 91
ERROR - 2021-07-08 15:42:06 --> Severity: Notice --> Undefined variable: insert_student_course_id D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 91
ERROR - 2021-07-08 15:42:06 --> Severity: Notice --> Undefined variable: insert_student_course_id D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 91
ERROR - 2021-07-08 15:45:52 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 15:46:05 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 15:52:49 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 20:14:44 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 20:16:10 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 43
ERROR - 2021-07-08 20:16:20 --> Could not find the language line "update_batch() called with no data"
ERROR - 2021-07-08 20:23:28 --> Severity: error --> Exception: Call to a member function result() on int D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 150
ERROR - 2021-07-08 20:24:03 --> Severity: error --> Exception: Call to a member function result() on int D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 150

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-17 06:44:02 --> 404 Page Not Found: Home/Staff_Register
ERROR - 2021-06-17 07:06:26 --> 404 Page Not Found: Home/Staff_Register
ERROR - 2021-06-17 07:16:09 --> 404 Page Not Found: Training_Register/trnRegister
ERROR - 2021-06-17 07:42:20 --> 404 Page Not Found: Add_institutes_Controller/add_institutes
ERROR - 2021-06-17 07:43:34 --> 404 Page Not Found: Add_institutes_Controller/add_institutes
ERROR - 2021-06-17 07:43:35 --> 404 Page Not Found: Add_institutes_Controller/add_institutes
ERROR - 2021-06-17 07:55:01 --> 404 Page Not Found: Home/Staff_Register
ERROR - 2021-06-17 08:31:48 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\training_institute_view.php 31
ERROR - 2021-06-17 08:31:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\training_institute_view.php 31
ERROR - 2021-06-17 08:32:42 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\training_institute_view.php 32
ERROR - 2021-06-17 08:32:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\training_institute_view.php 32
ERROR - 2021-06-17 08:34:42 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\training_institute_view.php 29
ERROR - 2021-06-17 08:34:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\training_institute_view.php 29
ERROR - 2021-06-17 08:34:43 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\training_institute_view.php 29
ERROR - 2021-06-17 08:34:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\training_institute_view.php 29
ERROR - 2021-06-17 08:34:44 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\training_institute_view.php 29
ERROR - 2021-06-17 08:34:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\training_institute_view.php 29
ERROR - 2021-06-17 08:41:25 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\training_institute_view.php 29
ERROR - 2021-06-17 08:41:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\training_institute_view.php 29
ERROR - 2021-06-17 08:41:28 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\training_institute_view.php 29
ERROR - 2021-06-17 08:41:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\training_institute_view.php 29
ERROR - 2021-06-17 08:41:50 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\training_institute_view.php 28
ERROR - 2021-06-17 08:41:50 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\training_institute_view.php 28
ERROR - 2021-06-17 08:43:37 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\training_institute_view.php 28
ERROR - 2021-06-17 08:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\training_institute_view.php 28
ERROR - 2021-06-17 08:43:43 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\training_institute_view.php 28
ERROR - 2021-06-17 08:43:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\training_institute_view.php 28
ERROR - 2021-06-17 08:52:21 --> 404 Page Not Found: Display_institute_controller/display_institute
ERROR - 2021-06-17 08:52:42 --> 404 Page Not Found: Display_institute_controller/display_institute
ERROR - 2021-06-17 08:52:44 --> 404 Page Not Found: Display_institute_controller/display_institute
ERROR - 2021-06-17 08:53:38 --> 404 Page Not Found: Display_institute_controller/display_institute
ERROR - 2021-06-17 08:53:42 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\training_institute_view.php 28
ERROR - 2021-06-17 08:53:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\training_institute_view.php 28
ERROR - 2021-06-17 08:55:05 --> 404 Page Not Found: Display_institutes_Controller/display_institute
ERROR - 2021-06-17 08:56:41 --> 404 Page Not Found: Display_institutes_Controller/display_institute
ERROR - 2021-06-17 08:56:43 --> 404 Page Not Found: Display_institutes_Controller/display_institute
ERROR - 2021-06-17 08:56:43 --> 404 Page Not Found: Display_institutes_Controller/display_institute
ERROR - 2021-06-17 08:56:43 --> 404 Page Not Found: Display_institutes_Controller/display_institute
ERROR - 2021-06-17 08:56:44 --> 404 Page Not Found: Display_institutes_Controller/display_institute
ERROR - 2021-06-17 08:56:44 --> 404 Page Not Found: Display_institutes_Controller/display_institute
ERROR - 2021-06-17 08:57:57 --> 404 Page Not Found: Display_institutes_Controller/display_institute
ERROR - 2021-06-17 08:58:00 --> 404 Page Not Found: Display_institutes_Controller/display_institute
ERROR - 2021-06-17 08:58:07 --> 404 Page Not Found: Display_institutes_Controller/display_institute
ERROR - 2021-06-17 08:58:27 --> 404 Page Not Found: Display_institute_Controller/display_institute
ERROR - 2021-06-17 08:58:30 --> 404 Page Not Found: Display_institute_Controller/display_institute
ERROR - 2021-06-17 08:58:30 --> 404 Page Not Found: Display_institute_Controller/display_institute
ERROR - 2021-06-17 08:58:30 --> 404 Page Not Found: Display_institute_Controller/display_institute
ERROR - 2021-06-17 08:58:31 --> 404 Page Not Found: Display_institute_Controller/display_institute
ERROR - 2021-06-17 09:00:29 --> 404 Page Not Found: Display_institute_Controller/display_institute
ERROR - 2021-06-17 09:00:33 --> 404 Page Not Found: Display_institute_Controller/display_institute
ERROR - 2021-06-17 09:00:33 --> 404 Page Not Found: Display_institute_Controller/display_institute
ERROR - 2021-06-17 09:00:33 --> 404 Page Not Found: Display_institute_Controller/display_institute
ERROR - 2021-06-17 09:00:34 --> 404 Page Not Found: Display_institute_Controller/display_institute
ERROR - 2021-06-17 09:00:34 --> 404 Page Not Found: Display_institute_Controller/display_institute
ERROR - 2021-06-17 09:00:34 --> 404 Page Not Found: Display_institute_Controller/display_institute
ERROR - 2021-06-17 09:00:37 --> Severity: error --> Exception: syntax error, unexpected '<', expecting function (T_FUNCTION) or const (T_CONST) D:\xampp\htdocs\EMS\application\controllers\Add_institutes_Controller.php 7
ERROR - 2021-06-17 09:01:24 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\training_institute_view.php 28
ERROR - 2021-06-17 09:01:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\training_institute_view.php 28
ERROR - 2021-06-17 09:01:57 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\training_institute_view.php 28
ERROR - 2021-06-17 09:01:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\training_institute_view.php 28
ERROR - 2021-06-17 09:05:19 --> Severity: error --> Exception: syntax error, unexpected '?>', expecting function (T_FUNCTION) or const (T_CONST) D:\xampp\htdocs\EMS\application\controllers\Dispay_institute_controller.php 22
ERROR - 2021-06-17 09:05:56 --> 404 Page Not Found: Dispay_institute_controller/display_institute
ERROR - 2021-06-17 09:06:04 --> 404 Page Not Found: Dispay_institute_controller/display_institute
ERROR - 2021-06-17 09:06:05 --> 404 Page Not Found: Dispay_institute_controller/display_institute
ERROR - 2021-06-17 09:06:05 --> 404 Page Not Found: Dispay_institute_controller/display_institute
ERROR - 2021-06-17 09:06:05 --> 404 Page Not Found: Dispay_institute_controller/display_institute
ERROR - 2021-06-17 09:06:12 --> 404 Page Not Found: Dispay_institute_controller/display_institute
ERROR - 2021-06-17 09:06:59 --> 404 Page Not Found: Dispay_institute_controller/display_institute
ERROR - 2021-06-17 09:07:00 --> 404 Page Not Found: Dispay_institute_controller/display_institute
ERROR - 2021-06-17 09:07:00 --> 404 Page Not Found: Dispay_institute_controller/display_institute
ERROR - 2021-06-17 09:07:07 --> 404 Page Not Found: Dispay_institute_controller/display_institute
ERROR - 2021-06-17 09:07:37 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\EMS\application\controllers\Dispay_institute_controller.php 21
ERROR - 2021-06-17 09:07:56 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\training_institute_view.php 28
ERROR - 2021-06-17 09:07:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\training_institute_view.php 28
ERROR - 2021-06-17 09:08:14 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\training_institute_view.php 28
ERROR - 2021-06-17 09:08:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\training_institute_view.php 28
ERROR - 2021-06-17 09:10:47 --> Severity: Notice --> Undefined property: stdClass::$STF_ID D:\xampp\htdocs\EMS\application\views\training_institute_view.php 36
ERROR - 2021-06-17 09:10:47 --> Severity: Notice --> Undefined property: stdClass::$STF_ID D:\xampp\htdocs\EMS\application\views\training_institute_view.php 37
ERROR - 2021-06-17 09:10:47 --> Severity: Notice --> Undefined property: stdClass::$STF_ID D:\xampp\htdocs\EMS\application\views\training_institute_view.php 36
ERROR - 2021-06-17 09:10:47 --> Severity: Notice --> Undefined property: stdClass::$STF_ID D:\xampp\htdocs\EMS\application\views\training_institute_view.php 37
ERROR - 2021-06-17 09:15:37 --> Severity: Notice --> Undefined property: Dispay_institute_controller::$DisplayStaffModel D:\xampp\htdocs\EMS\application\controllers\Dispay_institute_controller.php 18
ERROR - 2021-06-17 09:15:37 --> Severity: error --> Exception: Call to a member function delete_user() on null D:\xampp\htdocs\EMS\application\controllers\Dispay_institute_controller.php 18
ERROR - 2021-06-17 09:16:28 --> Severity: Notice --> Undefined variable: TC_ID D:\xampp\htdocs\EMS\application\controllers\Dispay_institute_controller.php 18
ERROR - 2021-06-17 09:19:40 --> Severity: Notice --> Undefined variable: TC_ID D:\xampp\htdocs\EMS\application\controllers\Dispay_institute_controller.php 18
ERROR - 2021-06-17 09:19:42 --> Severity: Notice --> Undefined variable: TC_ID D:\xampp\htdocs\EMS\application\controllers\Dispay_institute_controller.php 18
ERROR - 2021-06-17 18:28:12 --> 404 Page Not Found: Dispay_institute_controller/updatedata
ERROR - 2021-06-17 19:04:19 --> Severity: Notice --> Undefined variable: TC_ID D:\xampp\htdocs\EMS\application\controllers\Dispay_institute_controller.php 24
ERROR - 2021-06-17 19:04:19 --> Query error: Unknown column 'STF_ID' in 'where clause' - Invalid query: SELECT * FROM training_center WHERE STF_ID=''
ERROR - 2021-06-17 19:05:16 --> Query error: Unknown column 'STF_ID' in 'where clause' - Invalid query: SELECT * FROM training_center WHERE STF_ID='2'
ERROR - 2021-06-17 19:06:39 --> Severity: Notice --> Undefined property: stdClass::$Mobile D:\xampp\htdocs\EMS\application\views\Update_training_center_view.php 29
ERROR - 2021-06-17 21:03:06 --> Severity: error --> Exception: Too few arguments to function Dispay_institute_controller::updatedata(), 0 passed in D:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected D:\xampp\htdocs\EMS\application\controllers\Dispay_institute_controller.php 21
ERROR - 2021-06-17 21:36:01 --> Severity: error --> Exception: syntax error, unexpected '$TC_ID' (T_VARIABLE) D:\xampp\htdocs\EMS\application\controllers\Dispay_institute_controller.php 41
ERROR - 2021-06-17 21:51:58 --> Severity: error --> Exception: Method name must be a string D:\xampp\htdocs\EMS\application\controllers\Dispay_institute_controller.php 27

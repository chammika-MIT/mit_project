<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-25 07:40:01 --> 404 Page Not Found: Institute_reg/index.php
ERROR - 2021-06-25 07:42:50 --> 404 Page Not Found: Admin_Controller/index.php
ERROR - 2021-06-25 08:51:35 --> 404 Page Not Found: RegisterStudent_Contrroller/add_Course
ERROR - 2021-06-25 08:54:01 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 08:54:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 08:54:02 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 08:54:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 08:54:02 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 08:54:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 08:54:03 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 08:54:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 08:54:03 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 08:54:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 08:54:03 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 08:54:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 08:54:05 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 08:54:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 08:54:11 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 08:57:35 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 08:57:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\add_studentView.php 42
ERROR - 2021-06-25 09:05:54 --> 404 Page Not Found: RegisterStudent_Contrroller/add_Students
ERROR - 2021-06-25 09:07:30 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 30
ERROR - 2021-06-25 09:07:30 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\registerStudentView.php 25
ERROR - 2021-06-25 09:07:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\registerStudentView.php 25
ERROR - 2021-06-25 09:11:26 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 30
ERROR - 2021-06-25 09:11:26 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\registerStudentView.php 25
ERROR - 2021-06-25 09:11:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\registerStudentView.php 25
ERROR - 2021-06-25 09:12:46 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 30
ERROR - 2021-06-25 09:12:46 --> Severity: Notice --> Undefined variable: TC_ID D:\xampp\htdocs\EMS\application\views\add_studentView.php 43
ERROR - 2021-06-25 09:12:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\add_studentView.php 43
ERROR - 2021-06-25 11:08:43 --> Severity: error --> Exception: Call to undefined method RegisterStudentModel::insert_course_data() D:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 35
ERROR - 2021-06-25 11:09:19 --> Query error: Unknown column 'NIC' in 'field list' - Invalid query: INSERT INTO `training_center` (`NIC`, `Name`, `Year`, `Gender`, `Contact_no`, `Email`, `TC_ID`, `Avtive`) VALUES ('89567896V', 'Chammika Gunathilake', NULL, 'M', '0773630471', 'chammika@tvec.gov.lk', '1', NULL)
ERROR - 2021-06-25 11:15:28 --> Query error: Unknown column 'NIC' in 'field list' - Invalid query: INSERT INTO `training_center` (`NIC`, `Name`, `Year`, `Gender`, `Contact_no`, `Email`, `TC_ID`, `Avtive`) VALUES ('89567896V', 'Chammika Gunathilake', NULL, 'M', '0773630471', 'chammika@tvec.gov.lk', '1', NULL)
ERROR - 2021-06-25 11:21:56 --> Query error: Unknown column 'NIC' in 'field list' - Invalid query: INSERT INTO `training_center` (`NIC`, `Name`, `Year`, `Gender`, `Contact_no`, `Email`, `TC_ID`, `Avtive`) VALUES ('89567896V', 'Chammika Gunathilake', NULL, 'M', '0773630471', 'chammika@tvec.gov.lk', '1', NULL)
ERROR - 2021-06-25 11:22:45 --> Query error: Unknown column 'NIC' in 'field list' - Invalid query: INSERT INTO `training_center` (`NIC`, `Name`, `Year`, `Gender`, `Contact_no`, `Email`, `TC_ID`, `Avtive`) VALUES ('89567896V', 'Chammika Gunathilake', NULL, 'M', '0773630471', 'chammika@tvec.gov.lk', '1', NULL)
ERROR - 2021-06-25 11:23:40 --> Query error: Unknown column 'NIC' in 'field list' - Invalid query: INSERT INTO `training_center` (`NIC`, `Name`, `Gender`, `Contact_no`, `Email`, `TC_ID`, `Avtive`) VALUES ('89567896V', 'Chammika Gunathilake', 'M', '0773630471', 'chammika@tvec.gov.lk', '1', NULL)
ERROR - 2021-06-25 11:25:37 --> Query error: Unknown column 'NIC' in 'field list' - Invalid query: INSERT INTO `training_center` (`NIC`, `Name`, `Gender`, `Contact_no`, `Email`, `TC_ID`, `Avtive`) VALUES ('89567896V', 'Chammika Gunathilake', 'M', '0773630471', 'chammika@tvec.gov.lk', '1', NULL)
ERROR - 2021-06-25 11:29:14 --> Query error: Unknown column 'NIC' in 'field list' - Invalid query: INSERT INTO `training_center` (`NIC`, `Name`, `Gender`, `Contact_no`, `Email`, `TC_ID`, `Avtive`) VALUES ('89567896V', 'Chammika Gunathilake', 'M', '0773630471', 'chammika@tvec.gov.lk', '1', NULL)
ERROR - 2021-06-25 11:29:34 --> Query error: Unknown column 'NIC' in 'field list' - Invalid query: INSERT INTO `training_center` (`NIC`, `Name`, `Gender`, `Contact_no`, `Email`, `TC_ID`, `Avtive`) VALUES ('89567896V', 'Chammika Gunathilake', 'F', '0773630471', 'chammika@tvec.gov.lk', '1', NULL)
ERROR - 2021-06-25 11:32:00 --> Query error: Unknown column 'NIC' in 'field list' - Invalid query: INSERT INTO `training_center` (`NIC`, `Name`, `Gender`, `Contact_no`, `Email`, `TC_ID`, `Avtive`) VALUES ('89567896V', 'Chammika Gunathilake', 'M', '0773630471', 'chammika@tvec.gov.lk', '1', NULL)
ERROR - 2021-06-25 11:35:40 --> Query error: Unknown column 'NIC' in 'field list' - Invalid query: INSERT INTO `training_center` (`NIC`, `Name`, `Gender`, `Contact_no`, `Email`, `TC_ID`, `Avtive`) VALUES ('89567896V', 'Chammika Gunathilake', 'M', '0773630471', 'chammika@tvec.gov.lk', '1', NULL)
ERROR - 2021-06-25 11:37:23 --> Query error: Unknown column 'NIC' in 'field list' - Invalid query: INSERT INTO `training_center` (`NIC`, `Name`, `Gender`, `Contact_no`, `Email`, `TC_ID`, `Avtive`) VALUES ('89567896V', 'Chammika Gunathilake', 'M', '0773630471', 'chammika@tvec.gov.lk', '1', '1')
ERROR - 2021-06-25 11:48:25 --> Query error: Unknown column 'Std_NIC' in 'field list' - Invalid query: INSERT INTO `training_center` (`Std_NIC`, `Name`, `Gender`, `Contact_no`, `Email`, `TC_ID`, `Avtive`) VALUES ('89567896V', 'Chammika Gunathilake', 'M', '0773630471', 'chammika@tvec.gov.lk', '1', '1')
ERROR - 2021-06-25 12:00:19 --> Query error: Unknown column 'Avtive' in 'field list' - Invalid query: INSERT INTO `student_registration` (`Std_NIC`, `Name`, `Gender`, `Contact_no`, `Email`, `TC_ID`, `Avtive`) VALUES ('8925681V', 'Chammika Gunathilake', 'M', '0773630471', 'chammika@tvec.gov.lk', '1', '1')
ERROR - 2021-06-25 12:03:03 --> Severity: Notice --> Undefined property: stdClass::$NIC D:\xampp\htdocs\EMS\application\views\registerStudentView.php 27
ERROR - 2021-06-25 12:03:03 --> Severity: Notice --> Undefined property: stdClass::$Year D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-06-25 12:03:03 --> Severity: Notice --> Undefined property: stdClass::$Avtive D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-06-25 12:03:03 --> Severity: Notice --> Undefined property: stdClass::$Exam_ID D:\xampp\htdocs\EMS\application\views\registerStudentView.php 36
ERROR - 2021-06-25 12:03:03 --> Severity: Notice --> Undefined property: stdClass::$Exam_ID D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-06-25 12:03:50 --> Severity: Notice --> Undefined property: stdClass::$Year D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-06-25 12:03:50 --> Severity: Notice --> Undefined property: stdClass::$Avtive D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-06-25 12:03:50 --> Severity: Notice --> Undefined property: stdClass::$Exam_ID D:\xampp\htdocs\EMS\application\views\registerStudentView.php 36
ERROR - 2021-06-25 12:03:50 --> Severity: Notice --> Undefined property: stdClass::$Exam_ID D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-06-25 12:04:15 --> Severity: Notice --> Undefined property: stdClass::$Exam_ID D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-06-25 12:04:15 --> Severity: Notice --> Undefined property: stdClass::$Exam_ID D:\xampp\htdocs\EMS\application\views\registerStudentView.php 36
ERROR - 2021-06-25 13:11:12 --> 404 Page Not Found: RegisterStudent_Contrroller/updatestudent
ERROR - 2021-06-25 13:18:01 --> Severity: Notice --> Undefined property: RegisterStudent_Contrroller::$AddCourseModule_model D:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 63
ERROR - 2021-06-25 13:18:01 --> Severity: error --> Exception: Call to a member function update_course() on null D:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 63
ERROR - 2021-06-25 13:19:23 --> Query error: Unknown column 'Reg_No' in 'field list' - Invalid query: INSERT INTO `student_registration` (`Std_NIC`, `Name`, `Gender`, `Contact_no`, `Email`, `Reg_No`, `Active`) VALUES ('89103203V', 'Chammika Gunathilake', 'M', '0773630471', 'chammika@tvec.gov.lk', 'P01/0023', '1')
ERROR - 2021-06-25 13:23:22 --> Severity: Notice --> Undefined property: RegisterStudent_Contrroller::$AddCourseModule_model D:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 63
ERROR - 2021-06-25 13:23:22 --> Severity: error --> Exception: Call to a member function update_course() on null D:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 63
ERROR - 2021-06-25 13:33:29 --> 404 Page Not Found: CRegisterStudent_Contrroller/registerStudents
ERROR - 2021-06-25 13:44:04 --> Severity: Notice --> Undefined property: RegisterStudent_Contrroller::$AddCourseModule_model D:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 67
ERROR - 2021-06-25 13:44:04 --> Severity: error --> Exception: Call to a member function update_student() on null D:\xampp\htdocs\EMS\application\controllers\RegisterStudent_Contrroller.php 67
ERROR - 2021-06-25 13:47:01 --> Severity: Notice --> Undefined variable: STD_ID D:\xampp\htdocs\EMS\application\models\RegisterStudentModel.php 41
ERROR - 2021-06-25 13:47:17 --> Severity: Notice --> Undefined variable: STD_ID D:\xampp\htdocs\EMS\application\models\RegisterStudentModel.php 41
ERROR - 2021-06-25 13:53:28 --> Severity: Notice --> Undefined variable: STD_ID D:\xampp\htdocs\EMS\application\models\RegisterStudentModel.php 41
ERROR - 2021-06-25 13:57:50 --> Severity: error --> Exception: Call to a member function result() on bool D:\xampp\htdocs\EMS\application\models\RegisterStudentModel.php 42

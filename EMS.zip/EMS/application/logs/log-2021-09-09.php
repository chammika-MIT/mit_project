<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-09 13:57:56 --> Severity: error --> Exception: Call to a member function result() on bool D:\xampp\htdocs\EMS\application\models\View_institute_model.php 22
ERROR - 2021-09-09 14:00:52 --> Severity: error --> Exception: Call to a member function result() on bool D:\xampp\htdocs\EMS\application\models\View_institute_model.php 22
ERROR - 2021-09-09 14:09:17 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\EMS\application\controllers\Institute_reg.php 43
ERROR - 2021-09-09 14:09:39 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\EMS\application\controllers\Institute_reg.php 43
ERROR - 2021-09-09 14:11:44 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\EMS\application\controllers\Institute_reg.php 44
ERROR - 2021-09-09 14:12:02 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\EMS\application\controllers\Institute_reg.php 44
ERROR - 2021-09-09 14:44:32 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\EMS\application\controllers\Institute_reg.php 44
ERROR - 2021-09-09 14:44:39 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\EMS\application\controllers\Institute_reg.php 44
ERROR - 2021-09-09 14:46:47 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\EMS\application\controllers\Institute_reg.php 45
ERROR - 2021-09-09 15:00:06 --> 404 Page Not Found: Update_training_center_view/index
ERROR - 2021-09-09 15:01:01 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\EMS\application\controllers\Institute_reg.php 45
ERROR - 2021-09-09 15:06:18 --> Severity: error --> Exception: Too few arguments to function Institute_reg::updatedata(), 0 passed in D:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected D:\xampp\htdocs\EMS\application\controllers\Institute_reg.php 23

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-22 08:14:33 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16549
ERROR - 2021-08-22 08:14:33 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16549
ERROR - 2021-08-22 08:14:33 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16549
ERROR - 2021-08-22 08:14:33 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16549
ERROR - 2021-08-22 08:14:33 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16549
ERROR - 2021-08-22 08:14:33 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16549
ERROR - 2021-08-22 08:32:24 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16562
ERROR - 2021-08-22 08:32:24 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-22 08:32:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-22 08:32:24 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-22 08:32:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-22 08:32:24 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-22 08:32:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-22 08:32:24 --> Severity: Notice --> Undefined index: old_cell_padding C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19807
ERROR - 2021-08-22 08:32:48 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16562
ERROR - 2021-08-22 08:32:48 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-22 08:32:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19565
ERROR - 2021-08-22 08:32:48 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-22 08:32:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19594
ERROR - 2021-08-22 08:32:48 --> Severity: Notice --> Undefined index: trids C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-22 08:32:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19597
ERROR - 2021-08-22 08:32:48 --> Severity: Notice --> Undefined index: old_cell_padding C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19807
ERROR - 2021-08-22 08:52:28 --> Severity: Notice --> Undefined index: rows C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16980
ERROR - 2021-08-22 08:52:28 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16982
ERROR - 2021-08-22 08:52:28 --> Severity: Notice --> Undefined index: thead C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16549
ERROR - 2021-08-22 08:52:28 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18252
ERROR - 2021-08-22 09:22:37 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 7
ERROR - 2021-08-22 09:23:51 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 7
ERROR - 2021-08-22 09:24:18 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 7
ERROR - 2021-08-22 09:24:29 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 7
ERROR - 2021-08-22 09:24:45 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 8
ERROR - 2021-08-22 09:26:44 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 8
ERROR - 2021-08-22 09:29:02 --> Severity: Notice --> Undefined variable: dd C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 8
ERROR - 2021-08-22 09:38:11 --> Severity: error --> Exception: syntax error, unexpected '';' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf_autoconfig.php 107
ERROR - 2021-08-22 09:58:08 --> Severity: Notice --> Undefined variable: pdf C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 12
ERROR - 2021-08-22 09:58:08 --> Severity: error --> Exception: Call to a member function Image() on null C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 12
ERROR - 2021-08-22 09:58:22 --> Severity: Notice --> Undefined variable: x C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 12
ERROR - 2021-08-22 09:58:22 --> Severity: Notice --> Undefined variable: y C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 12
ERROR - 2021-08-22 09:58:22 --> Severity: Notice --> Undefined variable: w C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 12
ERROR - 2021-08-22 09:58:22 --> Severity: Notice --> Undefined variable: h C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 12
ERROR - 2021-08-22 09:58:22 --> Severity: Notice --> Undefined variable: fitbox C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 12
ERROR - 2021-08-22 10:01:48 --> Severity: Notice --> Undefined variable: pdf C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 18
ERROR - 2021-08-22 10:01:48 --> Severity: error --> Exception: Call to a member function setPrintHeader() on null C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 18
ERROR - 2021-08-22 10:19:22 --> Severity: error --> Exception: syntax error, unexpected '1' (T_LNUMBER) C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 5
ERROR - 2021-08-22 10:24:28 --> Severity: Warning --> imagecreatefromjpeg(): gd-jpeg: JPEG library reports unrecoverable error: Not a JPEG file: starts with 0x89 0x50 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 7066
ERROR - 2021-08-22 10:24:28 --> Severity: Warning --> imagecreatefromjpeg(): 'images/admission_header.png' is not a valid JPEG file C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 7066
ERROR - 2021-08-22 10:24:56 --> Severity: Warning --> imagecreatefromjpeg(): gd-jpeg: JPEG library reports unrecoverable error: Not a JPEG file: starts with 0x89 0x50 C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 7066
ERROR - 2021-08-22 10:24:56 --> Severity: Warning --> imagecreatefromjpeg(): 'images/admission_header.png' is not a valid JPEG file C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 7066
ERROR - 2021-08-22 10:36:57 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 12
ERROR - 2021-08-22 10:45:26 --> Severity: Notice --> Undefined variable: headerdata C:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 3416
ERROR - 2021-08-22 10:50:17 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 13
ERROR - 2021-08-22 12:00:31 --> Severity: Notice --> Undefined variable: pdf C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 22
ERROR - 2021-08-22 12:00:31 --> Severity: error --> Exception: Call to a member function setPrintFooter() on null C:\xampp\htdocs\EMS\application\views\examAdmissionPDF.php 22
ERROR - 2021-08-22 12:14:42 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 12:14:42 --> Severity: Notice --> Undefined variable: Course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 9
ERROR - 2021-08-22 12:14:42 --> Severity: Notice --> Undefined variable: TC_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 9
ERROR - 2021-08-22 12:14:42 --> Severity: Notice --> Undefined variable: Module_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 9
ERROR - 2021-08-22 12:14:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\EMS\application\views\examScheduleView.php 17
ERROR - 2021-08-22 12:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\examScheduleView.php 17
ERROR - 2021-08-22 12:14:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\EMS\application\views\examScheduleView.php 42
ERROR - 2021-08-22 12:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\examScheduleView.php 42
ERROR - 2021-08-22 12:32:20 --> 404 Page Not Found: Exam_Manage_Controller/add_exam_schedule
ERROR - 2021-08-22 12:32:26 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 12:32:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\EMS\application\views\examScheduleView.php 61
ERROR - 2021-08-22 12:32:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\EMS\application\views\examScheduleView.php 61
ERROR - 2021-08-22 12:47:40 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 12:51:00 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 12:54:25 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 12:54:36 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 12:55:22 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 13:03:21 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ')' C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 368
ERROR - 2021-08-22 13:04:12 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ')' C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 367
ERROR - 2021-08-22 13:04:30 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 13:04:38 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 13:05:51 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 13:05:59 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 13:06:22 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 13:07:30 --> 404 Page Not Found: Exam_Manage_Controller/selectCenter
ERROR - 2021-08-22 13:07:34 --> 404 Page Not Found: Exam_Manage_Controller/selectCenter
ERROR - 2021-08-22 13:07:57 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 13:09:29 --> Severity: Notice --> Undefined variable: training C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 222
ERROR - 2021-08-22 13:09:29 --> Severity: Notice --> Undefined variable: training C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 223
ERROR - 2021-08-22 13:09:29 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 13:09:51 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `exam_schedule` (`Exam_ID`, `Course_ID`, `Module_ID`, `Date_Time`) VALUES ('1', '5', '3', '2021-08-23T20:38')
ERROR - 2021-08-22 13:10:22 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 13:10:33 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 13:11:02 --> 404 Page Not Found: Exam_Manage_Controller/selectCenter
ERROR - 2021-08-22 13:11:07 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 13:11:36 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 13:12:05 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `exam_schedule` (`Exam_ID`, `Course_ID`, `Module_ID`, `Date_Time`) VALUES ('1', '3', '3', '2021-08-26T21:44')
ERROR - 2021-08-22 13:13:31 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 13:13:36 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-22 13:14:15 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7

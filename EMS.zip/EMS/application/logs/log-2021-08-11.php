<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-11 17:17:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 18
ERROR - 2021-08-11 17:18:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 18
ERROR - 2021-08-11 17:25:01 --> Severity: Warning --> require_once(tcpdf/config/lang/eng.php): failed to open stream: No such file or directory C:\xampp\htdocs\EMS\application\helpers\pdf_helper.php 4
ERROR - 2021-08-11 17:25:01 --> Severity: Compile Error --> require_once(): Failed opening required 'tcpdf/config/lang/eng.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\EMS\application\helpers\pdf_helper.php 4

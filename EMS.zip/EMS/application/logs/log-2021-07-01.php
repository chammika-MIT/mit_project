<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-01 06:17:05 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' D:\xampp\htdocs\EMS\application\views\assignexamView.php 29
ERROR - 2021-07-01 06:30:57 --> Severity: Compile Error --> Can't use function return value in write context D:\xampp\htdocs\EMS\application\views\assignexamView.php 31
ERROR - 2021-07-01 06:31:51 --> Severity: Compile Error --> Can't use function return value in write context D:\xampp\htdocs\EMS\application\views\assignexamView.php 31
ERROR - 2021-07-01 06:32:41 --> Severity: Compile Error --> Can't use function return value in write context D:\xampp\htdocs\EMS\application\views\assignexamView.php 31
ERROR - 2021-07-01 08:59:17 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 09:01:12 --> Severity: Notice --> Trying to get property 'Course_code' of non-object D:\xampp\htdocs\EMS\application\views\assignexamView.php 9
ERROR - 2021-07-01 10:07:08 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:07:10 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:07:33 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:09:38 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:10:18 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:10:20 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:10:21 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:10:21 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:10:21 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:10:21 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:10:24 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:11:01 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:11:02 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:11:02 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:11:02 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:11:02 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:11:02 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:11:03 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:11:03 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:11:03 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 10:16:04 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 37
ERROR - 2021-07-01 10:16:05 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 37
ERROR - 2021-07-01 10:16:05 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 37
ERROR - 2021-07-01 10:16:05 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 37
ERROR - 2021-07-01 10:16:05 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 37
ERROR - 2021-07-01 10:16:05 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 37
ERROR - 2021-07-01 13:20:20 --> Severity: error --> Exception: syntax error, unexpected '*' D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 44
ERROR - 2021-07-01 13:20:21 --> Severity: error --> Exception: syntax error, unexpected '*' D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 44
ERROR - 2021-07-01 14:00:55 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 14:01:21 --> Severity: error --> Exception: syntax error, unexpected '=' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 14:01:23 --> Severity: error --> Exception: syntax error, unexpected '=' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 14:02:06 --> Severity: error --> Exception: syntax error, unexpected ',' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 18
ERROR - 2021-07-01 14:03:35 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 19
ERROR - 2021-07-01 17:43:05 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 39
ERROR - 2021-07-01 17:44:43 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 42
ERROR - 2021-07-01 17:44:57 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 42
ERROR - 2021-07-01 17:45:19 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 42
ERROR - 2021-07-01 18:03:10 --> Severity: error --> Exception: syntax error, unexpected '?>', expecting function (T_FUNCTION) or const (T_CONST) D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 29
ERROR - 2021-07-01 18:27:45 --> Severity: Notice --> session_start(): A session had already been started - ignoring D:\xampp\htdocs\EMS\application\views\createExamView.php 6
ERROR - 2021-07-01 18:27:45 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\EMS\application\views\createExamView.php 9
ERROR - 2021-07-01 18:27:45 --> Severity: Notice --> Trying to get property 'Exam_ID' of non-object D:\xampp\htdocs\EMS\application\views\createExamView.php 9
ERROR - 2021-07-01 18:28:14 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\EMS\application\views\createExamView.php 9
ERROR - 2021-07-01 18:28:14 --> Severity: Notice --> Trying to get property 'Exam_ID' of non-object D:\xampp\htdocs\EMS\application\views\createExamView.php 9
ERROR - 2021-07-01 19:13:12 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::result() D:\xampp\htdocs\EMS\application\models\RegisterStudentModel.php 17
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:08 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Undefined property: mysqli::$Std_NIC D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Undefined property: mysqli::$Name D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Undefined property: mysqli::$Gender D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Undefined property: mysqli::$Contact_no D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Undefined property: mysqli::$Email D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Undefined property: mysqli::$TC_ID D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Undefined property: mysqli::$Course_ID D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Undefined property: mysqli::$Active D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Undefined property: mysqli::$STD_ID D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Undefined property: mysqli::$STD_ID D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Std_NIC' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 28
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Name' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 29
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Contact_no' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Email' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 32
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'TC_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 33
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 34
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'Active' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 35
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 37
ERROR - 2021-07-01 19:16:09 --> Severity: Notice --> Trying to get property 'STD_ID' of non-object D:\xampp\htdocs\EMS\application\views\registerStudentView.php 38

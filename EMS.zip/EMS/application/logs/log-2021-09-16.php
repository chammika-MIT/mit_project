<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-16 07:37:11 --> Severity: Notice --> Undefined index: User_ID  D:\xampp\htdocs\EMS\application\models\UserModel.php 73
ERROR - 2021-09-16 07:37:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Delete_Center'' at line 2 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID WHERE user_role.User_ID= AND component.Path='Delete_Center'
ERROR - 2021-09-16 07:42:24 --> Severity: error --> Exception: syntax error, unexpected 'P00' (T_STRING), expecting ')' D:\xampp\htdocs\EMS\application\models\ManageInstituteModel.php 27
ERROR - 2021-09-16 07:56:50 --> Severity: Warning --> Illegal offset type in isset or empty D:\xampp\htdocs\EMS\application\controllers\ManageInstituteController.php 44
ERROR - 2021-09-16 08:24:22 --> Severity: Notice --> Undefined property: stdClass::$Course_name D:\xampp\htdocs\EMS\application\views\updateStudentView.php 50
ERROR - 2021-09-16 08:25:56 --> Severity: Notice --> Undefined property: stdClass::$Course_name D:\xampp\htdocs\EMS\application\views\updateStudentView.php 50
ERROR - 2021-09-16 08:29:45 --> Severity: Notice --> Undefined variable: row1 D:\xampp\htdocs\EMS\application\views\updateStudentView.php 48
ERROR - 2021-09-16 08:29:45 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateStudentView.php 48
ERROR - 2021-09-16 08:29:45 --> Severity: Notice --> Undefined variable: row1 D:\xampp\htdocs\EMS\application\views\updateStudentView.php 48
ERROR - 2021-09-16 08:29:45 --> Severity: Notice --> Trying to get property 'Course_ID' of non-object D:\xampp\htdocs\EMS\application\views\updateStudentView.php 48
ERROR - 2021-09-16 08:30:46 --> Severity: Notice --> Undefined property: stdClass::$Course_ID D:\xampp\htdocs\EMS\application\views\updateStudentView.php 48
ERROR - 2021-09-16 08:30:46 --> Severity: Notice --> Undefined property: stdClass::$Course_ID D:\xampp\htdocs\EMS\application\views\updateStudentView.php 48
ERROR - 2021-09-16 09:17:26 --> Severity: Notice --> Undefined property: stdClass::$Course_ID D:\xampp\htdocs\EMS\application\views\updateStudentView.php 48
ERROR - 2021-09-16 09:17:26 --> Severity: Notice --> Undefined property: stdClass::$Course_ID D:\xampp\htdocs\EMS\application\views\updateStudentView.php 48
ERROR - 2021-09-16 09:17:26 --> Severity: Notice --> Undefined property: stdClass::$TC_ID D:\xampp\htdocs\EMS\application\views\updateStudentView.php 76
ERROR - 2021-09-16 09:24:53 --> Severity: Notice --> Undefined property: stdClass::$Contact_no D:\xampp\htdocs\EMS\application\views\updateStudentView.php 39
ERROR - 2021-09-16 09:24:53 --> Severity: Notice --> Undefined property: stdClass::$TC_ID D:\xampp\htdocs\EMS\application\views\updateStudentView.php 69
ERROR - 2021-09-16 09:25:40 --> Severity: Notice --> Undefined property: stdClass::$TC_ID D:\xampp\htdocs\EMS\application\views\updateStudentView.php 69
ERROR - 2021-09-16 09:41:21 --> Severity: Notice --> Undefined property: stdClass::$Center D:\xampp\htdocs\EMS\application\views\updateStudentView.php 61
ERROR - 2021-09-16 09:41:21 --> Severity: Notice --> Undefined property: stdClass::$Active D:\xampp\htdocs\EMS\application\views\updateStudentView.php 65
ERROR - 2021-09-16 09:41:21 --> Severity: Notice --> Undefined property: stdClass::$Active D:\xampp\htdocs\EMS\application\views\updateStudentView.php 67
ERROR - 2021-09-16 09:43:14 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file D:\xampp\htdocs\EMS\application\views\updateStudentView.php 73
ERROR - 2021-09-16 09:45:20 --> Severity: Notice --> Undefined property: stdClass::$Center D:\xampp\htdocs\EMS\application\views\updateStudentView.php 61
ERROR - 2021-09-16 09:45:20 --> Severity: Notice --> Undefined property: stdClass::$Active D:\xampp\htdocs\EMS\application\views\updateStudentView.php 65
ERROR - 2021-09-16 09:45:20 --> Severity: Notice --> Undefined property: stdClass::$Active D:\xampp\htdocs\EMS\application\views\updateStudentView.php 67
ERROR - 2021-09-16 10:25:05 --> Severity: Notice --> Undefined variable: Add_Institute D:\xampp\htdocs\EMS\application\views\updateStudentView.php 20
ERROR - 2021-09-16 10:25:36 --> Severity: Notice --> Undefined variable: Add_Institute D:\xampp\htdocs\EMS\application\views\updateStudentView.php 20
ERROR - 2021-09-16 12:01:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '=1' at line 1 - Invalid query: SELECT * FROM training_center WHERE=1
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 12:39:44 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-16 13:01:48 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-16 13:10:56 --> Severity: Notice --> Undefined variable: total D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-16 13:10:56 --> Severity: Notice --> Undefined variable: total D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-16 13:10:56 --> Severity: Notice --> Undefined variable: total D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-16 13:10:56 --> Severity: Notice --> Undefined variable: total D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-16 13:10:56 --> Severity: Notice --> Undefined variable: total D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-16 13:10:56 --> Severity: Notice --> Undefined variable: total D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-16 13:10:56 --> Severity: Notice --> Undefined variable: total D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-16 13:10:56 --> Severity: Notice --> Undefined variable: total D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-16 13:10:56 --> Severity: Notice --> Undefined variable: total D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-16 13:11:33 --> Severity: Notice --> Undefined variable: total D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-16 13:11:35 --> Severity: Notice --> Undefined variable: total D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-16 13:14:30 --> Severity: Notice --> Undefined index: module_amount D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 20
ERROR - 2021-09-16 13:14:30 --> Severity: Notice --> Undefined variable: total D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 20
ERROR - 2021-09-16 13:24:00 --> Severity: error --> Exception: Call to undefined function mysql_fetch_assoc() D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 19
ERROR - 2021-09-16 13:24:01 --> Severity: error --> Exception: Call to undefined function mysql_fetch_assoc() D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 19
ERROR - 2021-09-16 13:25:09 --> Severity: Notice --> Undefined variable: row D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 20
ERROR - 2021-09-16 13:25:36 --> Severity: Notice --> Undefined index: module_amount D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 20
ERROR - 2021-09-16 13:26:38 --> Severity: Notice --> Undefined index: module_amount D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 20
ERROR - 2021-09-16 13:30:13 --> Severity: Notice --> Undefined index: module_amount D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 19
ERROR - 2021-09-16 13:31:39 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 19
ERROR - 2021-09-16 13:31:40 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 19
ERROR - 2021-09-16 13:31:40 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 19
ERROR - 2021-09-16 13:31:41 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 19
ERROR - 2021-09-16 14:05:48 --> Severity: Notice --> Undefined variable: staffTC D:\xampp\htdocs\EMS\application\views\addStaffView.php 67
ERROR - 2021-09-16 14:05:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addStaffView.php 67
ERROR - 2021-09-16 14:11:59 --> Severity: Notice --> Undefined variable: staffTC D:\xampp\htdocs\EMS\application\views\addStaffView.php 67
ERROR - 2021-09-16 14:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addStaffView.php 67
ERROR - 2021-09-16 14:13:32 --> Severity: Notice --> Undefined variable: staffTC D:\xampp\htdocs\EMS\application\views\addStaffView.php 67
ERROR - 2021-09-16 14:13:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addStaffView.php 67
ERROR - 2021-09-16 14:35:54 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:35:54 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:35:54 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:35:54 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:35:54 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:35:54 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:35:54 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:35:54 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:35:54 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:35:54 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:35:54 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:35:54 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:35:54 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:35:54 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:35:54 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:35:54 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:35:54 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:37:51 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:37:51 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:37:51 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:37:51 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:37:51 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:37:51 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:37:51 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:37:51 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:37:51 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:37:51 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:37:51 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:37:51 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:37:51 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:37:51 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:37:51 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:37:51 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:37:51 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:25 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:25 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:25 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:25 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:25 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:25 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:25 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:25 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:25 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:25 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:25 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:25 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:25 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:25 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:25 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:25 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:25 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:44 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:44 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:44 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:44 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:44 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:44 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:44 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:44 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:44 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:44 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:44 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:44 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:44 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:44 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:44 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:44 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 14:39:44 --> Severity: Notice --> Undefined property: stdClass::$TC_IDff_Type D:\xampp\htdocs\EMS\application\views\updateStaffView.php 80
ERROR - 2021-09-16 16:05:14 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-16 16:05:40 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-16 16:29:59 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-16 17:02:46 --> Severity: Warning --> Use of undefined constant Total - assumed 'Total' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\examFees.php 43
ERROR - 2021-09-16 17:21:53 --> Query error: Unknown column 'ExamFeeController' in 'where clause' - Invalid query: SELECT training_center.TC_ID, training_center.Name, student_exam_course.Course_ID, 
        course.Course_name, student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount ,
        sum(exam_fee_rate.Amount) as `module_amount`  FROM student_exam_course INNER JOIN 
        student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID
        INNER JOIN course ON  student_exam_course.Course_ID = course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID WHERE student_exam_course.Exam_ID=ExamFeeController
        AND student_registration.TC_ID=vttt GROUP BY student_exam_module.Module_ID  
        ORDER BY `module`.`Module_name` ASC
ERROR - 2021-09-16 17:22:32 --> Query error: Unknown column 'ExamFeeController' in 'where clause' - Invalid query: SELECT training_center.TC_ID, training_center.Name, student_exam_course.Course_ID, 
        course.Course_name, student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount ,
        sum(exam_fee_rate.Amount) as `module_amount`  FROM student_exam_course INNER JOIN 
        student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID
        INNER JOIN course ON  student_exam_course.Course_ID = course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID WHERE student_exam_course.Exam_ID=ExamFeeController
        AND student_registration.TC_ID=vttt GROUP BY student_exam_module.Module_ID  
        ORDER BY `module`.`Module_name` ASC
ERROR - 2021-09-16 17:23:53 --> Query error: Unknown column 'ExamFeeController' in 'where clause' - Invalid query: SELECT training_center.TC_ID, training_center.Name, student_exam_course.Course_ID, 
        course.Course_name, student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount ,
        sum(exam_fee_rate.Amount) as `module_amount`  FROM student_exam_course INNER JOIN 
        student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID
        INNER JOIN course ON  student_exam_course.Course_ID = course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID WHERE student_exam_course.Exam_ID=ExamFeeController
        AND student_registration.TC_ID=vttt GROUP BY student_exam_module.Module_ID  
        ORDER BY `module`.`Module_name` ASC
ERROR - 2021-09-16 17:24:11 --> Query error: Unknown column 'ExamFeeController' in 'where clause' - Invalid query: SELECT training_center.TC_ID, training_center.Name, student_exam_course.Course_ID, 
        course.Course_name, student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount ,
        sum(exam_fee_rate.Amount) as `module_amount`  FROM student_exam_course INNER JOIN 
        student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID
        INNER JOIN course ON  student_exam_course.Course_ID = course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID WHERE student_exam_course.Exam_ID=ExamFeeController
        AND student_registration.TC_ID=vttt GROUP BY student_exam_module.Module_ID  
        ORDER BY `module`.`Module_name` ASC
ERROR - 2021-09-16 17:29:25 --> 404 Page Not Found: Upload/do_upload
ERROR - 2021-09-16 17:30:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
   ...' at line 12 - Invalid query: SELECT training_center.TC_ID, training_center.Name, student_exam_course.Course_ID, 
        course.Course_name, student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount ,
        sum(exam_fee_rate.Amount) as `module_amount`  FROM student_exam_course INNER JOIN 
        student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID
        INNER JOIN course ON  student_exam_course.Course_ID = course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID WHERE student_exam_course.Exam_ID=
        AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
        ORDER BY `module`.`Module_name` ASC
ERROR - 2021-09-16 17:33:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
   ...' at line 12 - Invalid query: SELECT training_center.TC_ID, training_center.Name, student_exam_course.Course_ID, 
        course.Course_name, student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount ,
        sum(exam_fee_rate.Amount) as `module_amount`  FROM student_exam_course INNER JOIN 
        student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID
        INNER JOIN course ON  student_exam_course.Course_ID = course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID WHERE student_exam_course.Exam_ID=
        AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
        ORDER BY `module`.`Module_name` ASC
ERROR - 2021-09-16 17:35:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
   ...' at line 12 - Invalid query: SELECT training_center.TC_ID, training_center.Name, student_exam_course.Course_ID, 
        course.Course_name, student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount ,
        sum(exam_fee_rate.Amount) as `module_amount`  FROM student_exam_course INNER JOIN 
        student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID
        INNER JOIN course ON  student_exam_course.Course_ID = course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID WHERE student_exam_course.Exam_ID=
        AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
        ORDER BY `module`.`Module_name` ASC
ERROR - 2021-09-16 17:37:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
   ...' at line 12 - Invalid query: SELECT training_center.TC_ID, training_center.Name, student_exam_course.Course_ID, 
        course.Course_name, student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount ,
        sum(exam_fee_rate.Amount) as `module_amount`  FROM student_exam_course INNER JOIN 
        student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID
        INNER JOIN course ON  student_exam_course.Course_ID = course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID WHERE student_exam_course.Exam_ID=
        AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
        ORDER BY `module`.`Module_name` ASC
ERROR - 2021-09-16 17:44:25 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 17:44:59 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 17:45:50 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 17:46:00 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 17:47:25 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 17:47:50 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 17:50:52 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 17:51:17 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 17:57:24 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 17:58:19 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 17:59:18 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 18:03:04 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 18:04:13 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 18:09:22 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 18:11:19 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 18:11:26 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 18:11:39 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 18:17:00 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 18:20:39 --> Severity: Notice --> Undefined property: ExamFeeController::$upload D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 37
ERROR - 2021-09-16 18:20:39 --> Severity: error --> Exception: Call to a member function initialize() on null D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 37
ERROR - 2021-09-16 18:20:50 --> Severity: Notice --> Undefined property: ExamFeeController::$upload D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 37
ERROR - 2021-09-16 18:20:50 --> Severity: error --> Exception: Call to a member function initialize() on null D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 37
ERROR - 2021-09-16 18:21:39 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 18:21:50 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 18:25:01 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 18:25:55 --> The upload path does not appear to be valid.
ERROR - 2021-09-16 19:39:51 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\EMS\application\views\upload_form.php 7
ERROR - 2021-09-16 19:41:28 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\EMS\application\views\upload_form.php 7
ERROR - 2021-09-16 19:41:44 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\EMS\application\views\upload_form.php 7
ERROR - 2021-09-16 19:57:49 --> Severity: Notice --> Undefined index: userfiles D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 48
ERROR - 2021-09-16 19:59:51 --> Severity: Notice --> Undefined variable: new_name D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 37
ERROR - 2021-09-16 20:07:15 --> Severity: Notice --> Undefined variable: config D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 32
ERROR - 2021-09-16 20:07:15 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 34
ERROR - 2021-09-16 20:07:15 --> Severity: Notice --> Undefined variable: new_name D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 41
ERROR - 2021-09-16 20:30:16 --> Severity: Notice --> Undefined index: userfiles D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 32
ERROR - 2021-09-16 20:31:23 --> Severity: Notice --> Undefined index: userfiles D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 32
ERROR - 2021-09-16 20:58:28 --> Severity: Notice --> Undefined index: userfile D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 33
ERROR - 2021-09-16 21:29:06 --> 404 Page Not Found: ExamFeeController/do_uploadSOFT%20IT%20training
ERROR - 2021-09-16 21:32:24 --> Severity: Notice --> Undefined index: userfile D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 33
ERROR - 2021-09-16 21:36:01 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\examFees.php 17
ERROR - 2021-09-16 21:36:01 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\examFees.php 19
ERROR - 2021-09-16 21:36:01 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-16 21:36:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-16 21:37:36 --> Severity: Notice --> Undefined variable: TC_Id D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 59
ERROR - 2021-09-16 21:37:36 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 59
ERROR - 2021-09-16 21:37:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
   ...' at line 12 - Invalid query: SELECT training_center.TC_ID, training_center.Name, student_exam_course.Course_ID, 
        course.Course_name, student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount ,
        sum(exam_fee_rate.Amount) as `module_amount`  FROM student_exam_course INNER JOIN 
        student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID
        INNER JOIN course ON  student_exam_course.Course_ID = course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID WHERE student_exam_course.Exam_ID=
        AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
        ORDER BY `module`.`Module_name` ASC
ERROR - 2021-09-16 21:38:30 --> Severity: Notice --> Undefined variable: TC_Id D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 59
ERROR - 2021-09-16 21:38:30 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 59
ERROR - 2021-09-16 21:38:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
   ...' at line 12 - Invalid query: SELECT training_center.TC_ID, training_center.Name, student_exam_course.Course_ID, 
        course.Course_name, student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount ,
        sum(exam_fee_rate.Amount) as `module_amount`  FROM student_exam_course INNER JOIN 
        student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID
        INNER JOIN course ON  student_exam_course.Course_ID = course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID WHERE student_exam_course.Exam_ID=
        AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
        ORDER BY `module`.`Module_name` ASC
ERROR - 2021-09-16 21:42:58 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\examFees.php 17
ERROR - 2021-09-16 21:42:58 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\examFees.php 19
ERROR - 2021-09-16 21:42:58 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-16 21:42:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-16 21:49:56 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\EMS\application\views\examFeesView.php 55

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-18 20:03:21 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:03:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:04:51 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:04:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:04:52 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:04:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:04:53 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:04:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:04:53 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:04:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:06:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:06:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:09:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:09:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:11:00 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:11:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:11:01 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:11:01 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:14:20 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:14:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:14:30 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:14:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:14:31 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:14:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 69
ERROR - 2021-06-18 20:17:37 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:17:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:18:08 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:18:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:18:37 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:18:43 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:18:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:22:49 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:22:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:22:51 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:22:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:27:56 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:27:56 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:27:58 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:28:47 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:28:47 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:28:47 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:28:49 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:28:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:28:52 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:28:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:29:28 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:29:58 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:29:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:30:10 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:30:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:30:58 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:30:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:30:59 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:31:05 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:31:05 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:31:06 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:31:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:31:14 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:31:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 68
ERROR - 2021-06-18 20:42:20 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\institute_reg.php 24
ERROR - 2021-06-18 20:42:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 24
ERROR - 2021-06-18 20:43:10 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\institute_reg.php 24
ERROR - 2021-06-18 20:43:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 24
ERROR - 2021-06-18 20:43:25 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\institute_reg.php 24
ERROR - 2021-06-18 20:43:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 24
ERROR - 2021-06-18 20:44:41 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\institute_reg.php 24
ERROR - 2021-06-18 20:44:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\institute_reg.php 24
ERROR - 2021-06-18 20:49:39 --> 404 Page Not Found: Institute_reg/updatedata
ERROR - 2021-06-18 21:46:51 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 21:47:39 --> Severity: error --> Exception: syntax error, unexpected '}', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 21:47:40 --> Severity: error --> Exception: syntax error, unexpected '}', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 21:48:24 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' D:\xampp\htdocs\EMS\application\views\institute_reg.php 34
ERROR - 2021-06-18 21:48:25 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' D:\xampp\htdocs\EMS\application\views\institute_reg.php 34
ERROR - 2021-06-18 21:48:25 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' D:\xampp\htdocs\EMS\application\views\institute_reg.php 34
ERROR - 2021-06-18 21:48:25 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' D:\xampp\htdocs\EMS\application\views\institute_reg.php 34
ERROR - 2021-06-18 21:49:03 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' D:\xampp\htdocs\EMS\application\views\institute_reg.php 34
ERROR - 2021-06-18 21:49:04 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' D:\xampp\htdocs\EMS\application\views\institute_reg.php 34
ERROR - 2021-06-18 21:49:04 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' D:\xampp\htdocs\EMS\application\views\institute_reg.php 34
ERROR - 2021-06-18 21:49:43 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 21:49:44 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 21:49:44 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 21:49:44 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 21:50:03 --> Severity: error --> Exception: syntax error, unexpected '?' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 21:50:04 --> Severity: error --> Exception: syntax error, unexpected '?' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 21:50:27 --> Severity: error --> Exception: syntax error, unexpected 'anchor' (T_STRING), expecting ',' or ';' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 21:50:28 --> Severity: error --> Exception: syntax error, unexpected 'anchor' (T_STRING), expecting ',' or ';' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 21:50:28 --> Severity: error --> Exception: syntax error, unexpected 'anchor' (T_STRING), expecting ',' or ';' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 21:58:42 --> Severity: error --> Exception: syntax error, unexpected ';', expecting '(' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 21:58:43 --> Severity: error --> Exception: syntax error, unexpected ';', expecting '(' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 21:58:43 --> Severity: error --> Exception: syntax error, unexpected ';', expecting '(' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:00:47 --> Severity: error --> Exception: syntax error, unexpected ';', expecting '(' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:00:48 --> Severity: error --> Exception: syntax error, unexpected ';', expecting '(' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:00:48 --> Severity: error --> Exception: syntax error, unexpected ';', expecting '(' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:00:48 --> Severity: error --> Exception: syntax error, unexpected ';', expecting '(' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:00:52 --> Severity: error --> Exception: syntax error, unexpected ';', expecting '(' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:00:57 --> Severity: error --> Exception: syntax error, unexpected ';', expecting '(' D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:01:32 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:01:33 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:01:33 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:01:54 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:01:55 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:01:55 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:01:55 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:01:56 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:04:56 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:04:57 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:04:57 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:04:57 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:04:58 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:04:58 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:04:58 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:04:58 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:04:58 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:04:59 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:04:59 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file D:\xampp\htdocs\EMS\application\views\institute_reg.php 33
ERROR - 2021-06-18 22:14:38 --> Severity: Warning --> Use of undefined constant TC_ID - assumed 'TC_ID' (this will throw an Error in a future version of PHP) D:\xampp\htdocs\EMS\application\views\Update_training_center_view.php 8
ERROR - 2021-06-18 22:15:23 --> Severity: Notice --> Undefined variable: TC_ID D:\xampp\htdocs\EMS\application\views\Update_training_center_view.php 8
ERROR - 2021-06-18 22:17:27 --> Severity: error --> Exception: Too few arguments to function Institute_reg::updatedata(), 0 passed in D:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 1 expected D:\xampp\htdocs\EMS\application\controllers\Institute_reg.php 21
ERROR - 2021-06-18 22:18:26 --> Severity: Notice --> Undefined variable: TC_ID D:\xampp\htdocs\EMS\application\views\Update_training_center_view.php 8
ERROR - 2021-06-18 22:25:40 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ')' D:\xampp\htdocs\EMS\application\views\institute_reg.php 31
ERROR - 2021-06-18 22:25:41 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ')' D:\xampp\htdocs\EMS\application\views\institute_reg.php 31
ERROR - 2021-06-18 22:56:47 --> Severity: error --> Exception: Call to a member function orderBy() on array D:\xampp\htdocs\EMS\application\models\View_institute_model.php 9
ERROR - 2021-06-18 22:56:48 --> Severity: error --> Exception: Call to a member function orderBy() on array D:\xampp\htdocs\EMS\application\models\View_institute_model.php 9
ERROR - 2021-06-18 22:57:20 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::orderBy() D:\xampp\htdocs\EMS\application\models\View_institute_model.php 9
ERROR - 2021-06-18 22:57:21 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::orderBy() D:\xampp\htdocs\EMS\application\models\View_institute_model.php 9
ERROR - 2021-06-18 22:57:22 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::orderBy() D:\xampp\htdocs\EMS\application\models\View_institute_model.php 9

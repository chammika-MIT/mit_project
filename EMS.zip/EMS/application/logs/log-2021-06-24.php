<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-24 06:54:01 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\views\addModule_view.php 18
ERROR - 2021-06-24 06:54:06 --> Severity: error --> Exception: syntax error, unexpected '<' D:\xampp\htdocs\EMS\application\views\addModule_view.php 18
ERROR - 2021-06-24 06:58:49 --> Severity: Notice --> Undefined variable: moduledata D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 85
ERROR - 2021-06-24 09:21:58 --> Severity: Notice --> Undefined variable: Course_code D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 65
ERROR - 2021-06-24 09:22:39 --> Severity: error --> Exception: Too few arguments to function AddCourseModule_model::displaymodulebyCourseCode(), 0 passed in D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php on line 65 and exactly 1 expected D:\xampp\htdocs\EMS\application\models\AddCourseModule_model.php 51
ERROR - 2021-06-24 09:23:30 --> Severity: Notice --> Undefined variable: Course_code D:\xampp\htdocs\EMS\application\models\AddCourseModule_model.php 52
ERROR - 2021-06-24 09:25:06 --> Severity: error --> Exception: syntax error, unexpected ')', expecting '(' D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 64
ERROR - 2021-06-24 09:25:07 --> Severity: error --> Exception: syntax error, unexpected ')', expecting '(' D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 64
ERROR - 2021-06-24 09:25:11 --> Severity: error --> Exception: syntax error, unexpected ')', expecting '(' D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 64
ERROR - 2021-06-24 09:25:13 --> Severity: error --> Exception: syntax error, unexpected ')', expecting '(' D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 64
ERROR - 2021-06-24 09:25:18 --> Severity: error --> Exception: syntax error, unexpected ')', expecting '(' D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 64
ERROR - 2021-06-24 09:25:18 --> Severity: error --> Exception: syntax error, unexpected ')', expecting '(' D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 64
ERROR - 2021-06-24 09:25:33 --> Severity: error --> Exception: syntax error, unexpected ')', expecting '(' D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 64
ERROR - 2021-06-24 09:25:34 --> Severity: error --> Exception: syntax error, unexpected ')', expecting '(' D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 64
ERROR - 2021-06-24 09:25:34 --> Severity: error --> Exception: syntax error, unexpected ')', expecting '(' D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 64
ERROR - 2021-06-24 09:25:48 --> Severity: error --> Exception: syntax error, unexpected ')', expecting '(' D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 64
ERROR - 2021-06-24 09:26:19 --> Severity: Notice --> Undefined variable: Course_code D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 65
ERROR - 2021-06-24 14:17:11 --> Severity: error --> Exception: syntax error, unexpected '<', expecting function (T_FUNCTION) or const (T_CONST) D:\xampp\htdocs\EMS\application\controllers\CreateExamController.php 13
ERROR - 2021-06-24 14:18:03 --> Severity: error --> Exception: syntax error, unexpected '<', expecting function (T_FUNCTION) or const (T_CONST) D:\xampp\htdocs\EMS\application\models\CreateExamModel.php 12
ERROR - 2021-06-24 19:55:01 --> Severity: error --> Exception: syntax error, unexpected ''AppOpenDate'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\EMS\application\models\CreateExamModel.php 19
ERROR - 2021-06-24 19:56:29 --> Query error: Unknown column 'AppOpenDate' in 'field list' - Invalid query: INSERT INTO `create_exam` (`level`, `semester`, `year`, `AppOpenDate`, `AppCloseDate`, `ExamStartDate`, `ExamEndDate`) VALUES ('5', '1', '2021', '2021-06-30', '2021-07-08', '2021-07-31', '2021-08-07')
ERROR - 2021-06-24 20:00:17 --> Severity: Notice --> Undefined property: stdClass::$Reg_No D:\xampp\htdocs\EMS\application\views\createExamView.php 29
ERROR - 2021-06-24 20:00:17 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\createExamView.php 30
ERROR - 2021-06-24 20:00:17 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\createExamView.php 31
ERROR - 2021-06-24 20:00:17 --> Severity: Notice --> Undefined property: stdClass::$Email D:\xampp\htdocs\EMS\application\views\createExamView.php 32
ERROR - 2021-06-24 20:00:17 --> Severity: Notice --> Undefined property: stdClass::$ContactNo D:\xampp\htdocs\EMS\application\views\createExamView.php 33
ERROR - 2021-06-24 20:00:17 --> Severity: Notice --> Undefined property: stdClass::$TC_ID D:\xampp\htdocs\EMS\application\views\createExamView.php 35
ERROR - 2021-06-24 20:00:17 --> Severity: Notice --> Undefined property: stdClass::$TC_ID D:\xampp\htdocs\EMS\application\views\createExamView.php 36
ERROR - 2021-06-24 20:12:24 --> Severity: error --> Exception: Call to undefined method CreateExamModel::add_Exam() D:\xampp\htdocs\EMS\application\controllers\CreateExamController.php 32
ERROR - 2021-06-24 20:13:31 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `create_exam` (`Level`, `Semester`, `Year`, `Application_start_date`, `Application_end_date`, `Exam_start_date`, `Exam_end_date`) VALUES ('5', '6', '2021', '2021-06-25', '2021-06-30', '2021-07-03', '2021-07-09')
ERROR - 2021-06-24 20:14:06 --> 404 Page Not Found: CreateExamController/addExamView
ERROR - 2021-06-24 20:14:36 --> 404 Page Not Found: CreateExamController/addExamView
ERROR - 2021-06-24 20:14:37 --> 404 Page Not Found: CreateExamController/addExamView
ERROR - 2021-06-24 20:14:38 --> 404 Page Not Found: CreateExamController/addExamView
ERROR - 2021-06-24 20:14:38 --> 404 Page Not Found: CreateExamController/addExamView
ERROR - 2021-06-24 20:19:16 --> Severity: Notice --> Undefined property: CreateExamController::$AddCourseModule_model D:\xampp\htdocs\EMS\application\controllers\CreateExamController.php 44
ERROR - 2021-06-24 20:19:16 --> Severity: error --> Exception: Call to a member function delete_course() on null D:\xampp\htdocs\EMS\application\controllers\CreateExamController.php 44
ERROR - 2021-06-24 20:21:42 --> Severity: Notice --> Undefined property: CreateExamController::$AddCourseModule_model D:\xampp\htdocs\EMS\application\controllers\CreateExamController.php 44
ERROR - 2021-06-24 20:21:42 --> Severity: error --> Exception: Call to a member function delete_course() on null D:\xampp\htdocs\EMS\application\controllers\CreateExamController.php 44
ERROR - 2021-06-24 20:52:40 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\xampp\htdocs\EMS\application\views\updateExamView.php 13
ERROR - 2021-06-24 20:53:59 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\xampp\htdocs\EMS\application\views\updateExamView.php 13
ERROR - 2021-06-24 20:56:17 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\xampp\htdocs\EMS\application\views\updateExamView.php 13
ERROR - 2021-06-24 20:56:31 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\xampp\htdocs\EMS\application\views\updateExamView.php 13
ERROR - 2021-06-24 20:57:15 --> Severity: error --> Exception: syntax error, unexpected ''checked'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' D:\xampp\htdocs\EMS\application\views\updateExamView.php 13
ERROR - 2021-06-24 20:57:16 --> Severity: error --> Exception: syntax error, unexpected ''checked'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' D:\xampp\htdocs\EMS\application\views\updateExamView.php 13
ERROR - 2021-06-24 20:57:16 --> Severity: error --> Exception: syntax error, unexpected ''checked'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' D:\xampp\htdocs\EMS\application\views\updateExamView.php 13
ERROR - 2021-06-24 20:57:24 --> Severity: error --> Exception: syntax error, unexpected ''checked'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' D:\xampp\htdocs\EMS\application\views\updateExamView.php 13
ERROR - 2021-06-24 20:58:15 --> Severity: Notice --> Undefined property: stdClass::$Module_code D:\xampp\htdocs\EMS\application\views\updateExamView.php 28
ERROR - 2021-06-24 20:58:15 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\updateExamView.php 32
ERROR - 2021-06-24 20:58:36 --> Severity: Notice --> Undefined property: stdClass::$Module_code D:\xampp\htdocs\EMS\application\views\updateExamView.php 28
ERROR - 2021-06-24 20:58:36 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\updateExamView.php 32
ERROR - 2021-06-24 20:58:43 --> Severity: Notice --> Undefined property: stdClass::$Module_code D:\xampp\htdocs\EMS\application\views\updateExamView.php 28
ERROR - 2021-06-24 20:58:43 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\updateExamView.php 32
ERROR - 2021-06-24 20:58:48 --> Severity: Notice --> Undefined property: stdClass::$Module_code D:\xampp\htdocs\EMS\application\views\updateExamView.php 28
ERROR - 2021-06-24 20:58:48 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\updateExamView.php 32
ERROR - 2021-06-24 20:59:17 --> Severity: Notice --> Undefined property: stdClass::$Module_code D:\xampp\htdocs\EMS\application\views\updateExamView.php 28
ERROR - 2021-06-24 20:59:17 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\updateExamView.php 32
ERROR - 2021-06-24 21:00:26 --> Severity: Notice --> Undefined property: stdClass::$Module_code D:\xampp\htdocs\EMS\application\views\updateExamView.php 28
ERROR - 2021-06-24 21:00:26 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\updateExamView.php 32
ERROR - 2021-06-24 21:04:29 --> Severity: Notice --> Undefined property: stdClass::$Module_code D:\xampp\htdocs\EMS\application\views\updateExamView.php 44
ERROR - 2021-06-24 21:04:29 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\updateExamView.php 48
ERROR - 2021-06-24 21:05:16 --> Severity: Notice --> Undefined property: stdClass::$Module_code D:\xampp\htdocs\EMS\application\views\updateExamView.php 44
ERROR - 2021-06-24 21:05:16 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\updateExamView.php 48
ERROR - 2021-06-24 21:12:24 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\updateExamView.php 50
ERROR - 2021-06-24 21:12:35 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\updateExamView.php 50
ERROR - 2021-06-24 21:26:51 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\models\CreateExamModel.php 37
ERROR - 2021-06-24 21:27:10 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\models\CreateExamModel.php 37
ERROR - 2021-06-24 21:28:19 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\models\CreateExamModel.php 37
ERROR - 2021-06-24 21:29:46 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\models\CreateExamModel.php 37
ERROR - 2021-06-24 21:29:57 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\models\CreateExamModel.php 37
ERROR - 2021-06-24 21:43:46 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 15
ERROR - 2021-06-24 21:43:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 15
ERROR - 2021-06-24 21:50:25 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:50:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:50:26 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:50:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:50:26 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:50:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:50:27 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:50:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:50:41 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:50:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:51:04 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:51:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:52:25 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:52:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:52:32 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:52:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:53:52 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:53:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:56:58 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:56:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:59:44 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:59:44 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:59:45 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 21:59:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 22:02:38 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:02:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:02:39 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:02:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:02:40 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:02:40 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:02:51 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:02:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:10:26 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:10:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:11:18 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:11:18 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:13:59 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:13:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:14:00 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:14:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:14:00 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:14:00 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:16:26 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\addModule_view.php 15
ERROR - 2021-06-24 22:16:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addModule_view.php 15
ERROR - 2021-06-24 22:18:02 --> Severity: Notice --> Undefined property: stdClass::$Course_name D:\xampp\htdocs\EMS\application\views\updateModuleView.php 14
ERROR - 2021-06-24 22:20:38 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:20:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:20:39 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:20:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:20:39 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:20:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:28:29 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:28:30 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:28:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:28:30 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:28:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:33:16 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:33:16 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:33:17 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:33:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:33:17 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:33:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:33:25 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:33:25 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:35:47 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:35:47 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:35:48 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:35:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:35:48 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:35:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:36:14 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:36:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:36:15 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:36:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:36:15 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:36:15 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:36:21 --> Severity: Notice --> Undefined variable: code D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13
ERROR - 2021-06-24 22:36:21 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\updateModuleView.php 13

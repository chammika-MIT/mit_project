<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Exam_course D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 75
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Exam_course D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 17:55:21 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 75
ERROR - 2021-07-07 17:56:44 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\EMS\system\database\DB_query_builder.php 1542
ERROR - 2021-07-07 17:56:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Array' at line 1 - Invalid query: INSERT INTO `student_exam_module` () VALUES ('1','0','0','1','8','9'), Array
ERROR - 2021-07-07 18:04:30 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 18:04:30 --> Severity: Notice --> Undefined variable: Exam_course D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 18:04:30 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 18:04:30 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 18:04:30 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 18:04:30 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 18:04:30 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 18:04:30 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 18:04:30 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 18:04:30 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 18:04:30 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 75
ERROR - 2021-07-07 18:06:09 --> Query error: Duplicate entry '9' for key 'PRIMARY' - Invalid query: INSERT INTO `student_exam_module` (`Is_assign`, `Is_attend`, `Is_repeat`, `Module_ID`, `ST_EX_CO_ID`, `ST_EX_MO_ID`) VALUES ('1','0','0','1','8','9'), ('1','0','0','1','8','9'), ('1','0','0','2','9','10'), ('1','0','0','2','9','10')
ERROR - 2021-07-07 18:13:07 --> Query error: Duplicate entry '9' for key 'PRIMARY' - Invalid query: INSERT INTO `student_exam_module` (`Is_assign`, `Is_attend`, `Is_repeat`, `Module_ID`, `ST_EX_CO_ID`, `ST_EX_MO_ID`) VALUES ('1','0','0','1','8','9'), ('1','0','0','1','8','9'), ('1','0','0','2','9','10'), ('1','0','0','2','9','10')
ERROR - 2021-07-07 18:14:23 --> Query error: Duplicate entry '9' for key 'PRIMARY' - Invalid query: INSERT INTO `student_exam_module` (`Is_assign`, `Is_attend`, `Is_repeat`, `Module_ID`, `ST_EX_CO_ID`, `ST_EX_MO_ID`) VALUES ('1','0','0','1','8','9'), ('1','0','0','1','8','9'), ('1','0','0','2','9','10'), ('1','0','0','2','9','10')
ERROR - 2021-07-07 18:15:17 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\EMS\system\database\DB_query_builder.php 1542
ERROR - 2021-07-07 18:15:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Array' at line 1 - Invalid query: INSERT INTO `student_exam_module` () VALUES ('1','0','0','1','8','9'), Array
ERROR - 2021-07-07 18:17:34 --> Query error: Duplicate entry '9' for key 'PRIMARY' - Invalid query: INSERT INTO `student_exam_module` (`Is_assign`, `Is_attend`, `Is_repeat`, `Module_ID`, `ST_EX_CO_ID`, `ST_EX_MO_ID`) VALUES ('1','0','0','1','8','9'), ('1','0','0','1','8','9'), ('1','0','0','2','9','10'), ('1','0','0','2','9','10')
ERROR - 2021-07-07 18:26:59 --> Severity: error --> Exception: syntax error, unexpected '}' D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 83
ERROR - 2021-07-07 18:27:17 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\EMS\system\database\DB_query_builder.php 1542
ERROR - 2021-07-07 18:27:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Array' at line 1 - Invalid query: INSERT INTO `student_exam_module` () VALUES ('1','0','0','1','8','9'), Array
ERROR - 2021-07-07 18:29:51 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 18:29:51 --> Severity: Notice --> Undefined variable: Exam_course D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 18:29:51 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 18:29:51 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 18:29:51 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 18:29:51 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 18:29:51 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 18:29:51 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 18:29:51 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 18:29:51 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 18:29:51 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 75
ERROR - 2021-07-07 18:38:12 --> Query error: Duplicate entry '16' for key 'PRIMARY' - Invalid query: INSERT INTO `student_exam_module` (`ST_EX_MO_ID`) VALUES ('16'), ('17')
ERROR - 2021-07-07 18:48:37 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 18:48:37 --> Severity: Notice --> Undefined variable: Exam_course D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 18:48:37 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 18:48:37 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 18:48:37 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 18:48:37 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 18:48:37 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 18:48:37 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 18:48:37 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 18:48:37 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 18:48:37 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 75
ERROR - 2021-07-07 18:48:54 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 18:48:54 --> Severity: Notice --> Undefined variable: Exam_course D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 18:48:54 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 18:48:54 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 18:48:54 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 18:48:54 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 18:48:54 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 18:48:54 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 18:48:54 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 18:48:54 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 18:48:54 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 75
ERROR - 2021-07-07 19:04:49 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 19:04:49 --> Severity: Notice --> Undefined variable: Exam_course D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 19:04:49 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 19:04:49 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 19:04:49 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 19:04:49 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 19:04:49 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 19:04:49 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 19:04:49 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 19:04:49 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 19:04:49 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 75
ERROR - 2021-07-07 19:05:10 --> Severity: Notice --> Undefined variable: std_Ex_module_insert D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 84
ERROR - 2021-07-07 19:05:10 --> Severity: Notice --> Undefined variable: std_Ex_module_insert D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 84
ERROR - 2021-07-07 19:07:34 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 19:07:34 --> Severity: Notice --> Undefined variable: Exam_course D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 19:07:34 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 19:07:34 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 19:07:34 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 19:07:34 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 19:07:34 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 19:07:34 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 19:07:34 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 19:07:34 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 19:07:34 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 75
ERROR - 2021-07-07 19:18:10 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 19:18:10 --> Severity: Notice --> Undefined variable: Exam_course D:\xampp\htdocs\EMS\application\views\selectexamView.php 18
ERROR - 2021-07-07 19:18:10 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 19:18:10 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 19:18:10 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 19:18:10 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 19:18:10 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 19:18:10 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 19:18:10 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 40
ERROR - 2021-07-07 19:18:10 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\selectexamView.php 47
ERROR - 2021-07-07 19:18:10 --> Severity: Notice --> Undefined variable: data1 D:\xampp\htdocs\EMS\application\views\selectexamView.php 75
ERROR - 2021-07-07 19:21:54 --> Could not find the language line "insert_batch() called with no data"
ERROR - 2021-07-07 19:22:32 --> Severity: Notice --> Undefined variable: studentExamcourse D:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 91
ERROR - 2021-07-07 19:22:32 --> Could not find the language line "insert_batch() called with no data"
ERROR - 2021-07-07 19:22:58 --> Could not find the language line "insert_batch() called with no data"

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-15 07:59:53 --> 404 Page Not Found: ManageInstituteModel/inst_reg
ERROR - 2021-09-15 08:00:41 --> 404 Page Not Found: ManageInstituteModel/inst_reg
ERROR - 2021-09-15 08:00:43 --> 404 Page Not Found: ManageInstituteModel/inst_reg
ERROR - 2021-09-15 08:00:45 --> 404 Page Not Found: ManageInstituteModel/inst_reg
ERROR - 2021-09-15 08:14:42 --> Severity: error --> Exception: Unable to locate the model you have specified: UserModel D:\xampp\htdocs\EMS\system\core\Loader.php 348
ERROR - 2021-09-15 08:14:43 --> Severity: error --> Exception: Unable to locate the model you have specified: UserModel D:\xampp\htdocs\EMS\system\core\Loader.php 348
ERROR - 2021-09-15 08:14:43 --> Severity: error --> Exception: Unable to locate the model you have specified: UserModel D:\xampp\htdocs\EMS\system\core\Loader.php 348
ERROR - 2021-09-15 08:30:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Login_model D:\xampp\htdocs\EMS\system\core\Loader.php 348
ERROR - 2021-09-15 08:31:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Login_model D:\xampp\htdocs\EMS\system\core\Loader.php 348
ERROR - 2021-09-15 08:31:47 --> Severity: error --> Exception: Unable to locate the model you have specified: Login_model D:\xampp\htdocs\EMS\system\core\Loader.php 348
ERROR - 2021-09-15 15:39:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Add_institute_model D:\xampp\htdocs\EMS\system\core\Loader.php 348
ERROR - 2021-09-15 16:53:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-09-15 16:53:59 --> Severity: Notice --> Undefined index: rows D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16981
ERROR - 2021-09-15 16:53:59 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16983
ERROR - 2021-09-15 16:53:59 --> Severity: Notice --> Undefined index: thead D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16563
ERROR - 2021-09-15 16:53:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:53:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:53:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:53:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:53:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:53:59 --> Severity: Notice --> Undefined variable: cellspacingx D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18179
ERROR - 2021-09-15 16:53:59 --> Severity: Notice --> Undefined variable: cellspacing D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18246
ERROR - 2021-09-15 16:53:59 --> Severity: Notice --> Undefined variable: cellspacing D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18272
ERROR - 2021-09-15 16:53:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-09-15 16:53:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:53:59 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:56:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-09-15 16:56:26 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:57:08 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-09-15 16:57:08 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-15 16:59:02 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-15 17:24:14 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\examFees.php 28
ERROR - 2021-09-15 17:24:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\examFees.php 28
ERROR - 2021-09-15 17:25:37 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\examFees.php 28
ERROR - 2021-09-15 17:25:37 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\examFees.php 28
ERROR - 2021-09-15 17:27:57 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\examFees.php 9
ERROR - 2021-09-15 17:27:57 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\examFees.php 10
ERROR - 2021-09-15 17:27:57 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:29:08 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\examFees.php 9
ERROR - 2021-09-15 17:29:08 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\examFees.php 29
ERROR - 2021-09-15 17:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\examFees.php 29
ERROR - 2021-09-15 17:29:10 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\examFees.php 9
ERROR - 2021-09-15 17:29:10 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\examFees.php 29
ERROR - 2021-09-15 17:29:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\examFees.php 29
ERROR - 2021-09-15 17:29:29 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\examFees.php 28
ERROR - 2021-09-15 17:29:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\examFees.php 28
ERROR - 2021-09-15 17:30:35 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\examFees.php 28
ERROR - 2021-09-15 17:30:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\examFees.php 28
ERROR - 2021-09-15 17:31:43 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\examFees.php 28
ERROR - 2021-09-15 17:31:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\examFees.php 28
ERROR - 2021-09-15 17:33:26 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\examFees.php 27
ERROR - 2021-09-15 17:33:26 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\examFees.php 27
ERROR - 2021-09-15 17:49:13 --> Query error: Unknown column '$Exam_ID' in 'where clause' - Invalid query: SELECT student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount,
        sum(exam_fee_rate.Amount) as `module_amount`  FROM student_exam_course 
        INNER JOIN student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module
        ON student_exam_module.Module_ID = module.Module_ID  
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID 
        AND student_exam_module.Module_ID = exam_fee_rate.Module_ID 
        WHERE student_exam_course.Exam_ID=$Exam_ID AND student_registration.TC_ID=1 
        GROUP BY student_exam_module.Module_ID
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 29
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 29
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 29
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 29
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 29
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 29
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 29
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 29
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 29
ERROR - 2021-09-15 17:54:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Name D:\xampp\htdocs\EMS\application\views\examFees.php 30
ERROR - 2021-09-15 17:55:01 --> Severity: Notice --> Undefined property: stdClass::$Address D:\xampp\htdocs\EMS\application\views\examFees.php 31
ERROR - 2021-09-15 18:05:52 --> Severity: error --> Exception: Too few arguments to function ExamFeeModel::displayexamfee(), 0 passed in D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php on line 13 and exactly 2 expected D:\xampp\htdocs\EMS\application\models\ExamFeeModel.php 4
ERROR - 2021-09-15 18:18:07 --> Severity: error --> Exception: Too few arguments to function ExamFeeModel::displayexamfee(), 0 passed in D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php on line 13 and exactly 2 expected D:\xampp\htdocs\EMS\application\models\ExamFeeModel.php 4
ERROR - 2021-09-15 18:19:19 --> Severity: Notice --> Undefined variable: TC_Id D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 13
ERROR - 2021-09-15 18:19:19 --> Severity: Notice --> Undefined variable: Exam_Id D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 13
ERROR - 2021-09-15 18:19:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
   ...' at line 12 - Invalid query: SELECT training_center.TC_ID, training_center.Name, student_exam_course.Course_ID, 
        course.Course_name, student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount ,
        sum(exam_fee_rate.Amount) as `module_amount`  FROM student_exam_course INNER JOIN 
        student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID
        INNER JOIN course ON  student_exam_course.Course_ID = course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID WHERE student_exam_course.Exam_ID=
        AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
        ORDER BY `module`.`Module_name` ASC
ERROR - 2021-09-15 18:19:46 --> Severity: error --> Exception: Too few arguments to function ExamFeeController::viewExamFee(), 1 passed in D:\xampp\htdocs\EMS\system\core\CodeIgniter.php on line 532 and exactly 2 expected D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 12
ERROR - 2021-09-15 18:20:12 --> Severity: Notice --> Undefined variable: TC_Id D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 13
ERROR - 2021-09-15 18:20:12 --> Severity: Notice --> Undefined variable: Exam_Id D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 13
ERROR - 2021-09-15 18:20:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
   ...' at line 12 - Invalid query: SELECT training_center.TC_ID, training_center.Name, student_exam_course.Course_ID, 
        course.Course_name, student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount ,
        sum(exam_fee_rate.Amount) as `module_amount`  FROM student_exam_course INNER JOIN 
        student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID
        INNER JOIN course ON  student_exam_course.Course_ID = course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID WHERE student_exam_course.Exam_ID=
        AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
        ORDER BY `module`.`Module_name` ASC
ERROR - 2021-09-15 18:22:09 --> Severity: Notice --> Undefined variable: TC_Id D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 13
ERROR - 2021-09-15 18:22:09 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 13
ERROR - 2021-09-15 18:22:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
   ...' at line 12 - Invalid query: SELECT training_center.TC_ID, training_center.Name, student_exam_course.Course_ID, 
        course.Course_name, student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount ,
        sum(exam_fee_rate.Amount) as `module_amount`  FROM student_exam_course INNER JOIN 
        student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID
        INNER JOIN course ON  student_exam_course.Course_ID = course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID WHERE student_exam_course.Exam_ID=
        AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
        ORDER BY `module`.`Module_name` ASC
ERROR - 2021-09-15 18:22:10 --> Severity: Notice --> Undefined variable: TC_Id D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 13
ERROR - 2021-09-15 18:22:10 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 13
ERROR - 2021-09-15 18:22:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
   ...' at line 12 - Invalid query: SELECT training_center.TC_ID, training_center.Name, student_exam_course.Course_ID, 
        course.Course_name, student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount ,
        sum(exam_fee_rate.Amount) as `module_amount`  FROM student_exam_course INNER JOIN 
        student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID
        INNER JOIN course ON  student_exam_course.Course_ID = course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID WHERE student_exam_course.Exam_ID=
        AND student_registration.TC_ID= GROUP BY student_exam_module.Module_ID  
        ORDER BY `module`.`Module_name` ASC
ERROR - 2021-09-15 18:24:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 13
ERROR - 2021-09-15 18:35:10 --> Severity: Notice --> Undefined variable: Training_center D:\xampp\htdocs\EMS\application\views\assignexamView.php 14
ERROR - 2021-09-15 18:48:26 --> Severity: Notice --> Undefined variable: post D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 13
ERROR - 2021-09-15 18:50:37 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\controllers\ExamFeeController.php 16
ERROR - 2021-09-15 18:50:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND student_registration.TC_ID=4 GROUP BY student_exam_module.Module_ID  
  ...' at line 12 - Invalid query: SELECT training_center.TC_ID, training_center.Name, student_exam_course.Course_ID, 
        course.Course_name, student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount ,
        sum(exam_fee_rate.Amount) as `module_amount`  FROM student_exam_course INNER JOIN 
        student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID
        INNER JOIN course ON  student_exam_course.Course_ID = course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID WHERE student_exam_course.Exam_ID=
        AND student_registration.TC_ID=4 GROUP BY student_exam_module.Module_ID  
        ORDER BY `module`.`Module_name` ASC
ERROR - 2021-09-15 18:56:36 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 37
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 37
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 37
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 37
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 37
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 37
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 37
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 37
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 37
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:56:37 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'Module_name' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 38
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:57:14 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_count' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 39
ERROR - 2021-09-15 18:59:17 --> Severity: Notice --> Trying to get property 'module_amount' of non-object D:\xampp\htdocs\EMS\application\views\examFees.php 40
ERROR - 2021-09-15 19:41:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Add_institute_model D:\xampp\htdocs\EMS\system\core\Loader.php 348

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-17 16:45:17 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-17 16:45:46 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-17 16:46:00 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7
ERROR - 2021-08-17 16:46:19 --> Severity: Notice --> Undefined variable: respone C:\xampp\htdocs\EMS\application\models\Exam_manage_Model.php 341

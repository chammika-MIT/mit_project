<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-24 07:54:42 --> Severity: Notice --> Undefined index: User_ID  D:\xampp\htdocs\EMS\application\models\UserModel.php 74
ERROR - 2021-09-24 07:54:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Course'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Course'
ERROR - 2021-09-24 07:54:51 --> Severity: Notice --> Undefined index: User_ID  D:\xampp\htdocs\EMS\application\models\UserModel.php 74
ERROR - 2021-09-24 07:54:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Course'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Course'
ERROR - 2021-09-24 07:55:16 --> Severity: Notice --> Undefined index: User_ID  D:\xampp\htdocs\EMS\application\models\UserModel.php 74
ERROR - 2021-09-24 07:55:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Course'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Course'
ERROR - 2021-09-24 07:56:53 --> Severity: Notice --> Undefined index: User_ID  D:\xampp\htdocs\EMS\application\models\UserModel.php 74
ERROR - 2021-09-24 07:56:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Course'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Course'
ERROR - 2021-09-24 07:58:12 --> Severity: Notice --> Undefined index: User_ID  D:\xampp\htdocs\EMS\application\models\UserModel.php 74
ERROR - 2021-09-24 07:58:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Course'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Course'
ERROR - 2021-09-24 08:02:07 --> Severity: Notice --> Undefined variable: User_Id D:\xampp\htdocs\EMS\application\models\UserModel.php 79
ERROR - 2021-09-24 08:02:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Course'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Course'
ERROR - 2021-09-24 08:02:42 --> Severity: Notice --> Undefined index: User_ID  D:\xampp\htdocs\EMS\application\models\UserModel.php 74
ERROR - 2021-09-24 08:02:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Course'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Course'
ERROR - 2021-09-24 08:04:58 --> Severity: Notice --> Undefined index: User_ID  D:\xampp\htdocs\EMS\application\models\UserModel.php 74
ERROR - 2021-09-24 08:04:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Course'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Course'
ERROR - 2021-09-24 08:05:11 --> Severity: Notice --> Undefined index: User_ID  D:\xampp\htdocs\EMS\application\models\UserModel.php 74
ERROR - 2021-09-24 08:05:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Course'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Course'
ERROR - 2021-09-24 08:07:57 --> Severity: Notice --> Undefined variable: User_Id D:\xampp\htdocs\EMS\application\models\UserModel.php 74
ERROR - 2021-09-24 08:08:26 --> Severity: Notice --> Undefined index: User_ID D:\xampp\htdocs\EMS\application\models\UserModel.php 75
ERROR - 2021-09-24 08:08:44 --> Severity: Notice --> Undefined index: User_ID D:\xampp\htdocs\EMS\application\models\UserModel.php 75
ERROR - 2021-09-24 08:08:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Course'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Course'
ERROR - 2021-09-24 08:10:33 --> Severity: Notice --> Undefined index: User_ID D:\xampp\htdocs\EMS\application\models\UserModel.php 75
ERROR - 2021-09-24 08:10:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Delete_Center'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Delete_Center'
ERROR - 2021-09-24 08:10:43 --> Severity: Notice --> Undefined index: User_ID D:\xampp\htdocs\EMS\application\models\UserModel.php 75
ERROR - 2021-09-24 08:10:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Delete_Center'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Delete_Center'
ERROR - 2021-09-24 08:11:22 --> Severity: Notice --> Undefined index: User_ID D:\xampp\htdocs\EMS\application\models\UserModel.php 75
ERROR - 2021-09-24 08:11:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Course'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Course'
ERROR - 2021-09-24 08:11:23 --> Severity: Notice --> Undefined index: User_ID D:\xampp\htdocs\EMS\application\models\UserModel.php 75
ERROR - 2021-09-24 08:11:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Course'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Course'
ERROR - 2021-09-24 08:11:37 --> Severity: Notice --> Undefined index: User_ID D:\xampp\htdocs\EMS\application\models\UserModel.php 75
ERROR - 2021-09-24 08:11:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Course'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Course'
ERROR - 2021-09-24 08:12:24 --> Severity: Notice --> Undefined index: User_ID D:\xampp\htdocs\EMS\application\models\UserModel.php 75
ERROR - 2021-09-24 08:12:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Course'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Course'
ERROR - 2021-09-24 08:12:26 --> Severity: Notice --> Undefined index: User_ID D:\xampp\htdocs\EMS\application\models\UserModel.php 75
ERROR - 2021-09-24 08:12:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Course'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Course'
ERROR - 2021-09-24 08:12:27 --> Severity: Notice --> Undefined index: User_ID D:\xampp\htdocs\EMS\application\models\UserModel.php 75
ERROR - 2021-09-24 08:12:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Course'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Course'
ERROR - 2021-09-24 08:12:27 --> Severity: Notice --> Undefined index: User_ID D:\xampp\htdocs\EMS\application\models\UserModel.php 75
ERROR - 2021-09-24 08:12:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Course'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Course'
ERROR - 2021-09-24 08:13:05 --> Severity: Notice --> Undefined index: User_ID D:\xampp\htdocs\EMS\application\models\UserModel.php 75
ERROR - 2021-09-24 08:13:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Delete_Center'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Delete_Center'
ERROR - 2021-09-24 08:14:01 --> Severity: Notice --> Undefined index: User_ID D:\xampp\htdocs\EMS\application\models\UserModel.php 75
ERROR - 2021-09-24 08:14:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Delete_Center'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Delete_Center'
ERROR - 2021-09-24 08:14:02 --> Severity: Notice --> Undefined index: User_ID D:\xampp\htdocs\EMS\application\models\UserModel.php 75
ERROR - 2021-09-24 08:14:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Delete_Center'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Delete_Center'
ERROR - 2021-09-24 08:14:38 --> Severity: Notice --> Undefined index: User_ID D:\xampp\htdocs\EMS\application\models\UserModel.php 75
ERROR - 2021-09-24 08:14:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Institute'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Institute'
ERROR - 2021-09-24 08:14:39 --> Severity: Notice --> Undefined index: User_ID D:\xampp\htdocs\EMS\application\models\UserModel.php 75
ERROR - 2021-09-24 08:14:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Institute'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Institute'
ERROR - 2021-09-24 08:14:40 --> Severity: Notice --> Undefined index: User_ID D:\xampp\htdocs\EMS\application\models\UserModel.php 75
ERROR - 2021-09-24 08:14:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND component.Path='Add_Institute'' at line 4 - Invalid query: SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID= AND component.Path='Add_Institute'
ERROR - 2021-09-24 09:14:10 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-24 09:15:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Group BY student_exam_module.Module_ID) as `pass_table` INNER JOIN (SELECT mo...' at line 4 - Invalid query: SELECT `pass_table`.Module_ID, `pass_table`.Module_name as 'Module_name',total_student,pass_student,
        CAST(((pass_student/total_student)*100) AS DECIMAL(11,2))  as 'pass_rate'  FROM (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `pass_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID WHERE  result.Marks>=40 AND module.Course_ID=
        Group BY student_exam_module.Module_ID) as `pass_table` INNER JOIN (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `total_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID Group BY student_exam_module.Module_ID) AS `total_table` ON `pass_table`.Module_ID=`total_table`.Module_ID ORDER BY `pass_table`.Module_ID
        
ERROR - 2021-09-24 11:51:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Group BY student_exam_module.Module_ID) as `pass_table` INNER JOIN (SELECT mo...' at line 4 - Invalid query: SELECT `pass_table`.Module_ID, `pass_table`.Module_name as 'Module_name',total_student,pass_student,
        CAST(((pass_student/total_student)*100) AS DECIMAL(11,2))  as 'pass_rate'  FROM (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `pass_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID WHERE  result.Marks>=40 AND module.Course_ID=
        Group BY student_exam_module.Module_ID) as `pass_table` INNER JOIN (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `total_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID Group BY student_exam_module.Module_ID) AS `total_table` ON `pass_table`.Module_ID=`total_table`.Module_ID ORDER BY `pass_table`.Module_ID
        
ERROR - 2021-09-24 12:01:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Group BY student_exam_module.Module_ID) as `pass_table` INNER JOIN (SELECT mo...' at line 4 - Invalid query: SELECT `pass_table`.Module_ID, `pass_table`.Module_name as 'Module_name',total_student,pass_student,
        CAST(((pass_student/total_student)*100) AS DECIMAL(11,2))  as 'pass_rate'  FROM (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `pass_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID WHERE  result.Marks>=40 AND module.Course_ID=
        Group BY student_exam_module.Module_ID) as `pass_table` INNER JOIN (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `total_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID Group BY student_exam_module.Module_ID) AS `total_table` ON `pass_table`.Module_ID=`total_table`.Module_ID ORDER BY `pass_table`.Module_ID
        
ERROR - 2021-09-24 12:05:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Group BY student_exam_module.Module_ID) as `pass_table` INNER JOIN (SELECT mo...' at line 4 - Invalid query: SELECT `pass_table`.Module_ID, `pass_table`.Module_name as 'Module_name',total_student,pass_student,
        CAST(((pass_student/total_student)*100) AS DECIMAL(11,2))  as 'pass_rate'  FROM (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `pass_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID WHERE  result.Marks>=40 AND module.Course_ID=
        Group BY student_exam_module.Module_ID) as `pass_table` INNER JOIN (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `total_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID Group BY student_exam_module.Module_ID) AS `total_table` ON `pass_table`.Module_ID=`total_table`.Module_ID ORDER BY `pass_table`.Module_ID
        
ERROR - 2021-09-24 12:07:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Group BY student_exam_module.Module_ID) as `pass_table` INNER JOIN (SELECT mo...' at line 4 - Invalid query: SELECT `pass_table`.Module_ID, `pass_table`.Module_name as 'Module_name',total_student,pass_student,
        CAST(((pass_student/total_student)*100) AS DECIMAL(11,2))  as 'pass_rate'  FROM (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `pass_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID WHERE  result.Marks>=40 AND module.Course_ID=
        Group BY student_exam_module.Module_ID) as `pass_table` INNER JOIN (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `total_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID Group BY student_exam_module.Module_ID) AS `total_table` ON `pass_table`.Module_ID=`total_table`.Module_ID ORDER BY `pass_table`.Module_ID
        
ERROR - 2021-09-24 13:21:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 18
ERROR - 2021-09-24 13:21:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 20
ERROR - 2021-09-24 13:21:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 66
ERROR - 2021-09-24 13:21:57 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 66
ERROR - 2021-09-24 13:22:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 18
ERROR - 2021-09-24 13:22:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 20
ERROR - 2021-09-24 13:22:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 66
ERROR - 2021-09-24 13:22:35 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 66
ERROR - 2021-09-24 13:24:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 18
ERROR - 2021-09-24 13:24:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 20
ERROR - 2021-09-24 13:24:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 66
ERROR - 2021-09-24 13:24:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 66
ERROR - 2021-09-24 13:37:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 18
ERROR - 2021-09-24 13:37:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 20
ERROR - 2021-09-24 13:37:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 66
ERROR - 2021-09-24 13:37:09 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 66
ERROR - 2021-09-24 13:38:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 18
ERROR - 2021-09-24 13:38:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 20
ERROR - 2021-09-24 13:38:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 66
ERROR - 2021-09-24 13:38:56 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 66
ERROR - 2021-09-24 13:40:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 18
ERROR - 2021-09-24 13:40:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 20
ERROR - 2021-09-24 13:40:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 66
ERROR - 2021-09-24 13:40:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examFeesView.php 66
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined index: thead D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16563
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined index: trids D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19566
ERROR - 2021-09-24 14:25:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19566
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined index: trids D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19595
ERROR - 2021-09-24 14:25:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19595
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined index: trids D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19598
ERROR - 2021-09-24 14:25:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19598
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined index: old_cell_padding D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19808
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:24 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined index: thead D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16563
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined index: trids D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19566
ERROR - 2021-09-24 14:25:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19566
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined index: trids D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19595
ERROR - 2021-09-24 14:25:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19595
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined index: trids D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19598
ERROR - 2021-09-24 14:25:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19598
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined index: old_cell_padding D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19808
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:25:42 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:36:09 --> Severity: error --> Exception: Class 'TCPDF' not found D:\xampp\htdocs\EMS\application\views\examSchedulePDF.php 2
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined index: thead D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 16563
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined index: trids D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19566
ERROR - 2021-09-24 14:59:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19566
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined index: trids D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19595
ERROR - 2021-09-24 14:59:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19595
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined index: trids D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19598
ERROR - 2021-09-24 14:59:41 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19598
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined index: old_cell_padding D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 19808
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17220
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18338
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18349
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 17587
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18040
ERROR - 2021-09-24 14:59:41 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\helpers\tcpdf\tcpdf.php 18347
ERROR - 2021-09-24 14:59:46 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-24 15:19:10 --> Severity: Notice --> Undefined variable: recepient_email D:\xampp\htdocs\EMS\application\controllers\User_Controller.php 35
ERROR - 2021-09-24 15:19:10 --> Severity: Notice --> Undefined variable: subject D:\xampp\htdocs\EMS\application\controllers\User_Controller.php 36
ERROR - 2021-09-24 15:19:10 --> Severity: Notice --> Undefined variable: message D:\xampp\htdocs\EMS\application\controllers\User_Controller.php 37
ERROR - 2021-09-24 15:19:12 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\EMS\system\libraries\Email.php 1902
ERROR - 2021-09-24 15:21:43 --> Severity: error --> Exception: Too few arguments to function CI_Email::to(), 0 passed in D:\xampp\htdocs\EMS\application\controllers\User_Controller.php on line 38 and exactly 1 expected D:\xampp\htdocs\EMS\system\libraries\Email.php 569
ERROR - 2021-09-24 15:23:48 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\EMS\system\libraries\Email.php 1902
ERROR - 2021-09-24 15:34:31 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;smtp.gmail.com&quot; port 465, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\EMS\system\libraries\Email.php 1902
ERROR - 2021-09-24 15:46:19 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:1408F10B:SSL routines:ssl3_get_record:wrong version number D:\xampp\htdocs\EMS\system\libraries\Email.php 2069
ERROR - 2021-09-24 15:46:19 --> Severity: Warning --> fsockopen(): Failed to enable crypto D:\xampp\htdocs\EMS\system\libraries\Email.php 2069
ERROR - 2021-09-24 15:46:19 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:587 (Unknown error) D:\xampp\htdocs\EMS\system\libraries\Email.php 2069
ERROR - 2021-09-24 15:46:46 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:1408F10B:SSL routines:ssl3_get_record:wrong version number D:\xampp\htdocs\EMS\system\libraries\Email.php 2069
ERROR - 2021-09-24 15:46:46 --> Severity: Warning --> fsockopen(): Failed to enable crypto D:\xampp\htdocs\EMS\system\libraries\Email.php 2069
ERROR - 2021-09-24 15:46:46 --> Severity: Warning --> fsockopen(): unable to connect to tls://smtp.googlemail.com:587 (Unknown error) D:\xampp\htdocs\EMS\system\libraries\Email.php 2069
ERROR - 2021-09-24 16:24:48 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' D:\xampp\htdocs\EMS\application\config\email.php 12
ERROR - 2021-09-24 16:25:41 --> Severity: Notice --> Undefined variable: config D:\xampp\htdocs\EMS\application\controllers\User_Controller.php 32
ERROR - 2021-09-24 16:25:41 --> Severity: error --> Exception: Argument 1 passed to CI_Email::initialize() must be of the type array, null given, called in D:\xampp\htdocs\EMS\application\controllers\User_Controller.php on line 32 D:\xampp\htdocs\EMS\system\libraries\Email.php 413
ERROR - 2021-09-24 16:25:44 --> Severity: Notice --> Undefined variable: config D:\xampp\htdocs\EMS\application\controllers\User_Controller.php 32
ERROR - 2021-09-24 16:25:44 --> Severity: error --> Exception: Argument 1 passed to CI_Email::initialize() must be of the type array, null given, called in D:\xampp\htdocs\EMS\application\controllers\User_Controller.php on line 32 D:\xampp\htdocs\EMS\system\libraries\Email.php 413
ERROR - 2021-09-24 16:57:49 --> Severity: Notice --> Undefined variable: staffTC D:\xampp\htdocs\EMS\application\views\addStaffView.php 84
ERROR - 2021-09-24 16:57:49 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addStaffView.php 84
ERROR - 2021-09-24 16:58:12 --> Severity: Notice --> Undefined variable: staffTC D:\xampp\htdocs\EMS\application\views\addStaffView.php 84
ERROR - 2021-09-24 16:58:12 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addStaffView.php 84
ERROR - 2021-09-24 17:37:38 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-24 17:37:53 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-24 17:39:11 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-24 18:01:01 --> Severity: Notice --> Undefined index: Email D:\xampp\htdocs\EMS\application\controllers\User_Controller.php 57
ERROR - 2021-09-24 18:01:40 --> Severity: Notice --> Undefined index: Email D:\xampp\htdocs\EMS\application\controllers\User_Controller.php 57
ERROR - 2021-09-24 18:01:45 --> Severity: Notice --> Undefined index: Email D:\xampp\htdocs\EMS\application\controllers\User_Controller.php 57
ERROR - 2021-09-24 18:09:35 --> Severity: Notice --> Undefined variable: userdata D:\xampp\htdocs\EMS\application\controllers\User_Controller.php 29
ERROR - 2021-09-24 18:09:35 --> Severity: Notice --> Undefined variable: userdata D:\xampp\htdocs\EMS\application\controllers\User_Controller.php 30
ERROR - 2021-09-24 18:22:51 --> Severity: Notice --> Undefined variable: mail D:\xampp\htdocs\EMS\application\controllers\User_Controller.php 18
ERROR - 2021-09-24 18:22:51 --> Severity: error --> Exception: Call to a member function IsSMTP() on null D:\xampp\htdocs\EMS\application\controllers\User_Controller.php 18
ERROR - 2021-09-24 18:29:06 --> Severity: Notice --> Undefined variable: userdata D:\xampp\htdocs\EMS\application\controllers\User_Controller.php 27
ERROR - 2021-09-24 18:29:06 --> Severity: Notice --> Undefined variable: userdata D:\xampp\htdocs\EMS\application\controllers\User_Controller.php 28
ERROR - 2021-09-24 20:12:50 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examResultCourseModuleCenterPDF.php 33
ERROR - 2021-09-24 20:12:50 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\examResultCourseModuleCenterPDF.php 34

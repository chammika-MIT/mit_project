<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-27 19:21:17 --> Severity: Notice --> Undefined variable: training D:\xampp\htdocs\EMS\application\views\selectexamView.php 28
ERROR - 2021-09-27 19:21:54 --> Severity: Notice --> Undefined variable: training D:\xampp\htdocs\EMS\application\views\selectexamView.php 28
ERROR - 2021-09-27 19:22:32 --> Severity: Notice --> Undefined variable: training D:\xampp\htdocs\EMS\application\views\selectexamView.php 28
ERROR - 2021-09-27 19:22:50 --> Severity: Notice --> Undefined variable: training D:\xampp\htdocs\EMS\application\views\selectexamView.php 28
ERROR - 2021-09-27 19:23:16 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14

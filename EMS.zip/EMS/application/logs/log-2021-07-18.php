<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-18 21:26:34 --> Severity: error --> Exception: Call to a member function result() on string D:\xampp\htdocs\EMS\application\models\login_model.php 24
ERROR - 2021-07-18 21:26:36 --> Severity: error --> Exception: Call to a member function result() on string D:\xampp\htdocs\EMS\application\models\login_model.php 24
ERROR - 2021-07-18 21:28:54 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:28:54 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, null given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:30:37 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:31:26 --> Severity: error --> Exception: Call to undefined function mysql_fetch_array() D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:31:30 --> Severity: error --> Exception: Call to undefined function mysql_fetch_array() D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:31:31 --> Severity: error --> Exception: Call to undefined function mysql_fetch_array() D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:31:31 --> Severity: error --> Exception: Call to undefined function mysql_fetch_array() D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:31:31 --> Severity: error --> Exception: Call to undefined function mysql_fetch_array() D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:31:42 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:32:26 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:32:28 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:32:29 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:32:29 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:32:30 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:32:30 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:35:21 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 27
ERROR - 2021-07-18 21:35:22 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 27
ERROR - 2021-07-18 21:35:53 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 27
ERROR - 2021-07-18 21:35:55 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 27
ERROR - 2021-07-18 21:35:55 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 27
ERROR - 2021-07-18 21:35:55 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 27
ERROR - 2021-07-18 21:38:25 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 27
ERROR - 2021-07-18 21:38:27 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 27
ERROR - 2021-07-18 21:38:27 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 27
ERROR - 2021-07-18 21:38:29 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 27
ERROR - 2021-07-18 21:38:35 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 27
ERROR - 2021-07-18 21:40:02 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 26
ERROR - 2021-07-18 21:40:03 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 26
ERROR - 2021-07-18 21:40:03 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 26
ERROR - 2021-07-18 21:40:04 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 26
ERROR - 2021-07-18 21:40:16 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 26
ERROR - 2021-07-18 21:40:17 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 26
ERROR - 2021-07-18 21:40:17 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 26
ERROR - 2021-07-18 21:40:17 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 26
ERROR - 2021-07-18 21:40:17 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 26
ERROR - 2021-07-18 21:40:18 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\xampp\htdocs\EMS\application\views\admin_view.php 26
ERROR - 2021-07-18 21:42:48 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:42:50 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:42:51 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:42:51 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:43:36 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:43:37 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:43:38 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:43:38 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:43:38 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:43:39 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:43:50 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:43:50 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:43:51 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:43:51 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:43:51 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:43:52 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:43:52 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:43:52 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:43:52 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:43:53 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:44:08 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:44:09 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:44:09 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:44:09 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:44:10 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:44:10 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:44:10 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:44:10 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:44:10 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:44:10 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:44:11 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:44:11 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:44:14 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:45:12 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 21:53:47 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\models\login_model.php 25
ERROR - 2021-07-18 21:53:49 --> Severity: Notice --> Undefined variable: result D:\xampp\htdocs\EMS\application\models\login_model.php 25
ERROR - 2021-07-18 21:54:13 --> Severity: error --> Exception: syntax error, unexpected '$query' (T_VARIABLE) D:\xampp\htdocs\EMS\application\models\login_model.php 25
ERROR - 2021-07-18 21:54:14 --> Severity: error --> Exception: syntax error, unexpected '$query' (T_VARIABLE) D:\xampp\htdocs\EMS\application\models\login_model.php 25
ERROR - 2021-07-18 21:58:10 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:09:16 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:12:32 --> Severity: Notice --> Undefined index: number D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:12:32 --> Severity: Notice --> Undefined index: number D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:12:36 --> Severity: Notice --> Undefined index: number D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:12:36 --> Severity: Notice --> Undefined index: number D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:13:30 --> Severity: Notice --> Undefined index: number D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:15:00 --> Severity: Notice --> Undefined index: number D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:15:00 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\admin_view.php 26
ERROR - 2021-07-18 22:18:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:18:08 --> Severity: Notice --> Trying to get property 'number' of non-object D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:18:08 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:18:08 --> Severity: Notice --> Trying to get property 'number' of non-object D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:23:10 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:23:10 --> Severity: Notice --> Trying to get property 'number' of non-object D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:23:10 --> Severity: Notice --> Trying to get property 'Gender' of non-object D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:23:10 --> Severity: Notice --> Trying to get property 'number' of non-object D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:26:29 --> Severity: Notice --> Undefined index: number D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:26:29 --> Severity: Notice --> Undefined index: number D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:27:51 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:31:12 --> Severity: error --> Exception: Call to undefined function mysql_fetch_array() D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:34:08 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:37:03 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:43:29 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:44:35 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 22:45:35 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, array given D:\xampp\htdocs\EMS\application\views\admin_view.php 25
ERROR - 2021-07-18 23:15:54 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:15:54 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:15:55 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:15:55 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:15:56 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:15:56 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:15:56 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:15:56 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:18:37 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:18:37 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:18:38 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:18:38 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:18:38 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:18:38 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:18:38 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:18:38 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:18:39 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:18:39 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:18:39 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:18:39 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:18:39 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:18:39 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:20:23 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:20:23 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:20:24 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:20:24 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:20:33 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34
ERROR - 2021-07-18 23:20:33 --> Severity: Notice --> Undefined index: Number D:\xampp\htdocs\EMS\application\views\admin_view.php 34

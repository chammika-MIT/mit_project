<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-27 17:11:22 --> Severity: Warning --> require_once(C:\xampp\htdocs\EMS\application\libraries/dompdf/dompdf_config.inc.php): failed to open stream: No such file or directory C:\xampp\htdocs\EMS\application\libraries\pdf.php 20
ERROR - 2021-07-27 17:11:22 --> Severity: Compile Error --> require_once(): Failed opening required 'C:\xampp\htdocs\EMS\application\libraries/dompdf/dompdf_config.inc.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\EMS\application\libraries\pdf.php 20
ERROR - 2021-07-27 17:12:54 --> Severity: Warning --> Use of undefined constant ‘session’ - assumed '‘session’' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 9
ERROR - 2021-07-27 17:12:54 --> Unable to load the requested class: ‘session’
ERROR - 2021-07-27 17:14:15 --> Severity: Warning --> Use of undefined constant ‘session’ - assumed '‘session’' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\EMS\application\controllers\Exam_Manage_Controller.php 9
ERROR - 2021-07-27 17:14:15 --> Unable to load the requested class: ‘session’
ERROR - 2021-07-27 17:14:46 --> Severity: Warning --> require_once(C:\xampp\htdocs\EMS\application\libraries/dompdf/dompdf_config.inc.php): failed to open stream: No such file or directory C:\xampp\htdocs\EMS\application\libraries\pdf.php 20
ERROR - 2021-07-27 17:14:46 --> Severity: Compile Error --> require_once(): Failed opening required 'C:\xampp\htdocs\EMS\application\libraries/dompdf/dompdf_config.inc.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\EMS\application\libraries\pdf.php 20
ERROR - 2021-07-27 17:18:46 --> Severity: Warning --> require_once(C:\xampp\htdocs\EMS\application\libraries/dompdf/dompdf_config.inc.php): failed to open stream: No such file or directory C:\xampp\htdocs\EMS\application\libraries\pdf.php 20
ERROR - 2021-07-27 17:18:46 --> Severity: Compile Error --> require_once(): Failed opening required 'C:\xampp\htdocs\EMS\application\libraries/dompdf/dompdf_config.inc.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\EMS\application\libraries\pdf.php 20
ERROR - 2021-07-27 17:19:15 --> Severity: error --> Exception: Class 'Dompdf\Dompdf' not found C:\xampp\htdocs\EMS\application\libraries\pdf.php 22
ERROR - 2021-07-27 17:19:34 --> Severity: Warning --> The use statement with non-compound name 'Dompdf' has no effect C:\xampp\htdocs\EMS\application\libraries\pdf.php 21
ERROR - 2021-07-27 17:19:34 --> Severity: error --> Exception: Class 'Dompdf' not found C:\xampp\htdocs\EMS\application\libraries\pdf.php 22
ERROR - 2021-07-27 17:25:17 --> Non-existent class: Pdf
ERROR - 2021-07-27 17:25:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\EMS\application\libraries\pdf.php:1) C:\xampp\htdocs\EMS\system\core\Common.php 570
ERROR - 2021-07-27 17:25:45 --> Non-existent class: Pdf
ERROR - 2021-07-27 17:25:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\EMS\application\libraries\pdf.php:1) C:\xampp\htdocs\EMS\system\core\Common.php 570
ERROR - 2021-07-27 17:29:06 --> Severity: Warning --> require_once(C:\xampp\htdocs\EMS\application\libraries/dompdf/dompdf_config.inc.php): failed to open stream: No such file or directory C:\xampp\htdocs\EMS\application\libraries\pdf.php 20
ERROR - 2021-07-27 17:29:06 --> Severity: Compile Error --> require_once(): Failed opening required 'C:\xampp\htdocs\EMS\application\libraries/dompdf/dompdf_config.inc.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\EMS\application\libraries\pdf.php 20
ERROR - 2021-07-27 17:31:36 --> Severity: Warning --> require_once(C:\xampp\htdocs\EMS\application\libraries/dompdf/dompdf_config.inc.php): failed to open stream: No such file or directory C:\xampp\htdocs\EMS\application\libraries\pdf.php 20
ERROR - 2021-07-27 17:31:36 --> Severity: Compile Error --> require_once(): Failed opening required 'C:\xampp\htdocs\EMS\application\libraries/dompdf/dompdf_config.inc.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\EMS\application\libraries\pdf.php 20
ERROR - 2021-07-27 17:32:26 --> Severity: error --> Exception: Class 'Dompdf\Dompdf' not found C:\xampp\htdocs\EMS\application\libraries\pdf.php 22
ERROR - 2021-07-27 17:32:39 --> Severity: Warning --> The use statement with non-compound name 'Dompdf' has no effect C:\xampp\htdocs\EMS\application\libraries\pdf.php 21
ERROR - 2021-07-27 17:32:39 --> Severity: error --> Exception: Class 'Dompdf' not found C:\xampp\htdocs\EMS\application\libraries\pdf.php 22
ERROR - 2021-07-27 17:54:45 --> 404 Page Not Found: Exam_Manage_Controller/my_DOMPDF
ERROR - 2021-07-27 17:54:52 --> Severity: Warning --> require_once(C:\xampp\htdocs\EMS\application\libraries/dompdf/autoload.inc.php): failed to open stream: No such file or directory C:\xampp\htdocs\EMS\application\libraries\pdf.php 4
ERROR - 2021-07-27 17:54:52 --> Severity: Compile Error --> require_once(): Failed opening required 'C:\xampp\htdocs\EMS\application\libraries/dompdf/autoload.inc.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\EMS\application\libraries\pdf.php 4
ERROR - 2021-07-27 18:00:47 --> Severity: Warning --> require_once(C:\xampp\htdocs\EMS\application\libraries/dompdf/autoload.inc.php): failed to open stream: No such file or directory C:\xampp\htdocs\EMS\application\libraries\pdf.php 4
ERROR - 2021-07-27 18:00:47 --> Severity: Compile Error --> require_once(): Failed opening required 'C:\xampp\htdocs\EMS\application\libraries/dompdf/autoload.inc.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\EMS\application\libraries\pdf.php 4
ERROR - 2021-07-27 18:00:55 --> Severity: Warning --> require_once(C:\xampp\htdocs\EMS\application\libraries/dompdf/autoload.inc.php): failed to open stream: No such file or directory C:\xampp\htdocs\EMS\application\libraries\pdf.php 4
ERROR - 2021-07-27 18:00:55 --> Severity: Compile Error --> require_once(): Failed opening required 'C:\xampp\htdocs\EMS\application\libraries/dompdf/autoload.inc.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\EMS\application\libraries\pdf.php 4
ERROR - 2021-07-27 18:01:19 --> Severity: Warning --> require_once(C:\xampp\htdocs\EMS\application\libraries\dompdf\autoload.inc.php): failed to open stream: No such file or directory C:\xampp\htdocs\EMS\application\libraries\pdf.php 4
ERROR - 2021-07-27 18:01:19 --> Severity: Compile Error --> require_once(): Failed opening required 'C:\xampp\htdocs\EMS\application\libraries\dompdf\autoload.inc.php' (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\EMS\application\libraries\pdf.php 4

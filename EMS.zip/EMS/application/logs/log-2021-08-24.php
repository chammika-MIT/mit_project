<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-24 15:18:30 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-24 15:18:40 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-24 15:18:58 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-24 15:28:26 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-24 15:31:49 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\examScheduleView.php 7
ERROR - 2021-08-24 15:35:34 --> Severity: Notice --> Undefined variable: course_ID C:\xampp\htdocs\EMS\application\views\addResultView.php 7

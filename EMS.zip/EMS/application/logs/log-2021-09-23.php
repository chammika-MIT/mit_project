<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-23 05:26:41 --> Severity: error --> Exception: syntax error, unexpected '$query' (T_VARIABLE) D:\xampp\htdocs\EMS\application\models\studentInfoModel.php 52
ERROR - 2021-09-23 05:44:47 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 05:45:34 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 05:46:47 --> Severity: Notice --> Undefined variable: exam D:\xampp\htdocs\EMS\application\views\selectexamView.php 61
ERROR - 2021-09-23 05:48:58 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 05:49:49 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 05:50:04 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 05:56:44 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 06:10:45 --> Severity: Notice --> Undefined property: stdClass::$Mark D:\xampp\htdocs\EMS\application\views\studentInfoView.php 127
ERROR - 2021-09-23 06:10:45 --> Severity: Notice --> Undefined property: stdClass::$Mark D:\xampp\htdocs\EMS\application\views\studentInfoView.php 127
ERROR - 2021-09-23 06:10:45 --> Severity: Notice --> Undefined property: stdClass::$Mark D:\xampp\htdocs\EMS\application\views\studentInfoView.php 127
ERROR - 2021-09-23 06:27:03 --> Severity: error --> Exception: syntax error, unexpected '.' D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-09-23 06:31:10 --> Severity: error --> Exception: syntax error, unexpected ''</span>'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-09-23 06:31:16 --> Severity: error --> Exception: syntax error, unexpected ''</span>'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' D:\xampp\htdocs\EMS\application\views\registerStudentView.php 31
ERROR - 2021-09-23 07:14:54 --> Severity: Notice --> Undefined variable: exam D:\xampp\htdocs\EMS\application\views\selectexamView.php 64
ERROR - 2021-09-23 07:16:42 --> Severity: Notice --> Undefined variable: exam D:\xampp\htdocs\EMS\application\views\selectexamView.php 64
ERROR - 2021-09-23 07:18:45 --> Severity: Notice --> Undefined variable: exam D:\xampp\htdocs\EMS\application\views\selectexamView.php 64
ERROR - 2021-09-23 07:19:36 --> Severity: Notice --> Undefined variable: exam D:\xampp\htdocs\EMS\application\views\selectexamView.php 64
ERROR - 2021-09-23 07:20:03 --> Severity: Notice --> Undefined variable: exam D:\xampp\htdocs\EMS\application\views\selectexamView.php 64
ERROR - 2021-09-23 07:22:18 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-23 07:23:16 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 07:23:16 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 07:23:25 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 07:23:25 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 07:24:14 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 07:31:30 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 07:59:36 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 07:59:43 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:00:54 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:01:37 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:02:54 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:03:27 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:03:27 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\examScheduleView.php 28
ERROR - 2021-09-23 08:03:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\examScheduleView.php 28
ERROR - 2021-09-23 08:04:06 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:04:06 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\examScheduleView.php 28
ERROR - 2021-09-23 08:04:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\examScheduleView.php 28
ERROR - 2021-09-23 08:04:43 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:05:00 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:05:46 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:06:43 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:07:07 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:07:33 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:08:29 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:08:54 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:11:43 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:12:12 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:12:56 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:14:03 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:14:12 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:14:43 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:15:19 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:15:27 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:15:31 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:15:43 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:17:32 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:17:51 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 08:27:50 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-23 08:29:06 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-23 08:30:15 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-23 08:30:35 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:30:35 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:32:36 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:32:36 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:33:59 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:33:59 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:34:02 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:34:02 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:34:20 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:34:20 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:34:47 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:34:47 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:36:19 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:36:19 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:36:48 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:36:48 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:37:24 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:37:24 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:37:35 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:37:35 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:43:45 --> Severity: Notice --> Undefined variable: course D:\xampp\htdocs\EMS\application\views\addPassMarkModuleView.php 27
ERROR - 2021-09-23 08:43:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addPassMarkModuleView.php 27
ERROR - 2021-09-23 08:43:48 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:43:48 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:43:56 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:43:56 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 08:44:02 --> Severity: Notice --> Undefined variable: disciplinary D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 68
ERROR - 2021-09-23 08:44:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 68
ERROR - 2021-09-23 08:46:34 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 68
ERROR - 2021-09-23 08:46:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 68
ERROR - 2021-09-23 08:47:54 --> Severity: Notice --> Undefined variable: data D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 68
ERROR - 2021-09-23 08:47:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\listdisciplinaryView.php 68
ERROR - 2021-09-23 09:04:58 --> Severity: Notice --> Undefined variable: std_NIC D:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 187
ERROR - 2021-09-23 09:04:58 --> Severity: Notice --> Undefined variable: std_Course D:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 187
ERROR - 2021-09-23 09:04:58 --> Severity: Notice --> Undefined variable: MC_Semester D:\xampp\htdocs\EMS\application\controllers\Result_Controller.php 187
ERROR - 2021-09-23 09:30:27 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 09:53:09 --> Severity: Notice --> Undefined variable: staffTC D:\xampp\htdocs\EMS\application\views\addStaffView.php 84
ERROR - 2021-09-23 09:53:09 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\EMS\application\views\addStaffView.php 84
ERROR - 2021-09-23 10:11:47 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:11:14 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:12:59 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:13:11 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:14:49 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:15:43 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:18:22 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:18:36 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:19:05 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:19:07 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:19:53 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:19:54 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:20:19 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:21:21 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:21:50 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:21:51 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:22:46 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:25:17 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:26:30 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:27:42 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:28:49 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:29:03 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:30:06 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:30:30 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:30:52 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:31:42 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:32:54 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:33:05 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:33:20 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:34:53 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examConductView.php 7
ERROR - 2021-09-23 11:47:00 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:00 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:00 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:00 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:00 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:00 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:00 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:00 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:00 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:00 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:00 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:00 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:25 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:25 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:25 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:25 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:47:25 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:24 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:24 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:24 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:24 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:24 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:24 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:24 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:24 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:24 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:24 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:24 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:24 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:46 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:46 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:46 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:46 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:46 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:46 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:46 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:46 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:46 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:46 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:46 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:50:46 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:56:44 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:56:44 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:56:44 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:56:44 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:56:44 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:56:44 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:56:44 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:56:44 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:56:44 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:56:44 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:56:44 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:56:44 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:57:51 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:57:51 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:57:51 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:57:51 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:57:51 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:57:51 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:57:51 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:57:51 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:57:51 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:57:51 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:57:51 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 11:57:51 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 12:02:06 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 12:02:06 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 12:02:06 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 12:02:06 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 12:02:06 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 12:02:06 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 12:02:06 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 12:02:06 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 12:02:06 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 12:02:06 --> Severity: Notice --> Undefined property: stdClass::$Module_ID D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 12:02:06 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 12:02:06 --> Severity: Notice --> Undefined property: stdClass::$Module_name D:\xampp\htdocs\EMS\application\views\reportView.php 71
ERROR - 2021-09-23 12:08:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Group BY student_exam_module.Module_ID) as `pass_table` INNER JOIN (SELECT mo...' at line 4 - Invalid query: SELECT `pass_table`.Module_ID, `pass_table`.Module_name as 'Module_name',total_student,pass_student,
        CAST(((pass_student/total_student)*100) AS DECIMAL(11,2))  as 'pass_rate'  FROM (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `pass_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID WHERE  result.Marks>=40 AND module.Course_ID=
        Group BY student_exam_module.Module_ID) as `pass_table` INNER JOIN (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `total_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID Group BY student_exam_module.Module_ID) AS `total_table` ON `pass_table`.Module_ID=`total_table`.Module_ID ORDER BY `pass_table`.Module_ID
        
ERROR - 2021-09-23 12:10:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Group BY student_exam_module.Module_ID) as `pass_table` INNER JOIN (SELECT mo...' at line 4 - Invalid query: SELECT `pass_table`.Module_ID, `pass_table`.Module_name as 'Module_name',total_student,pass_student,
        CAST(((pass_student/total_student)*100) AS DECIMAL(11,2))  as 'pass_rate'  FROM (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `pass_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID WHERE  result.Marks>=40 AND module.Course_ID=
        Group BY student_exam_module.Module_ID) as `pass_table` INNER JOIN (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `total_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID Group BY student_exam_module.Module_ID) AS `total_table` ON `pass_table`.Module_ID=`total_table`.Module_ID ORDER BY `pass_table`.Module_ID
        
ERROR - 2021-09-23 13:08:28 --> Query error: Unknown column 'Chammika' in 'where clause' - Invalid query: SELECT user_role.User_ID FROM user_role WHERE user_role.User_ID=Chammika AND user_role.Role_ID=1
ERROR - 2021-09-23 13:09:13 --> Query error: Unknown column 'Chammika' in 'where clause' - Invalid query: SELECT user_role.User_ID FROM user_role WHERE user_role.User_ID=Chammika AND user_role.Role_ID=2
ERROR - 2021-09-23 13:10:33 --> Query error: Unknown column 'Chammika' in 'where clause' - Invalid query: SELECT user_role.User_ID FROM user_role WHERE user_role.User_ID=Chammika AND user_role.Role_ID=2
ERROR - 2021-09-23 13:17:15 --> Query error: Unknown column 'Chammika' in 'where clause' - Invalid query: SELECT user_role.User_ID FROM user_role WHERE user_role.User_ID=Chammika AND user_role.Role_ID=2
ERROR - 2021-09-23 13:26:00 --> Query error: Unknown column 'Chammika' in 'where clause' - Invalid query: SELECT user_role.User_ID FROM user_role WHERE user_role.User_ID=Chammika AND user_role.Role_ID=2
ERROR - 2021-09-23 13:34:56 --> Query error: Unknown column 'Chammika' in 'where clause' - Invalid query: SELECT user_role.User_ID FROM user_role WHERE user_role.User_ID=Chammika AND user_role.Role_ID=2
ERROR - 2021-09-23 13:36:39 --> Query error: Unknown column 'Chammika' in 'where clause' - Invalid query: SELECT user_role.User_ID FROM user_role WHERE user_role.User_ID=Chammika AND user_role.Role_ID=2
ERROR - 2021-09-23 13:46:33 --> Severity: Notice --> Undefined variable: UserId D:\xampp\htdocs\EMS\application\views\userRoleView.php 15
ERROR - 2021-09-23 15:00:41 --> Query error: Unknown column 'student_exam_course' in 'where clause' - Invalid query: SELECT student_registration.STD_ID,student_registration.Name,
        student_course.STD_Coure_ID, student_course.Course_ID,
        module.Module_ID, module.Module_code,
        student_exam_course.ST_EX_CO_ID, student_exam_course.Exam_ID, student_exam_course.EXC_ID,
        student_exam_module.ST_EX_MO_ID,  student_exam_module.Is_assign, student_exam_course.Index_number, student_exam_module.Is_attend
        FROM student_registration LEFT JOIN student_course ON 
        student_registration.STD_ID=student_course.STD_ID LEFT JOIN module ON 
        student_course.Course_ID=module.Course_ID  LEFT JOIN student_exam_course  ON 
        student_course.Course_ID = student_exam_course.Course_ID AND 
        student_course.STD_ID=student_exam_course.STD_ID LEFT JOIN student_exam_module  ON 
        student_exam_course.ST_EX_CO_ID=student_exam_module.ST_EX_CO_ID AND 
        student_exam_module.Module_ID = module.Module_ID
        WHERE module.Course_ID=10 AND student_registration.TC_ID=1 AND module.Semester_No=2 AND student_exam_course=4 ORDER BY
        student_registration.STD_ID,module.Module_ID
ERROR - 2021-09-23 15:08:09 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-23 15:08:29 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-23 15:08:44 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-23 15:09:35 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-23 15:09:48 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-23 15:10:17 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-23 15:10:39 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-23 15:12:19 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-23 15:17:05 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-23 15:17:18 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-23 15:22:31 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-23 15:23:24 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\addResultView.php 14
ERROR - 2021-09-23 17:39:15 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\EMS\application\views\stdCountDistrictandCoursePDF.php 28
ERROR - 2021-09-23 19:02:02 --> Severity: Notice --> Undefined property: stdClass::$Index_number D:\xampp\htdocs\EMS\application\views\registerStudentView.php 41
ERROR - 2021-09-23 19:02:02 --> Severity: Notice --> Undefined property: stdClass::$Index_number D:\xampp\htdocs\EMS\application\views\registerStudentView.php 41
ERROR - 2021-09-23 19:02:02 --> Severity: Notice --> Undefined property: stdClass::$Index_number D:\xampp\htdocs\EMS\application\views\registerStudentView.php 41
ERROR - 2021-09-23 19:02:02 --> Severity: Notice --> Undefined property: stdClass::$Index_number D:\xampp\htdocs\EMS\application\views\registerStudentView.php 41
ERROR - 2021-09-23 19:02:02 --> Severity: Notice --> Undefined property: stdClass::$Index_number D:\xampp\htdocs\EMS\application\views\registerStudentView.php 41
ERROR - 2021-09-23 19:02:02 --> Severity: Notice --> Undefined property: stdClass::$Index_number D:\xampp\htdocs\EMS\application\views\registerStudentView.php 41
ERROR - 2021-09-23 19:02:02 --> Severity: Notice --> Undefined property: stdClass::$Index_number D:\xampp\htdocs\EMS\application\views\registerStudentView.php 41
ERROR - 2021-09-23 19:02:02 --> Severity: Notice --> Undefined property: stdClass::$Index_number D:\xampp\htdocs\EMS\application\views\registerStudentView.php 41
ERROR - 2021-09-23 19:02:02 --> Severity: Notice --> Undefined property: stdClass::$Index_number D:\xampp\htdocs\EMS\application\views\registerStudentView.php 41
ERROR - 2021-09-23 19:02:02 --> Severity: Notice --> Undefined property: stdClass::$Index_number D:\xampp\htdocs\EMS\application\views\registerStudentView.php 41
ERROR - 2021-09-23 19:02:02 --> Severity: Notice --> Undefined property: stdClass::$Index_number D:\xampp\htdocs\EMS\application\views\registerStudentView.php 41
ERROR - 2021-09-23 19:03:44 --> Severity: Notice --> Undefined property: stdClass::$Index_number D:\xampp\htdocs\EMS\application\views\registerStudentView.php 30
ERROR - 2021-09-23 19:38:39 --> Severity: Notice --> Undefined property: AddCourseModule_controller::$UserModel D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 10
ERROR - 2021-09-23 19:38:39 --> Severity: error --> Exception: Call to a member function getUserRoleComponentAccess() on null D:\xampp\htdocs\EMS\application\controllers\AddCourseModule_controller.php 10
ERROR - 2021-09-23 20:25:19 --> Severity: Notice --> Undefined property: CreateExamController::$UserModel D:\xampp\htdocs\EMS\application\controllers\CreateExamController.php 10
ERROR - 2021-09-23 20:25:19 --> Severity: error --> Exception: Call to a member function getUserRoleComponentAccess() on null D:\xampp\htdocs\EMS\application\controllers\CreateExamController.php 10
ERROR - 2021-09-23 20:51:01 --> Severity: error --> Exception: syntax error, unexpected end of file D:\xampp\htdocs\EMS\application\views\layouts\side_menu.php 104
ERROR - 2021-09-23 20:57:43 --> Severity: Notice --> Undefined property: Login_Controller::$UserModel D:\xampp\htdocs\EMS\application\controllers\Login_Controller.php 21
ERROR - 2021-09-23 20:57:43 --> Severity: error --> Exception: Call to a member function getUserRoleComponentAccess() on null D:\xampp\htdocs\EMS\application\controllers\Login_Controller.php 21
ERROR - 2021-09-23 21:09:23 --> Severity: Notice --> Undefined property: Exam_Center_Controller::$UserModel D:\xampp\htdocs\EMS\application\controllers\Exam_Center_Controller.php 12
ERROR - 2021-09-23 21:09:23 --> Severity: error --> Exception: Call to a member function getUserRoleComponentAccess() on null D:\xampp\htdocs\EMS\application\controllers\Exam_Center_Controller.php 12
ERROR - 2021-09-23 21:31:01 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 21:31:06 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 14
ERROR - 2021-09-23 21:31:08 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 21:31:13 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\updateExamScheduleView.php 14
ERROR - 2021-09-23 21:31:17 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\examScheduleView.php 13
ERROR - 2021-09-23 21:33:45 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 21:33:45 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 21:33:49 --> Severity: Notice --> Undefined variable: Exam_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13
ERROR - 2021-09-23 21:33:49 --> Severity: Notice --> Undefined variable: course_ID D:\xampp\htdocs\EMS\application\views\listModuleMarksView.php 13

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-15 19:27:01 --> Severity: Warning --> include(layoutsside_menu.php): failed to open stream: No such file or directory D:\xampp\htdocs\EMS\application\views\admin_view.php 2
ERROR - 2021-06-15 19:27:01 --> Severity: Warning --> include(): Failed opening 'layoutsside_menu.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\EMS\application\views\admin_view.php 2
ERROR - 2021-06-15 19:27:02 --> Severity: Warning --> include(layoutsside_menu.php): failed to open stream: No such file or directory D:\xampp\htdocs\EMS\application\views\admin_view.php 2
ERROR - 2021-06-15 19:27:02 --> Severity: Warning --> include(): Failed opening 'layoutsside_menu.php' for inclusion (include_path='D:\xampp\php\PEAR') D:\xampp\htdocs\EMS\application\views\admin_view.php 2

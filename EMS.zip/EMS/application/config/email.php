<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config = array(
    'protocol' => 'smtp', // 'mail', 'sendmail', or 'smtp'
    'smtp_host' => 'smtp.googlemail.com', 
    'smtp_port' => 465,
    'smtp_user' => 'chammikamit@gmail.com',
    'smtp_pass' => 'MIT2018@ucsc',
    'smtp_crypto' => 'ssl', //can be 'ssl' or 'tls' for example
    'mailtype' => 'html', //plaintext 'text' mails or 'html'
    'smtp_timeout' => '7', //in seconds
	'newline' => "\r\n",
    'charset' => 'utf-8',
    'wordwrap' => TRUE
);
?>
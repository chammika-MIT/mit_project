<?php
class ResultModel extends CI_Model{

    function displayExamResultModule($trainingcenter,$trainingcourse,$trainingmodule,$Exam_ID){
        $sql="SELECT student_registration.STD_ID,student_registration.Name,
        student_course.STD_Coure_ID, student_course.Course_ID,
        module.Module_ID, module.Module_code,
        student_exam_course.ST_EX_CO_ID, student_exam_course.Exam_ID, student_exam_course.EXC_ID,
        student_exam_module.ST_EX_MO_ID,  student_exam_module.Is_assign, student_exam_course.Index_number, 
        student_exam_module.Is_attend,result.Marks
        FROM student_registration LEFT JOIN student_course ON 
        student_registration.STD_ID=student_course.STD_ID LEFT JOIN module ON 
        student_course.Course_ID=module.Course_ID  LEFT JOIN student_exam_course  ON 
        student_course.Course_ID = student_exam_course.Course_ID AND 
        student_course.STD_ID=student_exam_course.STD_ID LEFT JOIN student_exam_module  ON 
        student_exam_course.ST_EX_CO_ID=student_exam_module.ST_EX_CO_ID AND 
        student_exam_module.Module_ID = module.Module_ID
        LEFT JOIN result ON student_exam_module.ST_EX_MO_ID = result.ST_EX_MO_ID
        WHERE module.Course_ID=".$trainingcourse." AND student_registration.TC_ID=".$trainingcenter. " AND student_exam_module.Module_ID=".$trainingmodule. 
        " AND student_exam_course.Exam_ID=".$Exam_ID." ORDER BY
        student_registration.STD_ID,module.Module_ID"; 
        //print_r($sql); exit();       
        $query=$this->db->query($sql);
        return $query->result();
    }

    function getStudentExamResultAssign($trainingcenter,$trainingcourse,$trainingmodule,$Exam_ID){
        $sql="SELECT student_exam_module.ST_EX_MO_ID 
        FROM `student_exam_course` INNER JOIN  `student_exam_module`  ON 
        student_exam_course.ST_EX_CO_ID=student_exam_module.ST_EX_CO_ID INNER JOIN student_registration ON
        student_exam_course.STD_ID = student_registration.STD_ID INNER JOIN result ON student_exam_module.ST_EX_MO_ID=result.ST_EX_MO_ID
        WHERE student_exam_course.Course_ID=".$trainingcourse." AND student_registration.TC_ID=".$trainingcenter. " AND student_exam_module.Module_ID=".$trainingmodule. 
        " AND student_exam_course.Exam_ID=".$Exam_ID;
        //print_r($sql); exit(); 
        $query=$this->db->query($sql);        
        return $query->result();
    }

    function getProperResultTypeId(){
        $query=$this->db->query("SELECT * FROM result_type WHERE Result_type='Proper'");
        return $query->result();
    }

    function insert_student_result($result,$ExamID,$courseID,$centerID,$moduleID){
      
       $studentExamResultInsert = array();
       $studentExamResultUpdate = array();
       $studentTempId=0;
       $resultType=$this->ResultModel->getProperResultTypeId();
       $resultType = json_decode( json_encode($resultType), true);  
       $resultType = array_column($resultType,"RE_TY_ID");
       $resultType = $resultType[0];
       $studentModuleResult=$this->ResultModel->getStudentExamResultAssign($centerID,$courseID,$moduleID,$ExamID);
       $studentModuleResult = json_decode( json_encode($studentModuleResult), true);      
       $studentModuleResult = array_column($studentModuleResult,"ST_EX_MO_ID");
      
        $this->db->trans_start();
           
        foreach ($result as $key => $value):           
            $studentmodule=explode("-",$key);
            $studentID=$studentmodule[0];            
            $studentExamModuleId=$studentmodule[1];                  
            if(($key = array_search($studentExamModuleId,  $studentModuleResult)) !== false){
            $std_ex_result_update =  array (                
                'ST_EX_MO_ID' => $studentExamModuleId,
                'RE_TY_ID' => $resultType,
                'Marks' => $value                       
              );  
            array_push($studentExamResultUpdate, $std_ex_result_update);   

           }  
           else{
           
            $std_ex_result_insert =  array (                
                'ST_EX_MO_ID' => $studentExamModuleId,
                'RE_TY_ID' => $resultType,
                'Marks' => $value                       
              );  
            array_push($studentExamResultInsert, $std_ex_result_insert);   
           }     
             
        endforeach;

        //print_r($studentExamResultUpdate);
        //exit;   
        //print_r($studentExamResultInsert);
        //exit;           
        //print_r($studentExamcourseInsert);exit; 
        if(!empty($studentExamResultInsert))
        //print_r($studentExamcourseInsert);
       // exit;
        $respone=$this->db->insert_batch('result',$studentExamResultInsert);
    
        if(!empty($studentExamResultUpdate)){
            $this->db->where('RE_TY_ID',$resultType);
            $respone=$this->db->update_batch('result',$studentExamResultUpdate, 'ST_EX_MO_ID'); 
        }
            
        
        $this->db->trans_complete(); 
        return $respone;
        
    }
    // MAnage Moodule minimum marks

    function displaytrainingcourse(){
        $query=$this->db->query('SELECT * FROM course');
        return $query->result();
    }
    function displaymodule(){
        $query=$this->db->query('SELECT * FROM module');
        return $query->result();
    }

    function displaytrainingmodule(){
        $sql="SELECT module_pass_mark.Module_ID as 'Module_ID',module_pass_mark.MO_PASS_MAR_ID as 'MO_PASS_MAR_ID',module.Module_name as 'Module_name',module_pass_mark.Minimum_mark as 'Minimum_mark' 
        FROM module INNER JOIN module_pass_mark ON module_pass_mark.Module_ID =module.Module_ID";

        $query=$this->db->query($sql);
        return $query->result();
    }
    function displaytrainingmodulemarks($trainingcourse){
        $sql="SELECT module_pass_mark.MO_PASS_MAR_ID as 'MO_PASS_MAR_ID',module.Module_name as 'Module_name',module_pass_mark.Minimum_mark as 
        'Minimum_mark' FROM module INNER JOIN module_pass_mark ON 
        module_pass_mark.Module_ID =module.Module_ID WHERE 
        module.Course_ID=".$trainingcourse;
        
        $query=$this->db->query( $sql);
        return $query->result();
    }
    function displaymodulebycourseid(){
        $sql="SELECT * FROM `module` WHERE Module_ID NOT IN (SELECT Module_ID FROM  module_pass_mark)
        ORDER BY module.Module_ID";

        $query=$this->db->query($sql);
        return $query->result();
    }
    
    function insert_module_marks(){
        
        $minimumMark=array(
            'Course_ID'=>$this->input->post('Course'),
            'Module_ID'=>$this->input->post('Module'),
            'Minimum_mark'=>$this->input->post('MinimumPassMark'));
         
            
        return $this->db->insert('module_pass_mark',$minimumMark);
        return $minimumMark->result();
    }
    function modulePassMark($MO_PASS_MAR_ID){
        $query=$this->db->query('SELECT * FROM module_pass_mark WHERE MO_PASS_MAR_ID='.$MO_PASS_MAR_ID);
        return $query->result();
    }
    function updatemodulePassMark($MO_PASS_MAR_ID, $ModuleMark){
        $query=$this->db->query("UPDATE module_pass_mark SET Minimum_mark='$ModuleMark' WHERE MO_PASS_MAR_ID=".$MO_PASS_MAR_ID);
    }

    // disciplinary actions for students

    function displaystudentbyNIC($std_NIC,$std_Course,$MC_Semester){
        $sql="SELECT student_registration.Std_NIC as 'std_NIC', student_registration.Name as 'sdt_Name', course.Course_name 
        as 'std_Course', module.Module_name AS 'std_Module',training_center.Name as 'TC_Name',student_exam_module.Module_ID as 'MD_ID', student_exam_module.ST_EX_MO_ID as 'ST_EX_MO_ID' FROM `student_exam_module` 
        INNER JOIN student_exam_course ON student_exam_module.ST_EX_CO_ID=student_exam_course.ST_EX_CO_ID
        INNER JOIN module ON student_exam_module.Module_ID=module.Module_ID
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID
        INNER JOIN course ON student_exam_course.Course_ID=course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID WHERE student_registration.Std_NIC LIKE '$std_NIC' AND module.Semester_No='$MC_Semester' AND student_exam_course.Course_ID='$std_Course'";
        $query=$this->db->query( $sql);
        return $query->result();
    }

    function insert_disciplinary(){
        $action=array(
            'ST_EX_MO_ID'=>$this->input->post('ST_EX_MO_ID'),
            'Description'=>$this->input->post('Description'),
            'Action'=>$this->input->post('Action'));
         
        return $this->db->insert('disciplinary_action',$action);
        return $minimumMark->result();
    }
    function viewdisciplinary(){
        $sql="SELECT student_registration.Std_NIC as 'std_NIC', student_registration.Name as 'std_Name', module.Module_name as 'std_Module',disciplinary_action.Action as 'Action', disciplinary_status.Disciplinary as 'DIS_Status' FROM `disciplinary_action` 
        INNER JOIN student_exam_module ON disciplinary_action.ST_EX_MO_ID=student_exam_module.ST_EX_MO_ID
        INNER JOIN student_exam_course ON student_exam_module.ST_EX_CO_ID=student_exam_course.ST_EX_CO_ID
        INNER JOIN module ON student_exam_module.Module_ID=module.Module_ID
        INNER JOIN disciplinary_status ON disciplinary_action.Action=disciplinary_status.DIS_ST_ID
        INNER JOIN student_registration ON student_exam_course.STD_ID= student_registration.STD_ID";

        $query=$this->db->query( $sql);
        return $query->result();
    }

}
?>

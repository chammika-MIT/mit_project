<?php
class Payment_Model extends CI_Model{

    function getStaff(){
        $query=$this->db->query('SELECT * FROM staff WHERE Active=1');
        return $query->result();
    }

    function getStaffType(){
        $query=$this->db->query('SELECT * FROM staff_type');
        return $query->result();
    }    

    function getStaffConductExamByExamId($Exam_ID){
        $sql="SELECT staff_conducting_examination.STF_CON_EXM_ID, staff_conducting_examination.Exam_ID, staff_conducting_examination.STF_ID, staff.Name AS `Staff_Name`, 
        staff_conducting_examination.STF_TY_ID, staff_type.Staff_Type, staff_conducting_examination.EXC_ID, examination_center.Name,staff_conducting_examination.Course_ID,
        course.Course_name, staff_conducting_examination.Module_ID, module.Module_name, staff_conducting_examination.No_paper_marked,
        staff_conducting_examination.No_second_marked, staff_conducting_examination.No_recorrection_marked
        FROM staff_conducting_examination INNER JOIN staff ON staff_conducting_examination.STF_ID=staff.STF_ID 
        INNER JOIN staff_type ON staff_conducting_examination.STF_ID=staff_type.STF_TY_ID INNER JOIN
        examination_center ON staff_conducting_examination.EXC_ID=examination_center.EXC_ID INNER JOIN
        course ON staff_conducting_examination.Course_ID=course.Course_ID INNER JOIN
        module ON staff_conducting_examination.Module_ID=module.Module_ID WHERE
        staff_conducting_examination.Exam_ID=$Exam_ID";
        $query=$this->db->query($sql);
        return $query->result();
    }

    function insert_staff_conduct($Exam_ID){         
        $examconductdata=array(
            'Exam_ID'=>$Exam_ID,
            'STF_ID'=>$this->input->post('Staff'),
            'STF_TY_ID'=>$this->input->post('StaffType'),
            'EXC_ID'=>$this->input->post('ExamCenter'),
            'Course_ID'=>$this->input->post('Course'),
            'Module_ID'=>$this->input->post('Module'),
            'No_paper_marked'=>$this->input->post('PaperMarked'),
            'No_second_marked'=>$this->input->post('SecondPaperMarked'),
            'No_recorrection_marked'=>$this->input->post('RecorrectionPaperMarked')        
        );            
        return $this->db->insert('staff_conducting_examination',$examconductdata);        
    }

    function getStaffConductExamById($STF_CON_EXM_ID){
        $sql="SELECT staff_conducting_examination.STF_CON_EXM_ID, staff_conducting_examination.Exam_ID, staff_conducting_examination.STF_ID, staff.Name AS `Staff_Name`, 
        staff_conducting_examination.STF_TY_ID, staff_type.Staff_Type, staff_conducting_examination.EXC_ID, examination_center.Name,staff_conducting_examination.Course_ID,
        course.Course_name, staff_conducting_examination.Module_ID, module.Module_name, staff_conducting_examination.No_paper_marked,
        staff_conducting_examination.No_second_marked, staff_conducting_examination.No_recorrection_marked
        FROM staff_conducting_examination INNER JOIN staff ON staff_conducting_examination.STF_ID=staff.STF_ID 
        INNER JOIN staff_type ON staff_conducting_examination.STF_ID=staff_type.STF_TY_ID INNER JOIN
        examination_center ON staff_conducting_examination.EXC_ID=examination_center.EXC_ID INNER JOIN
        course ON staff_conducting_examination.Course_ID=course.Course_ID INNER JOIN
        module ON staff_conducting_examination.Module_ID=module.Module_ID WHERE
        staff_conducting_examination.STF_CON_EXM_ID=$STF_CON_EXM_ID";
        $query=$this->db->query($sql);
        return $query->result();
    }


    function update_staff_conduct($STF_CON_EXM_ID,$Exam_ID){  
        $examconductdata=array(
            'Exam_ID'=>$Exam_ID,
            'STF_ID'=>$this->input->post('Staff'),
            'STF_TY_ID'=>$this->input->post('StaffType'),
            'EXC_ID'=>$this->input->post('ExamCenter'),
            'Course_ID'=>$this->input->post('Course'),
            'Module_ID'=>$this->input->post('Module'),
            'No_paper_marked'=>$this->input->post('PaperMarked'),
            'No_second_marked'=>$this->input->post('SecondPaperMarked'),
            'No_recorrection_marked'=>$this->input->post('RecorrectionPaperMarked')        
        );        
        $this->db->where('STF_CON_EXM_ID', $STF_CON_EXM_ID);
        return $this->db->update('staff_conducting_examination', $examconductdata);              
        
    }

    public function delete_exam_conduct($STF_CON_EXM_ID){
        $this->db->query("DELETE FROM staff_conducting_examination WHERE STF_CON_EXM_ID='".$STF_CON_EXM_ID."'");
    }

}
?>
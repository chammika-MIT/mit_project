<?php
class ExamCenterModel extends CI_Model{

    public function __construct() {
        $this->load->database();
      }

    function displayexamcenter(){
        $query=$this->db->query('SELECT * FROM examination_center');
        return $query->result();
    }
    function displayexamcenterdistrict(){
        $query=$this->db->get('district');
        return $query->result();
    }
    function insert_examcenter_data(){
        
        $coursedata=array(
            'Name'=>$this->input->post('CenterName'),
            'Address'=>$this->input->post('Address'),
            'District_ID'=>$this->input->post('District_ID'),
            'Capacity'=>$this->input->post('Capacity'));
            
        return $this->db->insert('examination_center',$coursedata);
    }
   
      public function delete_exam_center($EXC_ID){
        $this->db->query("DELETE FROM examination_center WHERE EXC_ID='".$EXC_ID."'");

    }
    public function displayexamcenterbyid($EXC_ID){
        $query=$this->db->query("SELECT * FROM examination_center WHERE EXC_ID='".$EXC_ID."'");
        return $query->result();
    }
    public function update_exam_center($EXC_ID, $CenterName, $Address, $District_ID, $Capacity){
        $query=$this->db->query("UPDATE examination_center SET Name='$CenterName',Address='$Address', District_ID='$District_ID', Capacity='$Capacity' WHERE EXC_ID='".$EXC_ID."'");

    }
}
?>
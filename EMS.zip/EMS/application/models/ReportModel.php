<?php
class ReportModel extends CI_Model{

    function displaytrainingCenter(){
        $query=$this->db->query('SELECT * FROM training_center WHERE TC_ID !="P00/0000"');
        return $query->result();
    }
    function displayExamCenter(){
        $query=$this->db->query('SELECT * FROM examination_center');
        return $query->result();
    }
    function displayCourse(){
        $query=$this->db->query('SELECT * FROM course');
        return $query->result();
    }
    function displayModule(){
        $query=$this->db->query('SELECT * FROM module');
        return $query->result();
    }
    function get_exam_student_by_indexno_course($courseID,$excID,$Moudle_ID){
        $sql= "SELECT student_registration.Name, student_exam_course.Index_number, course.Course_name as 'course_name',module.Module_name as 'Module_name', examination_center.Name as 'Exc_Name' FROM student_exam_course 
        INNER JOIN course ON student_exam_course.Course_ID=course.Course_ID
        INNER JOIN examination_center ON student_exam_course.EXC_ID=examination_center.EXC_ID 
        INNER JOIN student_exam_module ON student_exam_course.ST_EX_CO_ID=student_exam_module.ST_EX_CO_ID
        INNER JOIN module ON student_exam_module.Module_ID=module.Module_ID
        INNER JOIN student_registration
        ON student_exam_course .STD_ID=student_registration.STD_ID
        WHERE student_exam_course.Course_ID=$courseID AND student_exam_course.EXC_ID=$excID AND student_exam_module.Module_ID=$Moudle_ID
        ORDER BY student_exam_course.Index_number";       
        $query=$this->db->query($sql);       
        return $query->result();
    }
    function get_exam_student_count_per_module($Course_ID){
        $sql= "SELECT COUNT(student_exam_course.STD_ID) AS `Student_Count`, module.Module_name, course.Course_name as 'Course' FROM student_exam_course INNER JOIN student_exam_module ON 
        student_exam_course.ST_EX_CO_ID=student_exam_module.ST_EX_CO_ID INNER JOIN module ON student_exam_module.Module_ID=module.Module_ID 
        INNER JOIN course ON module.Course_ID=course.Course_ID
        WHERE student_exam_course.Course_ID=$Course_ID
        GROUP BY student_exam_module.Module_ID ORDER BY module.Module_name";       
        $query=$this->db->query($sql);       
        return $query->result();
    }
    function displayCoursebyID($Course_ID){
        $query=$this->db->query('SELECT * FROM course WHERE Course_ID='.$Course_ID);
        return $query->result();
    }
    function displayDistrict(){
        $query=$this->db->query('SELECT * FROM district');
        return $query->result();
    }
    function studentPassRate($Course_ID){
        $sql="SELECT `pass_table`.Module_ID, `pass_table`.Module_name as 'Module_name',total_student,pass_student,
        CAST(((pass_student/total_student)*100) AS DECIMAL(11,2))  as 'pass_rate'  FROM (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `pass_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID WHERE  result.Marks>=40 AND module.Course_ID=$Course_ID
        Group BY student_exam_module.Module_ID) as `pass_table` INNER JOIN (SELECT module.Module_ID, module.Module_name, count(student_exam_module.Module_ID) as `total_student`  FROM `result` INNER JOIN student_exam_module ON result.ST_EX_MO_ID = student_exam_module.ST_EX_MO_ID INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID Group BY student_exam_module.Module_ID) AS `total_table` ON `pass_table`.Module_ID=`total_table`.Module_ID ORDER BY `pass_table`.Module_ID
        ";
        
        $query=$this->db->query($sql);
        return $query->result();
    }
    function get_student_count_per_course_and_district($District_ID){

        $sql="SELECT course.Course_ID, course.Course_name, count(student_registration.STD_ID) as `Student_Count`, district.District as 'district' FROM student_registration INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        INNER JOIN student_exam_course ON student_registration.STD_ID=student_exam_course.STD_ID
        INNER JOIN course ON student_exam_course.Course_ID=course.Course_ID
        INNER JOIN district ON training_center.District_ID=district.District_ID
        WHERE training_center.District_ID=$District_ID
        GROUP BY course.Course_ID";

        $query=$this->db->query($sql);
        return $query->result();
    }
    function get_reg_student_by_course_district(){
        $sql= "SELECT course.Course_name, district.District, count(student_registration.STD_ID) AS `Student_Count` FROM student_course INNER JOIN course ON 
        student_course.Course_ID=course.Course_ID INNER JOIN student_registration ON student_course.STD_ID=student_registration.STD_ID INNER JOIN training_center ON 
        student_registration.TC_ID=training_center.TC_ID INNER JOIN district ON training_center.District_ID=district.District_ID GROUP BY 
        student_course.Course_ID, training_center.District_ID ORDER BY course.Course_name, district.District";       
        $query=$this->db->query($sql);       
        return $query->result();
    }
    function studentResultcentercourse($TC_ID,$Course_ID,$Moudle_ID){
        $sql="SELECT student_registration.Std_NIC as 'NIC', student_registration.Name as 'Name', module.Module_name as 'Module',result.Marks as 
        'Result', training_center.Name as 'TC_Name', course.Course_name as 'Course' FROM `result`
        INNER JOIN student_exam_module ON result.ST_EX_MO_ID=student_exam_module.ST_EX_MO_ID
        INNER JOIN module ON student_exam_module.Module_ID=module.Module_ID
        INNER JOIN student_exam_course ON student_exam_module.ST_EX_CO_ID=student_exam_course.ST_EX_CO_ID
        INNER JOIN course ON student_exam_course.Course_ID =course.Course_ID
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        INNER JOIN student_course ON student_registration.STD_ID=student_course.STD_ID WHERE student_exam_module.Module_ID=$Moudle_ID AND student_exam_course.Course_ID=$Course_ID AND training_center.TC_ID=$TC_ID";
        
        $query=$this->db->query($sql);       
        return $query->result();
    }

    function modulestudentcount($Course_ID,$Moudle_ID){
        $sql="SELECT module.Module_name as 'module', count(student_exam_module.ST_EX_CO_ID) as 'total', course.Course_name as 'Course' FROM `student_exam_module`
        INNER JOIN student_exam_course ON student_exam_module.ST_EX_CO_ID=student_exam_course.ST_EX_CO_ID
        INNER JOIN course ON student_exam_course.Course_ID=course.Course_ID
        INNER JOIN module ON student_exam_module.Module_ID=module.Module_ID WHERE course.Course_ID=$Course_ID AND module.Module_ID=$Moudle_ID ORDER BY student_exam_module.ST_EX_CO_ID";
        
        $query=$this->db->query($sql);       
        return $query->result();
    }


}

<?php
class studentInfoModel extends CI_Model{

    public function __construct() {
        $this->load->database();
      }
    
    public function displaystudentbyNIC($Std_NIC){   
        $query=$this->db->query("SELECT * FROM student_registration WHERE Std_NIC='".$Std_NIC."'");
        return $query->result();
    }
    
    public function get_TC_ID(){
        $query = $this->db->get('training_center');
        return $query ->result();
    }
    public function get_Course_ID(){
        $course = $this->db->get('course');
        return $course ->result();
    }
    public function get_Student_Course_ID(){
        $course = $this->db->get('student_course');
        return $course ->result();
    }
    public function displaystudentwithresult($Std_NIC){   
        $sql="SELECT module.Module_name as 'Module', result.Marks as 'marks', module.Semester_No as 'semester', student_registration.Std_NIC FROM `result` 
        INNER JOIN student_exam_module ON result.ST_EX_MO_ID=student_exam_module.ST_EX_MO_ID
        INNER JOIN module ON student_exam_module.Module_ID=module.Module_ID
        INNER JOIN student_exam_course ON student_exam_module.ST_EX_CO_ID=student_exam_course.ST_EX_CO_ID
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID WHERE student_registration.Std_NIC LIKE '$Std_NIC' ORDER BY module.Semester_No";
       
        $query=$this->db->query($sql);
        return $query->result();
    }
    
    public function displaystudenttimetable($Std_NIC){  
        /* 
        $sql="SELECT module.Module_name as 'Module_Name', exam_schedule.Start_Time as 'Start_Date_Time', exam_schedule.End_Time as 'End_Date_Time', student_registration.Std_NIC as 'Std_NIC', module.Semester_No as 'Semester' FROM `exam_schedule`
        INNER JOIN student_exam_module ON exam_schedule.Module_ID=student_exam_module.Module_ID
        INNER JOIN module ON student_exam_module.Module_ID =module.Module_ID
        INNER JOIN student_exam_course ON student_exam_module.ST_EX_CO_ID=student_exam_course.ST_EX_CO_ID
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        WHERE exam_schedule.Start_Time>=NOW() AND student_registration.Std_NIC LIKE '$Std_NIC' ORDER BY module.Semester_No ASC";
       */
      $sql="SELECT module.Module_name as 'Module_Name', exam_schedule.Start_Time as 'Start_Date_Time', exam_schedule.End_Time as 'End_Date_Time', student_registration.Std_NIC as 'Std_NIC', module.Semester_No as 'Semester',result.Marks as 'Marks' FROM `exam_schedule`
      INNER JOIN student_exam_module ON exam_schedule.Module_ID=student_exam_module.Module_ID
      INNER JOIN module ON student_exam_module.Module_ID =module.Module_ID
      INNER JOIN student_exam_course ON student_exam_module.ST_EX_CO_ID=student_exam_course.ST_EX_CO_ID
      LEFT JOIN result ON student_exam_module.ST_EX_MO_ID=result.ST_EX_MO_ID
      INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
      WHERE exam_schedule.Start_Time>=NOW()  AND student_registration.Std_NIC LIKE '$Std_NIC' ORDER BY module.Semester_No ASC";
        $query=$this->db->query($sql);
        return $query->result();
    }
}
?>
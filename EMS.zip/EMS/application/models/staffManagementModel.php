<?php
class staffManagementModel extends CI_Model{

    public function __construct() {
        $this->load->database();
      }
    function displaystaff(){
        $query=$this->db->get('staff');

        return $query->result();
    }
    function getStaffType(){
        $stType=$this->db->get('staff_type');
        
        return $stType->result();
    }
    function getStafftraining(){
        $TC=$this->db->get('training_center');
        
        return $TC->result();
    }

/*
    function get_TC_ID(){
        $query = $this->db->get('training_center');
        return $query ->result();
    }
    function get_Course_ID(){
        $course = $this->db->get('course');
        return $course ->result();
    }
*/
    function insert_staff_data(){
        
        $staffdata=array(
            'Name'=>$this->input->post('Name'),
            'NIC'=>$this->input->post('Stf_NIC'),
            'Gender'=>$this->input->post('Gender'),
            'Contact_no_1'=>$this->input->post('Contact_no_1'),
            'Contact_no_2'=>$this->input->post('Contact_no_2'),
            'Email'=>$this->input->post('Email'),
            'STF_TY_ID'=>$this->input->post('Staff_Type'),
            'TC_ID'=>$this->input->post('TC_ID'),
            'Active'=>$this->input->post('Stf_status'));

  
            return $this->db->insert('staff',$staffdata);

        
    }
/*
    function insert_student_course($insert_id){
        $studentcourse=array(
            'STD_ID'=>$insert_id,
            'Course_ID'=>$this->input->post('Course_ID'));
            
        return $this->db->insert('student_course',$studentcourse);
    }
*/
    public function delete_staff($STF_ID){
        $this->db->query("DELETE FROM staff WHERE STF_ID='".$STF_ID."'");
    }

    public function displaystaffbyid($STF_ID){
        $query=$this->db->query("SELECT * FROM staff WHERE STF_ID='".$STF_ID."'");
        return $query->result();
    }
    
    public function update_staff($STF_ID, $Name, $NIC , $Gender, $Contact_No_1, $Contact_No_2, $Email, $STF_TY_ID, $Active){
        $query=$this->db->query("UPDATE staff SET Name='$Name',NIC='$NIC', 
        Gender='$Gender', Contact_No_1='$Contact_No_1', Contact_No_2='$Contact_No_2', Email='$Email', 
        STF_TY_ID='$STF_TY_ID', Active='$Active' WHERE STF_ID='".$STF_ID."'");
    } 
}
?>
<?php
class Exam_manage_Model extends CI_Model{

    function displaytrainingcenter(){
        $query=$this->db->query('SELECT * FROM training_center');
        return $query->result();
    }
    function displaytrainingcenterBYTCID($institute_id){
        $query=$this->db->query('SELECT * FROM training_center WHERE TC_ID='.$institute_id);
        return $query->result();
    }
    function displaytrainingcourse(){
        $query=$this->db->query('SELECT * FROM course');
        return $query->result();
    }

    function displaytrainingmodule(){
        $query=$this->db->query('SELECT * FROM module');
        return $query->result();
    }

    function getCreateExam($Exam_ID){
        $query=$this->db->query('SELECT * FROM create_exam WHERE Exam_ID='.$Exam_ID);
        return $query->result();
    }

    function displayexamtrainingmodule($trainingcenter,$trainingcourse,$semesterNo,$examId){
        $sql="SELECT student_registration.STD_ID,student_registration.Name,
        student_course.STD_Coure_ID, student_course.Course_ID,
        module.Module_ID, module.Module_code,
        student_exam_course.ST_EX_CO_ID, student_exam_course.Exam_ID, student_exam_course.EXC_ID,
        student_exam_module.ST_EX_MO_ID,  student_exam_module.Is_assign, student_exam_course.Index_number, student_exam_module.Is_attend
        FROM student_registration LEFT JOIN student_course ON 
        student_registration.STD_ID=student_course.STD_ID LEFT JOIN module ON 
        student_course.Course_ID=module.Course_ID  LEFT JOIN student_exam_course  ON 
        student_course.Course_ID = student_exam_course.Course_ID AND 
        student_course.STD_ID=student_exam_course.STD_ID AND student_exam_course.Exam_ID=".$examId." LEFT JOIN student_exam_module  ON 
        student_exam_course.ST_EX_CO_ID=student_exam_module.ST_EX_CO_ID AND 
        student_exam_module.Module_ID = module.Module_ID
        WHERE module.Course_ID=".$trainingcourse." AND student_registration.TC_ID=".$trainingcenter." AND module.Semester_No=".$semesterNo." ORDER BY
        student_registration.STD_ID,module.Module_ID";   
        //print_r($sql); exit;
        //print_r( $sql);
        $query=$this->db->query($sql);
        return $query->result();
    }

    function displayExamAttendanceModule($trainingcenter,$trainingcourse,$Exam_ID,$semesterNo){
        $sql="SELECT student_registration.STD_ID,student_registration.Name,
        student_course.STD_Coure_ID, student_course.Course_ID,
        module.Module_ID, module.Module_code,
        student_exam_course.ST_EX_CO_ID, student_exam_course.Exam_ID, student_exam_course.EXC_ID,
        student_exam_module.ST_EX_MO_ID,  student_exam_module.Is_assign, student_exam_course.Index_number, student_exam_module.Is_attend
        FROM student_registration LEFT JOIN student_course ON 
        student_registration.STD_ID=student_course.STD_ID LEFT JOIN module ON 
        student_course.Course_ID=module.Course_ID  LEFT JOIN student_exam_course  ON 
        student_course.Course_ID = student_exam_course.Course_ID AND 
        student_course.STD_ID=student_exam_course.STD_ID LEFT JOIN student_exam_module  ON 
        student_exam_course.ST_EX_CO_ID=student_exam_module.ST_EX_CO_ID AND 
        student_exam_module.Module_ID = module.Module_ID
        WHERE module.Course_ID=".$trainingcourse." AND student_registration.TC_ID=".$trainingcenter." AND module.Semester_No=".$semesterNo." AND student_exam_course.Exam_ID=".$Exam_ID." ORDER BY
        student_registration.STD_ID,module.Module_ID";        
        $query=$this->db->query($sql);
        return $query->result();
    }



    function getStudentExamModuleAssign($trainingcenter,$trainingcourse){
        $sql="SELECT CONCAT(student_exam_course.STD_ID,"."'-'".",student_exam_module.Module_ID,"."'-'".",student_exam_course.ST_EX_CO_ID,"."'-'".",student_exam_module.ST_EX_MO_ID)  
        as `Exam_Module_Ids` FROM `student_exam_course` INNER JOIN  `student_exam_module`  ON 
        student_exam_course.ST_EX_CO_ID=student_exam_module.ST_EX_CO_ID INNER JOIN student_registration ON
        student_exam_course.STD_ID = student_registration.STD_ID 
        WHERE student_exam_module.Is_assign=1 AND  student_exam_course.Course_ID=$trainingcourse AND 
        student_registration.TC_ID =$trainingcenter";
        
        $query=$this->db->query($sql);
        
        return $query->result();
    }

    function getStudentExamModuleAttendance($trainingcenter,$trainingcourse){
        $sql="SELECT CONCAT(student_exam_course.STD_ID,"."'-'".",student_exam_module.Module_ID,"."'-'".",student_exam_course.ST_EX_CO_ID,"."'-'".",student_exam_module.ST_EX_MO_ID)  
        as `Exam_Module_Ids` FROM `student_exam_course` INNER JOIN  `student_exam_module`  ON 
        student_exam_course.ST_EX_CO_ID=student_exam_module.ST_EX_CO_ID INNER JOIN student_registration ON
        student_exam_course.STD_ID = student_registration.STD_ID 
        WHERE student_exam_module.Is_attend=1 AND  student_exam_course.Course_ID=$trainingcourse AND 
        student_registration.TC_ID =$trainingcenter";
        
        $query=$this->db->query($sql);
        
        return $query->result();
    }
    
    function insert_data($studentExamcourse){   

       return $this->db->insert_batch('student_exam_course',$studentExamcourse);
    }

    function insert_course_student_data($result,$ExamID,$courseID,$centerID){
        $studentTempId=0;
       $studentModuleResult=$this->Exam_manage_Model->getStudentExamModuleAssign($centerID,$courseID);
       $studentModuleResult = json_decode( json_encode($studentModuleResult), true);
      
        $studentModuleDelete = array_column($studentModuleResult,"Exam_Module_Ids");

        $studentExamcourseInsert=array();
        $studentExamcourseUpdate=array();
        $insert_student_course_id=0;
        $this->db->trans_start();

          //print_r( $studentModuleDelete);
       
        
        
        foreach ($result as $row):
           // print_r($row);
            if (($key = array_search($row,  $studentModuleDelete)) !== false) {
                unset( $studentModuleDelete[$key]);
            }
           
          
           
            $studentmodule=explode("-",$row);
            $studentID=$studentmodule[0];
            $moduleID=$studentmodule[1];
            $studentExamCourseId=$studentmodule[2];
            $studentExamModuleId=$studentmodule[3];
            
            
            if($studentTempId!=$studentID && $studentExamCourseId==Null){
                $studentTempId= $studentID;  
                $std_Ex_course =  array (                
                    'STD_ID' => $studentID,
                    'Exam_ID' => $ExamID,
                    'Course_ID' =>$courseID,
                    'Active' => '0'
                  );                   
                  
                $this->db->insert('student_exam_course',$std_Ex_course);
                $insert_student_course_id = $this->db->insert_id(); 
                      
                
            }  
            if($insert_student_course_id!=0 ||  $studentExamModuleId==NULL){     
                        
                $std_Ex_module_insert =  array (                
                    'ST_EX_CO_ID' => ($studentExamCourseId==NULL) ? $insert_student_course_id : $studentExamCourseId,
                    'Module_ID' => $moduleID,
                    'Is_assign' => '1',
                    'Is_attend' => '0',
                    'Is_repeat' => '0'              
                  );   
                  array_push($studentExamcourseInsert, $std_Ex_module_insert);  
            }            
            else if($studentExamModuleId!=NULL){
                $std_Ex_module_update =  array (                
                    'ST_EX_CO_ID' =>  $studentExamCourseId,
                    'ST_EX_MO_ID' => $studentExamModuleId,
                    'Module_ID' => $moduleID,
                    'Is_assign' => '1',
                    'Is_attend' => '0',
                    'Is_repeat' => '0'              
                  );   
                  array_push($studentExamcourseUpdate, $std_Ex_module_update);                 
            }
          //  print_r($studentExamcourseUpdate);         
           // print_r($insert_student_course_id);
           // exit; 
             
        endforeach;
        
        //print_r($studentExamcourseInsert);exit; 
        
        if(!empty($studentExamcourseInsert))
        //print_r($studentExamcourseInsert);
       // exit;
        $respone=$this->db->insert_batch('student_exam_module',$studentExamcourseInsert);
    
        if(!empty($studentExamcourseUpdate))
        $respone=$this->db->update_batch('student_exam_module',$studentExamcourseUpdate, 'ST_EX_MO_ID');
        
        //print_r($studentModuleDelete);
        $studentExamcourseUpdate=array();
        foreach ($studentModuleDelete as $row):
            $studentmodule=explode("-",$row);
            $studentID=$studentmodule[0];
            $moduleID=$studentmodule[1];
            $studentExamCourseId=$studentmodule[2];
            $studentExamModuleId=$studentmodule[3];
            $std_Ex_module_update =  array (               
               
                'ST_EX_MO_ID' => $studentExamModuleId,
              
                'Is_assign' => '0'
                            
              );   
              array_push($studentExamcourseUpdate, $std_Ex_module_update);    
        endforeach;

        if(!empty($studentExamcourseUpdate))
        $respone=$this->db->update_batch('student_exam_module',$studentExamcourseUpdate, 'ST_EX_MO_ID');
                  
        //print_r($respone); exit;
        $this->db->trans_complete(); 
        return $respone;
        
    }

    function displayExamCenterStudent($trainingCenter,$trainingCourse,$examId){
        $sql="SELECT student_registration.STD_ID,student_registration.Name AS `Student_Name` , examination_center.EXC_ID AS `Exam_Center_Id`, examination_center.Name AS `Exam_Center_Name`, 
        student_exam_course.ST_EX_CO_ID, student_exam_course.Exam_ID, student_exam_course.EXC_ID AS `Exam_Course_Center_Id`, student_exam_course.Index_number  FROM student_registration INNER JOIN
        training_center ON student_registration.TC_ID= training_center.TC_ID INNER JOIN examination_center 
        ON training_center.District_ID= examination_center.District_ID INNER JOIN 
        student_exam_course ON student_registration.STD_ID=student_exam_course.STD_ID  WHERE student_exam_course.Course_ID=".$trainingCourse." 
        AND student_registration.TC_ID=".$trainingCenter."  AND student_exam_course.Exam_ID=".$examId."
        ORDER BY student_registration.STD_ID";     
        $query=$this->db->query($sql);       
        return $query->result();
    }

    function getNotCreatedIndexNoList($examId){
        $sql="SELECT examination_center.District_ID,create_exam.Level,create_exam.Semester,create_exam.Year,student_exam_course.ST_EX_CO_ID,student_exam_course.STD_ID 
        FROM create_exam INNER JOIN student_exam_course ON create_exam.Exam_ID=student_exam_course.Exam_ID INNER JOIN 
        examination_center ON student_exam_course.EXC_ID=examination_center.EXC_ID WHERE create_exam.Exam_ID=".$examId." AND student_exam_course.Index_number IS NULL";     
        $query=$this->db->query($sql);       
        return $query->result();
    }


    // function getStudentExamCenterID($trainingcenter,$trainingcourse,$examId){
    //     $sql="SELECT student_exam_course.ST_EX_CO_ID 
    //     as `Student_Exam_Center_Ids` FROM `student_exam_course` INNER JOIN student_registration ON
    //     student_exam_course.STD_ID = student_registration.STD_ID 
    //     WHERE student_exam_course.EXC_ID IS NOT NULL   AND  student_exam_course.Course_ID=$trainingcourse AND 
    //     student_registration.TC_ID =$trainingcenter  AND student_exam_course.Exam_ID=".$examId;  
         
    //     $query=$this->db->query($sql);        
    //     return $query->result();
    // }
    
    function update_student_exam_center($result,$ExamID,$courseID,$centerID){
        //print_r($result);exit;
        $studentExamcourseUpdate=array();         
        $this->db->trans_start();                         
        foreach ($result as $row):
            $studentexamcenter=explode("-",$row);  
                     
            $studentExamCourseId=$studentexamcenter[0];
            $studentExamCenterId=$studentexamcenter[1];          
           
                $std_Ex_center_update =  array (                
                    'ST_EX_CO_ID' => $studentExamCourseId,
                    'EXC_ID' => $studentExamCenterId                  
                  );  
                                     
                  array_push($studentExamcourseUpdate, $std_Ex_center_update);   
                           
        endforeach; 
              
        if(!empty($studentExamcourseUpdate))
        $respone=$this->db->update_batch('student_exam_course',$studentExamcourseUpdate, 'ST_EX_CO_ID');        
        $this->db->trans_complete(); 
        return $respone;        
    }

    function update_student_attendance($result,$ExamID,$courseID,$centerID){
       $studentTempId=0;
       $studentModuleResult=$this->Exam_manage_Model->getStudentExamModuleAttendance($centerID,$courseID);
       $studentModuleResult = json_decode( json_encode($studentModuleResult), true);
      
        $studentModuleDelete = array_column($studentModuleResult,"Exam_Module_Ids");

        $studentExamcourseInsert=array();
        $studentExamcourseUpdate=array();
        $insert_student_course_id=0;
        $this->db->trans_start();

          //print_r( $studentModuleDelete);
       
           
        
        foreach ($result as $row):
           // print_r($row);
            if (($key = array_search($row,  $studentModuleDelete)) !== false) {
                unset( $studentModuleDelete[$key]);
            }
           
          
           
            $studentmodule=explode("-",$row);
            $studentID=$studentmodule[0];
            $moduleID=$studentmodule[1];
            $studentExamCourseId=$studentmodule[2];
            $studentExamModuleId=$studentmodule[3];
            
                                     
            if($studentExamModuleId!=NULL){
                $std_Ex_module_update =  array (             
                    'ST_EX_MO_ID' => $studentExamModuleId,                   
                    'Is_attend' => '1'                              
                  );   
                  array_push($studentExamcourseUpdate, $std_Ex_module_update);                 
            }
                      
            endforeach;
             
        foreach ($studentModuleDelete as $row):
            $studentmodule=explode("-",$row);
            $studentID=$studentmodule[0];
            $moduleID=$studentmodule[1];
            $studentExamCourseId=$studentmodule[2];
            $studentExamModuleId=$studentmodule[3];
            $std_Ex_module_update =  array (       
                'ST_EX_MO_ID' => $studentExamModuleId,              
                'Is_attend' => '0'                            
            );   
              array_push($studentExamcourseUpdate, $std_Ex_module_update);    
        endforeach;

        if(!empty($studentExamcourseUpdate))
        $respone=$this->db->update_batch('student_exam_module',$studentExamcourseUpdate, 'ST_EX_MO_ID');
                  
        //print_r($respone); exit;
        $this->db->trans_complete(); 
        return $respone;
        
    }

    function update_student_exam_index_no($ExamID){
        //print_r($result);exit;
        $studentExamcourseUpdate =array();
        $studentExamIndexNos=$this->Exam_manage_Model->getNotCreatedIndexNoList($ExamID);         
        $this->db->trans_start();                         
        foreach ($studentExamIndexNos as $row):
            
             $indexNo = sprintf("%02d", $row->District_ID).$row->Level.$row->Semester.substr($row->Year, -2).sprintf("%04d", $row->ST_EX_CO_ID);             
                $std_Ex_index_update =  array (                
                    'ST_EX_CO_ID' => $row->ST_EX_CO_ID,
                    'Index_number' =>  $indexNo                  
                  );  
                                     
                  array_push($studentExamcourseUpdate, $std_Ex_index_update);   
                           
        endforeach; 
        $response='';  
        if(!empty($studentExamcourseUpdate))
        $response=$this->db->update_batch('student_exam_course',$studentExamcourseUpdate, 'ST_EX_CO_ID');        
        $this->db->trans_complete(); 
        return $response;        
    }

    function get_exam_admmission_list($trainingcenter,$trainingcourse,$Exam_ID){
    $sql="SELECT student_registration.STD_ID, student_exam_course.Index_number, course.Course_code 
    AS `Course_Code`, course.Course_name AS `Course_name`, student_registration.Std_NIC, student_registration.Name 
    AS `Student_name`,create_exam.Level, create_exam.Semester, create_exam.Year, examination_center.Name 
    AS `Exam_Center_name`, examination_center.Address, module.Module_code, module.Module_name 
    AS `Module_name`,exam_schedule.Start_Time, exam_schedule.End_Time  FROM student_exam_course 
    INNER JOIN student_registration ON student_exam_course.STD_ID= student_registration.STD_ID 
    INNER JOIN course ON student_exam_course.Course_ID=course.Course_ID 
    INNER JOIN create_exam ON student_exam_course.Exam_ID=create_exam.Exam_ID INNER JOIN 
    examination_center ON student_exam_course.EXC_ID = examination_center.EXC_ID 
    INNER JOIN student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
    INNER JOIN module ON student_exam_module.Module_ID=module.Module_ID
    LEFT JOIN exam_schedule ON exam_schedule.Exam_ID=student_exam_course.Exam_ID AND 
    exam_schedule.Course_ID=student_exam_course.Course_ID AND exam_schedule.Module_ID=student_exam_module.Module_ID  
    WHERE student_registration.TC_ID=".$trainingcenter." AND create_exam.Exam_ID=".$Exam_ID." AND student_exam_course.Course_ID=".$trainingcourse." 
    AND module.Semester_No=1 AND student_exam_course.Index_number IS NOT NULL ORDER BY student_registration.STD_ID";
    
              /* $sql= "SELECT student_registration.STD_ID, student_exam_course.Index_number, course.Course_name AS `Course_name`, student_registration.Std_NIC, student_registration.Name AS `Student_name`, 
              create_exam.Level, create_exam.Semester, examination_center.Name AS `Exam_Center_name`, examination_center.Address, module.Module_code, 
              module.Module_name AS `Module_name` FROM student_exam_course 
              INNER JOIN student_registration ON student_exam_course.STD_ID= student_registration.STD_ID INNER JOIN course ON student_exam_course.Course_ID=course.Course_ID 
              INNER JOIN create_exam ON student_exam_course.Exam_ID=create_exam.Exam_ID INNER JOIN examination_center ON student_exam_course.EXC_ID = examination_center.EXC_ID 
              INNER JOIN student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID INNER JOIN module ON 
              student_exam_module.Module_ID=module.Module_ID WHERE student_registration.TC_ID=".$trainingCenter." AND create_exam.Exam_ID=".$examId." 
              AND student_exam_course.Course_ID=".$trainingCourse." AND student_exam_course.Index_number IS NOT NULL ORDER BY student_registration.STD_ID";        */
        $query=$this->db->query($sql);       
        return $query->result();
    }

    function get_exam_schedule($Exam_ID){
        $sql= "SELECT exam_schedule.EX_SCH_ID, exam_schedule.Exam_ID, exam_schedule.Course_ID, course.Course_name, exam_schedule.Module_ID, module.Module_name, 
        exam_schedule.Start_Time, exam_schedule.End_Time, create_exam.Level, create_exam.Semester, create_exam.Year   FROM exam_schedule INNER JOIN course ON exam_schedule.Course_ID=course.Course_ID INNER JOIN module ON 
        exam_schedule.Module_ID=module.Module_ID INNER JOIN create_exam ON exam_schedule.Exam_ID=create_exam.Exam_ID  WHERE exam_schedule.Exam_ID=".$Exam_ID.
        " ORDER BY exam_schedule.Start_Time, exam_schedule.Course_ID, exam_schedule.Module_ID";       
        $query=$this->db->query($sql);       
        return $query->result();
    }

    function get_exam_schedule_by_id($EX_SCH_ID){
        $sql= "SELECT exam_schedule.EX_SCH_ID, exam_schedule.Exam_ID, exam_schedule.Course_ID, course.Course_name, exam_schedule.Module_ID, module.Module_name, 
        exam_schedule.Start_Time, exam_schedule.End_Time  FROM exam_schedule INNER JOIN course ON exam_schedule.Course_ID=course.Course_ID INNER JOIN module ON 
        exam_schedule.Module_ID=module.Module_ID WHERE exam_schedule.EX_SCH_ID=".$EX_SCH_ID." ORDER BY exam_schedule.Start_Time, exam_schedule.Course_ID, exam_schedule.Module_ID";       
        $query=$this->db->query($sql);       
        return $query->result();
    }

    function insert_exam_schedule($Exam_ID){        
        $scheduledata=array(
            'Exam_ID'=>$Exam_ID,
            'Course_ID'=>$this->input->post('Course'),
            'Module_ID'=>$this->input->post('Module'),
            'Start_Time'=>$this->input->post('Start_Time'),
            'End_Time'=>$this->input->post('End_Time'));
            
        return $this->db->insert('exam_schedule',$scheduledata);
        return $scheduledata->result();
    }

    function update_exam_schedule($EX_SCH_ID){  
        $course=$this->input->post('Course');
        $module=$this->input->post('Module');
        $Start_Time=$this->input->post('Start_Time');
        $End_Time=$this->input->post('End_Time');
        $update= "UPDATE exam_schedule SET Course_ID=$course, Module_ID=$module,Start_Time='$Start_Time',End_Time='$End_Time' WHERE EX_SCH_ID=$EX_SCH_ID"; 
        //print_r($update); exit();
        $query=$this->db->query($update);       
        
    }

    public function delete_exam_schedule($EX_SCH_ID){
        $this->db->query("DELETE FROM exam_schedule WHERE EX_SCH_ID='".$EX_SCH_ID."'");
    }

    function displayexamcenter(){
        $query=$this->db->query('SELECT * FROM examination_center');
        return $query->result();
    }

    function get_exam_schedule_by_course_order($Exam_ID){
        $sql= "SELECT exam_schedule.EX_SCH_ID, exam_schedule.Exam_ID, exam_schedule.Course_ID, course.Course_code, course.Course_name, exam_schedule.Module_ID, module.Module_code, 
        module.Module_name, exam_schedule.Start_Time, exam_schedule.End_Time, create_exam.Level, create_exam.Semester, create_exam.Year FROM exam_schedule INNER JOIN course ON 
        exam_schedule.Course_ID=course.Course_ID INNER JOIN module ON exam_schedule.Module_ID=module.Module_ID INNER JOIN create_exam ON 
        exam_schedule.Exam_ID=create_exam.Exam_ID WHERE exam_schedule.Exam_ID=".$Exam_ID." ORDER BY exam_schedule.Course_ID, exam_schedule.Start_Time, exam_schedule.Module_ID";       
        $query=$this->db->query($sql);       
        return $query->result();
    } 
    /*
    function get_exam_student_count_per_module(){
        $sql= "SELECT COUNT(student_exam_course.STD_ID) AS `Student_Count`, module.Module_name FROM student_exam_course INNER JOIN student_exam_module ON 
        student_exam_course.ST_EX_CO_ID=student_exam_module.ST_EX_CO_ID INNER JOIN module ON student_exam_module.Module_ID=module.Module_ID
        GROUP BY student_exam_module.Module_ID ORDER BY module.Module_name";       
        $query=$this->db->query($sql);       
        return $query->result();
    } 

    function get_reg_student_by_course_district(){
        $sql= "SELECT course.Course_name, district.District, count(student_registration.STD_ID) AS `Student_Count` FROM student_course INNER JOIN course ON 
        student_course.Course_ID=course.Course_ID INNER JOIN student_registration ON student_course.STD_ID=student_registration.STD_ID INNER JOIN training_center ON 
        student_registration.TC_ID=training_center.TC_ID INNER JOIN district ON training_center.District_ID=district.District_ID GROUP BY 
        student_course.Course_ID, training_center.District_ID ORDER BY course.Course_name, district.District";       
        $query=$this->db->query($sql);       
        return $query->result();
    } 

    function get_exam_student_by_indexno_course($courseID,$excID){
        $sql= "SELECT student_registration.Name, student_exam_course.Index_number FROM student_exam_course INNER JOIN course ON student_exam_course.Course_ID=course.Course_ID
        INNER JOIN examination_center ON student_exam_course.EXC_ID=examination_center.EXC_ID INNER JOIN student_registration
        ON student_exam_course.STD_ID=student_registration.STD_ID
        WHERE student_exam_course.Course_ID=$courseID AND student_exam_course.EXC_ID=$excID ORDER BY student_registration.Name";       
        $query=$this->db->query($sql);       
        return $query->result();
    }
    */

    // Recorection module and student view

    function displayexamtrainingmoduleRecorrection($trainingcenter,$trainingcourse,$semesterNo){
        $sql="SELECT student_registration.STD_ID,student_registration.Name,
        student_course.STD_Coure_ID, student_course.Course_ID,
        module.Module_ID, module.Module_code,
        student_exam_course.ST_EX_CO_ID, student_exam_course.Exam_ID, student_exam_course.EXC_ID,
        student_exam_module.ST_EX_MO_ID,  student_exam_module.Is_assign, student_exam_course.Index_number, 
        student_exam_module.Is_attend, result.ST_EX_MO_ID as `result_ST_EX_MO_ID`,  result.Marks, 
        exam_fee_rate.EX_FEE_RATE_ID, exam_fee_rate.Amount, recurrection_request.RE_REQ_ID
        FROM student_registration LEFT JOIN student_course ON 
        student_registration.STD_ID=student_course.STD_ID LEFT JOIN module ON 
        student_course.Course_ID=module.Course_ID  LEFT JOIN student_exam_course  ON 
        student_course.Course_ID = student_exam_course.Course_ID AND 
        student_course.STD_ID=student_exam_course.STD_ID LEFT JOIN student_exam_module  ON 
        student_exam_course.ST_EX_CO_ID=student_exam_module.ST_EX_CO_ID AND 
        student_exam_module.Module_ID = module.Module_ID
        LEFT JOIN result ON student_exam_module.ST_EX_MO_ID=result.ST_EX_MO_ID
        LEFT JOIN exam_fee_rate ON student_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID 
        LEFT JOIN recurrection_request ON result.ST_EX_MO_ID =recurrection_request.ST_EX_MO_ID
        WHERE module.Course_ID=".$trainingcourse." AND student_registration.TC_ID=".$trainingcenter." AND 
        module.Semester_No=".$semesterNo."  ORDER BY
        student_registration.STD_ID,module.Module_ID"; 
        
        $query=$this->db->query($sql);
        return $query->result();
    }

    function getStudentRecorrectionModuleAssign($trainingcenter,$trainingcourse){
        
        $sql="SELECT CONCAT(recurrection_request.RE_REQ_ID,"."'-'".",result.ST_EX_MO_ID,"."'-'".",exam_fee_rate.EX_FEE_RATE_ID)  
        as `Exam_Rec_Module_Ids` FROM `student_exam_course` INNER JOIN  `student_exam_module`  ON 
        student_exam_course.ST_EX_CO_ID=student_exam_module.ST_EX_CO_ID INNER JOIN student_registration ON
        student_exam_course.STD_ID = student_registration.STD_ID 
        INNER JOIN result ON student_exam_module.ST_EX_MO_ID=result.ST_EX_MO_ID
        INNER JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID 
        INNER JOIN recurrection_request ON result.ST_EX_MO_ID =recurrection_request.ST_EX_MO_ID
        WHERE student_exam_course.Course_ID=$trainingcourse AND 
        student_registration.TC_ID =$trainingcenter";
       
        $query=$this->db->query($sql);       
        return $query->result();
    }

    function insert_recorrection_student_data($result,$ExamID,$courseID,$centerID){

        //$sql="INSERT INTO recurrection_request VALUES (2,43,'2018-11-23 17:31:26',1, NULL)";
        //$respone=$this->db->query( $sql);
        //exit;
       
       $studentModuleRecorrection=$this->getStudentRecorrectionModuleAssign($centerID,$courseID);
       
       $studentModuleRecorrection = json_decode( json_encode($studentModuleRecorrection), true);
        //$studentModuleRecorrection = array_column($studentModuleRecorrection,"[Exam_Rec_Module_Ids]");
       
        $studentExamRecorrectInsert=array();
        //$studentExamcourseUpdate=array();

        //$this->db->trans_start();

       

       
           
        
        foreach ($result as $row):
           //print_r($row);exit;
           $studentmodulerec=explode("-",$row);
           $recID=$studentmodulerec[0];
           $moduleID=$studentmodulerec[1];
           $rateId=$studentmodulerec[2];
          
            if (($key = array_search($row,  $studentModuleRecorrection)) !== false) {

                unset( $studentModuleRecorrection[$key]);
                
            }
            else{
                $std_Ex_correction =  array (                              
                    'ST_EX_MO_ID' => $moduleID,
                    'Request_date' => 'curdate()',
                    'EX_RATE_ID' =>$rateId,
                    'Receipt_file_name' => NULL
                );  
                
                array_push($studentExamRecorrectInsert, $std_Ex_correction);    
            }    
            
           // print_r($insert_student_course_id);
           // exit; 
             
        endforeach;
        //print_r($studentExamRecorrectInsert); exit;
        if(!empty($studentExamRecorrectInsert))
        $respone=$this->db->insert_batch('recurrection_request',$studentExamRecorrectInsert);
       
        
        
        
        
        $studentExamcorrectionDelete=array();
        foreach ($studentModuleRecorrection as $row):
            
            $studentmodulerec=explode("-",$row['Exam_Rec_Module_Ids']);
            $recID=$studentmodulerec[0];
            $moduleID=$studentmodulerec[1];
            $rateId=$studentmodulerec[2];           
              array_push($studentExamcorrectionDelete, $recID);    
        endforeach;
        //print_r($studentExamcorrectionDelete); exit; 
        if(!empty($studentExamcorrectionDelete)) {
            $this->db->where_in('RE_REQ_ID', $studentExamcorrectionDelete);
            $respone=$this->db->delete('recurrection_request');  
        }       
        
          
        //print_r($respone); exit;
        //$this->db->trans_complete(); 
        return $respone;
        
    }
}
?>
<?php

class ManageInstituteModel extends CI_Model{

    public function __construct() {
        $this->load->database();
      }

    function insert_training_center_data(){
        
        $tradata=array(
            'Reg_No'=>$this->input->post('Reg_No',TRUE),
            'Name'=>$this->input->post('CenterName',TRUE),
            'Address'=>$this->input->post('PermanentAddress',TRUE),
            'District_ID'=>$this->input->post('District'),
            'Email'=>$this->input->post('Email',TRUE),
            'ContactNo'=>$this->input->post('Mobile',TRUE));
            
            
        return $this->db->insert('training_center',$tradata);
    }
    function get_district(){
        $query = $this->db->get('district');
        return $query ->result();
    }
    function displaytraininginstitute(){
        $query=$this->db->query('SELECT * FROM training_center where Reg_No !="P00/0000" ORDER BY Reg_No ASC');
        return $query->result();
    }

    function displaytraininginstituteById($institute_id){
        $query=$this->db->query('SELECT * FROM training_center WHERE TC_ID='.$institute_id);
        return $query->result();
    }
    
    public function delete_training_center($TC_ID){
        $this->db->query("DELETE FROM training_center WHERE TC_ID='".$TC_ID."'");

    }
    public function displaytrainingcenterbyid($TC_ID){
        $query=$this->db->query("SELECT * FROM training_center WHERE TC_ID='".$TC_ID."'");
        return $query->result();
    }
    public function update_trainingcenter($TC_ID, $Reg_No, $CenterName, $PermanentAddress, $District_ID, $Email_address, $ContactNo){
        $query=$this->db->query("UPDATE training_center SET Reg_No='$Reg_No',Name='$CenterName', Address='$PermanentAddress', District_ID='$District_ID', Email='$Email_address', ContactNo='$ContactNo' WHERE TC_ID='".$TC_ID."'");
        return TRUE;
    }
    public function update_trainingcenterbycenter($TC_ID, $PermanentAddress, $District_ID, $Email_address, $ContactNo){
        $query=$this->db->query("UPDATE training_center SET Address='$PermanentAddress', District_ID='$District_ID', Email='$Email_address', ContactNo='$ContactNo' WHERE TC_ID='".$TC_ID."'");
        return TRUE;
    }
}
?>
<?php
class LoginManagModel extends CI_Model{

    public function login(){

        $Username=$this->input->post('Username');
        $Password=sha1($this->input->post('Password'));

        $this->db->where('Username',$Username);
        $this->db->where('Password',$Password);

        $respond=$this->db->get('users');

        if($respond->num_rows()==1){

            return $respond->row(0);

        }else{
            return false;
        }
    }
    public function resetPassword(){

        $Username=$this->input->post('Username');
        $Password=sha1($this->input->post('CurrentPassword'));
        $NewPassword=sha1($this->input->post('NewPassword'));
       // $Password=sha1($this->input->post('Password'));

        $this->db->where('Username',$Username);
        $this->db->where('Password',$Password);

        $respond=$this->db->get('users');

        if($respond->num_rows()==1){

            $respond=$this->db->query("UPDATE users SET Password='$NewPassword' WHERE Username='$Username' AND Password='$Password'");
            return TRUE;

        }else{
            return false;
        }
    }


    function stGenderchartdata(){
        $sql='SELECT Gender,COUNT(Gender) AS Total  FROM student_registration GROUP BY Gender';
        //$query=$this->db->query($sql);
       // return $query->result();
        return $this->db->query($sql)->result_array();
    }
    function TCchartdata(){
        $sql='SELECT district.District, COUNT(training_center.District_ID) AS Total FROM district 
        INNER JOIN training_center ON district.District_ID=training_center.District_ID 
        GROUP BY training_center.District_ID';
        //$query=$this->db->query($sql);
       // return $query->result();
        return $this->db->query($sql)->result_array();
    }
    function stCoursechartdata(){
        $sql='SELECT course.Course_name, COUNT(student_course.Course_ID) AS Total FROM course
        INNER JOIN student_course ON course.Course_ID=student_course.Course_ID 
        GROUP BY student_course.Course_ID';
        //$query=$this->db->query($sql);
       // return $query->result();
        return $this->db->query($sql)->result_array();
    }
    function distrcitStudentchart(){
        $sql="SELECT district.District as 'District', COUNT(student_registration.TC_ID) as 'Total' FROM `training_center` INNER JOIN student_registration ON student_registration.TC_ID=training_center.TC_ID INNER JOIN district ON training_center.District_ID
        =district.District_ID GROUP BY student_registration.TC_ID";
        //$query=$this->db->query($sql);
       // return $query->result();
        return $this->db->query($sql)->result_array();
    }

}
?>
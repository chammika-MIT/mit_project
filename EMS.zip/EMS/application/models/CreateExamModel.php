<?php
class CreateExamModel extends CI_Model{

    public function __construct() {
        $this->load->database();
      }

    function displayexam(){
        $query=$this->db->query('SELECT * FROM create_exam');
        return $query->result();
    }
    
    function insert_exam_data(){
        
        $examdata=array(
            'Level'=>$this->input->post('level'),
            'Semester'=>$this->input->post('semester'),
            'Year'=>$this->input->post('year'),
            'Application_start_date'=>$this->input->post('AppOpenDate'),
            'Application_end_date'=>$this->input->post('AppCloseDate'),
            'Exam_start_date'=>$this->input->post('ExamStartDate'),
            'Exam_end_date'=>$this->input->post('ExamEndDate'));
            
        return $this->db->insert('create_exam',$examdata);
    }
    
    public function delete_exam($Exam_ID){
        $this->db->query("DELETE FROM create_exam WHERE Exam_ID='".$Exam_ID."'");

    }

    public function displayexambyid($Exam_ID){
        $query=$this->db->query("SELECT * FROM create_exam WHERE Exam_ID='".$Exam_ID."'");
        return $query->result();
    }
    public function update_exam($Exam_ID, $Level, $Semester, $Year, $Application_start_date, $Application_end_date, $Exam_start_date, $Exam_end_date){
        $query=$this->db->query("UPDATE create_exam SET Level='$Level', Semester='$Semester', Year='$Year' , Application_start_date='$Application_start_date' , Application_end_date='$Application_end_date' , Exam_start_date='$Exam_start_date' , Exam_end_date='$Exam_end_date' WHERE Exam_ID='".$Exam_ID."'");

    }
    
}
?>
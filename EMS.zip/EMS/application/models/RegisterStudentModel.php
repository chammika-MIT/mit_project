<?php
class RegisterStudentModel extends CI_Model{

    public function __construct() {
        $this->load->database();
      }
    function displaystudents(){
        $query=$this->db->query('SELECT student_registration.STD_ID,student_registration.Std_NIC, student_registration.Name,
         student_registration.Gender, student_registration.Contact_no, student_registration.Email, student_registration.TC_ID,
         student_course.Course_ID, student_registration.Active, student_exam_course.Index_number 
         FROM student_registration
         INNER JOIN student_course
         ON student_registration.STD_ID=student_course.STD_ID 
         LEFT JOIN student_exam_course ON student_registration.STD_ID=student_exam_course.STD_ID'); 

         //return $this->db->join('student_registration', 'student_registration.STD_ID=student_course.STD_ID', 'INNER');

        return $query->result();
    }
    function displaystudentsByInstitute($institute_id){
        $query=$this->db->query('SELECT student_registration.STD_ID,student_registration.Std_NIC, student_registration.Name,
         student_registration.Gender, student_registration.Contact_no, student_registration.Email, student_registration.TC_ID,
         student_course.Course_ID, student_registration.Active, student_exam_course.Index_number 
         FROM student_registration
         INNER JOIN student_course
         ON student_registration.STD_ID=student_course.STD_ID 
         LEFT JOIN student_exam_course ON student_registration.STD_ID=student_exam_course.STD_ID
         WHERE student_registration.TC_ID='.$institute_id); 

        return $query->result();
    }

    function get_TC_ID(){
        $query = $this->db->get('training_center');
        return $query ->result();
    }
    function get_TC_ID_By_Inst($institute_id){
        $query = $this->db->query('SELECT * FROM training_center WHERE TC_ID='.$institute_id);
        return $query->result();
    }
    

    function insert_student_data(){
        
        $studentdata=array(
            'Std_NIC'=>$this->input->post('Std_NIC'),
            'Name'=>$this->input->post('Name'),
            'Gender'=>$this->input->post('Gender'),
            'Contact_no'=>$this->input->post('Contact_no'),
            'Email'=>$this->input->post('Email'),
            'TC_ID'=>$this->input->post('TC_ID'),
            'Active'=>$this->input->post('Std_status'));

        $this->db->trans_start();
        $this->db->insert('student_registration',$studentdata);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return $insert_id;
    }
    function insert_student_course($insert_id){
        $studentcourse=array(
            'STD_ID'=>$insert_id,
            'Course_ID'=>$this->input->post('Course_ID'));
            
        return $this->db->insert('student_course',$studentcourse);
    }

    public function delete_student($STD_ID){
        $this->db->query("DELETE FROM student_registration WHERE STD_ID='".$STD_ID."'");
        $this->db->query("DELETE FROM student_course WHERE STD_ID='".$STD_ID."'");
    }

    public function displaystudentbyid($STD_ID){
        $query=$this->db->query("SELECT * FROM student_registration WHERE STD_ID='".$STD_ID."'");
        return $query->result();
    }
    public function displaystudentcoursebyid($STD_ID){
        $course=$this->db->query("SELECT * FROM student_course WHERE STD_ID='".$STD_ID."'");
        return $course->result();
    }

    function get_Course_ID(){
        $course = $this->db->get('course');
        return $course ->result();
    }

    public function displayStudentBySTD_IS($STD_ID){
        $sql='SELECT student_registration.Std_NIC as "Std_NIC", student_registration.Name as "Name", 
        student_registration.Gender, student_registration.Contact_no as "Contact_No", 
        student_registration.Email, course.Course_name as "Course", training_center.Name as "Center", student_registration.TC_ID as "Reg_No" ,
        student_registration.Active, course.Course_ID as "Course_ID" FROM `student_registration` INNER JOIN student_course ON 
        student_registration.STD_ID =student_course.STD_ID INNER JOIN course ON 
        student_course.Course_ID=course.Course_ID INNER JOIN training_center ON 
        student_registration.TC_ID=training_center.TC_ID WHERE student_registration.STD_ID='.$STD_ID;

        $query=$this->db->query($sql);
        return $query ->result();
    }

    public function update_student($STD_ID, $Name, $Gender, $Contact_no, $Email, $Active, $Course_code){
        $query=$this->db->query("UPDATE student_registration SET Name='$Name', Gender='$Gender', Contact_no='$Contact_no', Email='$Email', Active='$Active' WHERE STD_ID='".$STD_ID."'");
        $query=$this->db->query("UPDATE student_course SET Course_ID='$Course_code' WHERE STD_ID='".$STD_ID."'");
    } 
    public function updateStudentByAdmin($STD_ID,$Std_NIC, $Name, $Gender, $Contact_no, $Email, $TC_ID, $Active,$Course_code){
        $query=$this->db->query("UPDATE student_registration SET Name='$Name', Gender='$Gender', Contact_no='$Contact_no', Email='$Email', Active='$Active' WHERE STD_ID='".$STD_ID."'");
        $query=$this->db->query("UPDATE student_course SET Course_ID='$Course_code' WHERE STD_ID='".$STD_ID."'");
    } 
}
?>
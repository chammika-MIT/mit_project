<?php
class UserModel extends CI_Model{

    function getUser(){
        $query=$this->db->query('SELECT users.User_ID, users.TC_ID, users.STF_ID, training_center.Name as `Center_Name`, staff.Name as `Staff_Name`, users.Username, users.Availability
                FROM users INNER JOIN training_center ON users.TC_ID=training_center.TC_ID INNER JOIN staff ON users.STF_ID=staff.STF_ID');
        return $query->result();
    }

    function getUserById($User_Id){
        $query=$this->db->query('SELECT * FROM users WHERE User_ID='.$User_Id);
        return $query->result();
    }
   
    function getTrainingCenters(){
        $query = $this->db->get('training_center');
        return $query ->result();
    }

    function getStaff(){
        $query = $this->db->get('staff');
        return $query ->result();
    }

    function getRole(){
        $query = $this->db->get('role');
        return $query ->result();
    }   
    

    function insert_user($userdata){      
        $userdata["Password"] =  sha1($this->input->post('Password'));       
        $this->db->trans_start();
        $this->db->insert('users',$userdata);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return $insert_id;
    }

    function getStaffById($STF_ID){
        $query=$this->db->query('SELECT * FROM staff WHERE STF_ID='.$STF_ID);
        return $query ->result();
    }

    function update_user($User_Id,$userdata){   
        $userdata["Password"] =  sha1($this->input->post('Password'));   
        $this->db->trans_start();
        $response = $this->db->update('users',$userdata, array('User_ID' =>$User_Id));       
        $this->db->trans_complete();
        return $response;
    }
    
    function getUserRoleById($User_Id){
        $query=$this->db->query('SELECT users.User_ID,user_role.Role_ID,role.Name as `role_name`,role.Description,staff.Name as `staff_name` FROM users LEFT JOIN user_role   ON 
                user_role.User_ID=users.User_ID LEFT JOIN role ON user_role.Role_ID=role.Role_ID LEFT JOIN staff ON users.STF_ID=staff.STF_ID WHERE users.User_ID='.$User_Id);
        return $query->result();
    }

    function insert_user_role(){    
        $userroledata = $this->input->post();   
       // print_r($userroledata); exit;            
        $this->db->trans_start();
        $response = $this->db->insert('user_role',$userroledata);               
        $this->db->trans_complete();         
        return $response;
    }

    function getUserByRoleId($User_Id, $Role_Id){
        $query=$this->db->query('SELECT user_role.User_ID FROM user_role WHERE user_role.User_ID='.$User_Id. ' AND user_role.Role_ID='.$Role_Id);
        return $query->result();
    }

    function delete_user_role($User_Id, $Role_Id){
        $this->db->query('DELETE FROM user_role WHERE user_role.User_ID='.$User_Id. ' AND user_role.Role_ID='.$Role_Id); 
    }
    
    function getUserRoleComponentAccess($Path){
        $user_data = $this->session->get_userdata(); 
        //print_r($User_Id);exit;
        $User_Id = $user_data['User_ID '];
        //print_r($User_Id);exit;
        $query=$this->db->query("SELECT component_access.Component_ID,component.Path FROM user_role 
        INNER JOIN component_access ON 
        user_role.Role_ID=component_access.Role_ID INNER JOIN component ON component_access.Component_ID
         WHERE user_role.User_ID=".$User_Id. " AND component.Path='".$Path."'");
        return $query->result();
    }
}
?>
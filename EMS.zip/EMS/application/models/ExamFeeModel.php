<?php
class ExamFeeModel extends CI_Model{

    function displayexamfee($TC_Id, $Exam_ID, $Course_Id){
        $sql='SELECT training_center.TC_ID, training_center.Name, student_exam_course.Course_ID, 
        course.Course_name, student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount ,
        sum(exam_fee_rate.Amount) as `module_amount`, student_exam_course.Exam_ID, exam_fee.Receipt_file_name  FROM student_exam_course INNER JOIN 
        student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID AND student_exam_module.Is_assign=1  
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID
        INNER JOIN course ON  student_exam_course.Course_ID = course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID
        LEFT JOIN exam_fee ON student_exam_course.Exam_ID=exam_fee.Exam_ID AND  
        student_registration.TC_ID=exam_fee.TC_ID WHERE student_exam_course.Exam_ID='.$Exam_ID.'
        AND student_registration.TC_ID='.$TC_Id.' AND student_exam_course.Course_ID='.$Course_Id.' GROUP BY student_exam_module.Module_ID  
        ORDER BY `module`.`Module_name` ASC';       
         //print_r($sql);exit;
        $query=$this->db->query($sql);
        return $query->result();
    }

    function displayexamrecorrectionfee($TC_Id, $Exam_ID){
        $sql='SELECT training_center.TC_ID, training_center.Name, student_exam_course.Course_ID, 
        course.Course_name, student_exam_module.Module_ID, module.Module_name, 
        count(student_exam_module.Module_ID) as `module_count`, exam_fee_rate.Amount ,
        sum(exam_fee_rate.Amount) as `module_amount`, student_exam_course.Exam_ID 
        FROM student_exam_course INNER JOIN 
        student_exam_module ON student_exam_course.ST_EX_CO_ID = student_exam_module.ST_EX_CO_ID 
        INNER JOIN student_registration ON student_exam_course.STD_ID=student_registration.STD_ID 
        INNER JOIN module ON student_exam_module.Module_ID = module.Module_ID
        INNER JOIN course ON  student_exam_course.Course_ID = course.Course_ID
        INNER JOIN training_center ON student_registration.TC_ID=training_center.TC_ID
        INNER JOIN recurrection_request ON student_exam_module.ST_EX_MO_ID =recurrection_request.ST_EX_MO_ID
        LEFT JOIN exam_fee_rate ON student_exam_course.Course_ID=exam_fee_rate.Courese_ID AND 
        student_exam_module.Module_ID = exam_fee_rate.Module_ID WHERE student_exam_course.Exam_ID='.$Exam_ID.'
        AND student_registration.TC_ID='.$TC_Id.' AND recurrection_request.Receipt_file_name IS NULL GROUP BY 
        student_exam_module.Module_ID  
        ORDER BY `module`.`Module_name` ASC';       
       
        $query=$this->db->query($sql);
        return $query->result();
    }

    function addExamFee($Exam_ID,$TC_Id,$Total_Amount,$date,$new_name){

        $examFee=array(
            'Exam_ID'=>$Exam_ID,
            'TC_ID'=>$TC_Id,
            'Total_amount'=>$Total_Amount,
            'Payment_date'=>$date,
            'Receipt_file_name'=>$new_name);

        return $this->db->insert('exam_fee',$examFee);
        return $examFee->result();

    }
    function addExamRecorrectionFee($Exam_ID,$TC_Id,$Total_Amount,$date,$new_name){
        $Is_recorrection='1';
        $examFee=array(
            'Exam_ID'=>$Exam_ID,
            'TC_ID'=>$TC_Id,
            'Total_amount'=>$Total_Amount,
            'Payment_date'=>$date,
            'Is_recorrection'=>$Is_recorrection,
            'Receipt_file_name'=>$new_name);

        return $this->db->insert('exam_fee',$examFee);
        return $examFee->result();

    }
}
?>
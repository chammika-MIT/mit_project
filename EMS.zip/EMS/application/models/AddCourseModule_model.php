<?php
class AddCourseModule_model extends CI_Model{

    public function __construct() {
        $this->load->database();
      }

    function insert_course_data(){
        
        $coursedata=array(
            'Course_code'=>$this->input->post('CourseCode'),
            'Course_name'=>$this->input->post('CourseName'),
            'Version'=>$this->input->post('Version'));
            
        return $this->db->insert('course',$coursedata);
    }
   
      function displaycourse(){
          $query=$this->db->query('SELECT * FROM course');
          return $query->result();
      }
      public function delete_course($Course_ID){
        $this->db->query("DELETE FROM Course WHERE Course_ID='".$Course_ID."'");

    }
    public function displaycoursebyid($Course_ID){
        $query=$this->db->query("SELECT * FROM course WHERE Course_ID='".$Course_ID."'");
        return $query->result();
    }
    public function update_course($Course_ID, $Course_code, $Course_name, $Version){
        $query=$this->db->query("UPDATE course SET Course_code='$Course_code',Course_name='$Course_name', Version='$Version' WHERE Course_ID='".$Course_ID."'");

    }
    // **************************************************************
    // Manage Modules
    // **************************************************************
    function insert_module_data(){
        
        $moduledata=array(
            'Course_ID'=>$this->input->post('Course_code'),
            'Module_code'=>$this->input->post('Module_code'),
            'Semester_No'=>$this->input->post('MC_Semester'),
            'Module_name'=>$this->input->post('Module_name'));
            
           
            return $this->db->insert('module',$moduledata);
    }
    function displaymodule(){
        $query=$this->db->query("SELECT * FROM module");
        return $query->result();
    }
    function displaymodulebyCourseCode($Course_ID){
        $query=$this->db->query("SELECT * FROM module WHERE Course_ID='".$Course_ID."'");
        return $query->result();
    }
    public function delete_module($Module_ID){
        $this->db->query("DELETE FROM module WHERE Module_ID='".$Module_ID."'");

    }
    public function displaymodulebyid($Module_ID){
        $query=$this->db->query("SELECT * FROM module WHERE Module_ID='".$Module_ID."'");
        return $query->result();
    }
    public function update_module($Module_ID, $Course_ID, $Module_code, $MC_Semester, $Module_name){
        $query=$this->db->query("UPDATE module SET Course_ID='$Course_ID', Module_code='$Module_code', Semester_No='$MC_Semester',Module_name='$Module_name' WHERE Module_ID='".$Module_ID."'");
    }

    function get_course_code(){
        $query = $this->db->get('course');
        return $query ->result();
    }

}
?>
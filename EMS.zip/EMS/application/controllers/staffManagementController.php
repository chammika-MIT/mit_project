<?php
class staffManagementController extends CI_Controller{

    public function __construct() {
        parent:: __construct();
        $this->load->model('staffManagementModel');
        $this->load->model('UserModel');
    }

    public function staffmanagement(){
        $result['data']=$this->staffManagementModel->displaystaff();
        $result['staffType']=$this->staffManagementModel->getStaffType();
        $result['staffTC']=$this->staffManagementModel->getStafftraining();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        //print_r($result); exit;
        $this->load->view('staffManagemantView',$result);
	}

    public function addStaff(){
        $result['staffType']=$this->staffManagementModel->getStaffType();
        $result['staffTC']=$this->staffManagementModel->getStafftraining();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $this->load->view('addStaffView', $result);
	}
   
	public function reg_Staff_validation(){
        $this->form_validation->set_rules('Stf_NIC','Staff NIC','required|is_unique[staff.NIC]|min_length[10]|max_length[12]');
        $this->form_validation->set_rules('Name','Name','required');
        $this->form_validation->set_rules('Gender','Gender','required');
        $this->form_validation->set_rules('Contact_no_1','Contact No 1','required|is_unique[staff.Contact_No_1]|min_length[10]|max_length[10]');
        $this->form_validation->set_rules('Email','Email','required|is_unique[staff.Email]');
        $this->form_validation->set_rules('Staff_Type','Staff Type','required');
        $this->form_validation->set_rules('TC_ID','Training Center','required');
        $this->form_validation->set_rules('Stf_status','Staff status','required');

        $result['staffType']=$this->staffManagementModel->getStaffType();
        $result['staffTC']=$this->staffManagementModel->getStafftraining();

        if($this->form_validation->run()==FALSE){
       // print_r('Test'); exit;
           $this->load->view('addStaffView', $result); 
        }
        else{
            $response = $this->staffManagementModel->insert_staff_data();
            
            if ($response){

                $this->session->set_flashdata('msg','Registration Completed');
                redirect ('staffManagementController/addStaff');
            }
        }
    }
     
    function deleteStaff($STF_ID){

        $this->staffManagementModel->delete_staff($STF_ID);
        redirect ("staffManagementController/staffmanagement");
    }

    function updatestaff($STF_ID){
        $result['data']=$this->staffManagementModel->displaystaffbyid($STF_ID);
        $result['staffType']=$this->staffManagementModel->getStaffType();
        $result['staffTC']=$this->staffManagementModel->getStafftraining();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');

        $this->load->view('updateStaffView',$result);

            if($this->input->post('Update')){
                $Name=$this->input->post('Name');
                $NIC=$this->input->post('Stf_NIC');
                $Gender=$this->input->post('Gender');
                $Contact_No_1=$this->input->post('Contact_No_1');
                $Contact_No_2=$this->input->post('Contact_No_2');
                $Email=$this->input->post('Email');
                $STF_TY_ID=$this->input->post('STF_ID');
                $Active=$this->input->post('Std_status');
                                
                $this->staffManagementModel->update_staff($STF_ID, $Name, $NIC , $Gender, $Contact_No_1, $Contact_No_2, $Email, $STF_TY_ID, $Active);
                redirect ("staffManagementController/staffmanagement");
            }
    }
  
}
?>
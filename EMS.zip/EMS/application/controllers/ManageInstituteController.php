<?php
class ManageInstituteController extends CI_Controller{

    public function __construct() {
        parent:: __construct();
        $this->load->model('ManageInstituteModel');
        //$this->load->model('View_institute_model');
       // $this->load->model('Add_institute_model');
        $this->load->model('UserModel');
    }

    public function add_institute(){
        $result['data']=$this->ManageInstituteModel->get_district();
       $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
		$this->load->view('add_institutesView', $result);
	}

	public function reg_insitute(){
        $this->form_validation->set_rules('Reg_No','Registration No','required|is_unique[training_center.Reg_No]|min_length[8]|max_length[8]');
        $this->form_validation->set_rules('CenterName','Center Name','required');
        $this->form_validation->set_rules('PermanentAddress','Permanent Address','required');
        $this->form_validation->set_rules('District','District','required');
        $this->form_validation->set_rules('Mobile','Contact No','trim|required|min_length[10]|max_length[10]');
        $this->form_validation->set_rules('Email','Email','required|valid_email|is_unique[training_center.Email]');

        if($this->form_validation->run()==FALSE){
            $result['data']=$this->ManageInstituteModel->get_district();
            $this->load->view('add_institutesView', $result);
        }
        else{
            
            //$this->load->model('Add_institute_model');
            $response = $this->ManageInstituteModel->insert_training_center_data();
            if ($response){

                $this->session->set_flashdata('msg', 'Successfully Added');
                redirect ('ManageInstituteController/add_institute');
            }
        }
    }
    public function inst_reg(){		
        $result['district']=$this->ManageInstituteModel->get_district();
       $result['Delete_Center']=$this->UserModel->getUserRoleComponentAccess('Delete_Center');
        $result['Add_Institute']=$this->UserModel->getUserRoleComponentAccess('Add_Institute');
       $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        if(!empty($result['Add_Institute'])){
            $result['data']=$this->ManageInstituteModel->displaytraininginstitute();
        }
        else{
            $user_data = $this->session->get_userdata(); 
            $institute_id = $user_data['TC_ID'];
            $result['data']=$this->ManageInstituteModel->displaytraininginstituteById($institute_id);
        }

        $this->load->view('listInstituteView', $result);
		//$this->load->view('institute_reg');
	}
	function deletedata($TC_ID){
       // $this->load->model('View_institute_model');

        //$TC_ID=$this->input->get('TC_ID');
        $this->ManageInstituteModel->delete_training_center($TC_ID);
        redirect ("ManageInstituteController/inst_reg");
    }
    function updatedata($TC_ID){
        //$this->load->model('View_institute_model');
        //$TC_ID=$this->input->get('TC_ID');
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $result['district']=$this->ManageInstituteModel->get_district();
        $result['data']=$this->ManageInstituteModel->displaytrainingcenterbyid($TC_ID);
     //   $result['Add_Institute']=$this->UserModel->getUserRoleComponentAccess('Add_Institute');
        $this->load->view('Update_training_center_view',$result);
        

            if($this->input->post('Update')){
               
                //$TC_ID=$this->input->get('TC_ID');
                if(!empty( $result['Add_Institute'])){
                    $Reg_No=$this->input->post('Reg_No');
                    $CenterName=$this->input->post('CenterName');
                    $PermanentAddress=$this->input->post('PermanentAddress');
                    $District_ID=$this->input->post('District_ID');
                    $Email_address=$this->input->post('Email_address');
                    $ContactNo=$this->input->post('ContactNo');
                    
                    $response=$this->ManageInstituteModel->update_trainingcenter($TC_ID, $Reg_No, $CenterName, $PermanentAddress, $District_ID, $Email_address, $ContactNo);
                    //print_r($response); exit;
                    if ($response){

                        $this->session->set_flashdata('msg', 'Successfully Updated');
                        //print_r($result); exit;
                        redirect ($this->agent->referrer());
                    }
                }else{
                    //$Reg_No=$this->input->post('Reg_No');
                    //$CenterName=$this->input->post('CenterName');
                    $PermanentAddress=$this->input->post('PermanentAddress');
                    $District_ID=$this->input->post('District_ID');
                    $Email_address=$this->input->post('Email_address');
                    $ContactNo=$this->input->post('ContactNo');
                    
                    $response=$this->ManageInstituteModel->update_trainingcenterbycenter($TC_ID, $PermanentAddress, $District_ID, $Email_address, $ContactNo);
                    //print_r($response); exit;
                    if ($response){
    
                        $this->session->set_flashdata('msg', 'Successfully Updated');
                        //print_r($result); exit;
                        redirect ($this->agent->referrer());
                    }
                }
                
                
                
            }
    }
}
?>
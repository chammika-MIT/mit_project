<?php
class AddCourseModule_controller extends CI_Controller{

    public function __construct() {
        parent:: __construct();
        $this->load->model('AddCourseModule_model');
        $this->load->model('UserModel');
    }

    public function add_CourseModule(){
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $result['Add_Module']=$this->UserModel->getUserRoleComponentAccess('Add_Module');
        $result['data']=$this->AddCourseModule_model->displaycourse();
        $this->load->view('CourseModule_view', $result);
	}

    public function add_Course(){
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
		$this->load->view('addCourse_view', $result);
	}
	public function add_course_validation(){
        $this->form_validation->set_rules('CourseCode','CourseCode','required|is_unique[course.Course_code]');
        $this->form_validation->set_rules('CourseName','CourseName','required');
        $this->form_validation->set_rules('Version','Version','required');

        if($this->form_validation->run()==FALSE){
           $this->load->view('addCourse_view'); 
        }
        else{
            
            $this->load->model('AddCourseModule_model');
           // print_r($this->input->post());
           // exit();
            $response = $this->AddCourseModule_model->insert_course_data();

            if ($response){

                $this->session->set_flashdata('msg','Registration Completed');
                redirect ('AddCourseModule_controller/add_CourseModule');
            }
        }
    }
    function deletecourse($Course_ID){
        $this->load->model('AddCourseModule_model');

        $this->AddCourseModule_model->delete_course($Course_ID);
        redirect ("AddCourseModule_controller/add_CourseModule");
    }
    function updatecourse($Course_ID){
        $this->load->model('AddCourseModule_model');
        $result['data']=$this->AddCourseModule_model->displaycoursebyid($Course_ID);
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $this->load->view('updateCourseView',$result);

            if($this->input->post('Update')){
                $Course_code=$this->input->post('Course_code');
                $Course_name=$this->input->post('Course_name');
                $Version=$this->input->post('Version');
                
                $this->AddCourseModule_model->update_course($Course_ID, $Course_code, $Course_name, $Version);
                redirect ("AddCourseModule_controller/add_CourseModule");
            }
    }
    // ******************************************
    // Add module information
    // ******************************************

    public function moduleView(){
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $result['Add_Module']=$this->UserModel->getUserRoleComponentAccess('Add_Module');
        $result['data']=$this->AddCourseModule_model->displaymodule();
        $this->load->view('Module_view',$result);
	}
    public function modulViewByCourse($Course_code){
        $result['data']=$this->AddCourseModule_model->displaymodulebyCourseCode($Course_code);
        $this->load->view('Module_view',$result);
	}
    public function add_module(){
        $result['code'] = $this->AddCourseModule_model->get_course_code();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $this->load->view('addModule_view', $result);
		//$this->load->view('addModule_view');
	}
    public function add_module_validation(){
      //  $this->input->post('Course_code');
        $this->form_validation->set_rules('Course_code','Course Name','required');
        $this->form_validation->set_rules('Module_code','Module code','required|is_unique[module.Module_code]|min_length[10]|max_length[10]');
        $this->form_validation->set_rules('MC_Semester','Semester No','required');
        $this->form_validation->set_rules('Module_name','Module name','required');
        
        
       
        if($this->form_validation->run()==FALSE){
            $result['code'] = $this->AddCourseModule_model->get_course_code();

            $this->load->view('addModule_view', $result); 
        }
        else{
            
            $response = $this->AddCourseModule_model->insert_module_data();

            if ($response){

                $this->session->set_flashdata('msg','Module Added');
                redirect ('AddCourseModule_controller/add_module');
            }
        }
    }
    function deletemodule($Module_ID){
        $this->load->model('AddCourseModule_model');

        $this->AddCourseModule_model->delete_module($Module_ID);
        redirect ("AddCourseModule_controller/moduleView");
    }
    function updatemodule($Module_ID){

        $result['data']=$this->AddCourseModule_model->displaymodulebyid($Module_ID);
        $result['code'] = $this->AddCourseModule_model->get_course_code();
        $this->load->view('updateModuleView',$result);

            if($this->input->post('Update')){

                    $Course_ID=$this->input->post('Course_code');
                    $Module_code=$this->input->post('Module_code');
                    $MC_Semester=$this->input->post('Semester_no');
                    $Module_name=$this->input->post('Module_name');
                    
                    $this->AddCourseModule_model->update_module($Module_ID, $Course_ID, $Module_code,$MC_Semester, $Module_name);
                    redirect ("AddCourseModule_controller/moduleView");
                
            }
    }
}
?>
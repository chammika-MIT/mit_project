<?php
class Exam_Manage_Controller extends CI_Controller{

    public function __construct() {
        parent:: __construct();
        $this->load->model('Exam_manage_Model'); 
        $this->load->model('Payment_Model'); 
        $this->load->model('UserModel');

    }

    public function download_admission($Exam_ID)
    {
        $this->form_validation->set_rules('Training_center','Training center','required');
        $this->form_validation->set_rules('course','course','required');

        $result['data']=$this->Exam_manage_Model->displaytrainingcenter();
        $result['course']=$this->Exam_manage_Model->displaytrainingcourse();
        $result['Exam_ID']=$Exam_ID;
        $result['exam']=$this->Exam_manage_Model->getCreateExam($Exam_ID);
        $result['exam']=json_decode(json_encode($result['exam']), true);

        if($this->form_validation->run()==FALSE){
            $this->load->view('selectexamView', $result); 
        }
        else{
            $training=$this->input->post();
            $trainingcenter=$training['Training_center'];
            $trainingcourse=$training['course'];

            $result['Exam_ID']=$Exam_ID;
            $result['course_ID']=$trainingcourse;
            $result['training_center']=$trainingcenter;

            //print_r($trainingcenter); exit;

            $result['data']=$this->Exam_manage_Model->get_exam_admmission_list($trainingcenter,$trainingcourse,$Exam_ID);
            //print_r($result); exit;
            $this->load->helper('pdf_helper');            
            $this->load->view('examAdmissionPDF', $result);
        }
    }  

    public function select_center($Exam_ID){

        $result['Add_Student']=$this->UserModel->getUserRoleComponentAccess('Add_Student');
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $result['Add_Module']=$this->UserModel->getUserRoleComponentAccess('Add_Module');
        $result['Exam_ID']=$Exam_ID;
        
        $result['course']=$this->Exam_manage_Model->displaytrainingcourse();
        $result['exam']=$this->Exam_manage_Model->getCreateExam($Exam_ID);
        $result['exam']=json_decode(json_encode($result['exam']), true);
        
        if(!empty($result['Add_Student'])){
            $result['data']=$this->Exam_manage_Model->displaytrainingcenter();

        }
        else{
            $user_data = $this->session->get_userdata(); 
            $institute_id = $user_data['TC_ID'];

            $result['data']=$this->Exam_manage_Model->displaytrainingcenterBYTCID($institute_id);
           // 
           $result['training']=json_decode(json_encode($result['training']), true);
           //print_r($result['data']); exit;
        }

        $this->load->view('selectexamView', $result);

	}
    
    public function assign_exam_validation($Exam_ID){            

        $this->form_validation->set_rules('Training_center','Training center','required');
        $this->form_validation->set_rules('semester_no','semester no','required');
        $this->form_validation->set_rules('course','course','required');
        
      //  $result['data']=$this->Exam_manage_Model->displaytrainingcenter();
        $result['Add_Student']=$this->UserModel->getUserRoleComponentAccess('Add_Student');
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $result['course']=$this->Exam_manage_Model->displaytrainingcourse();
        $result['Exam_ID']=$Exam_ID;
        $result['exam']=$this->Exam_manage_Model->getCreateExam($Exam_ID);
        $result['exam']=json_decode(json_encode($result['exam']), true);
        if($this->form_validation->run()==FALSE){

            if(!empty($result['Add_Student'])){
                $result['data']=$this->Exam_manage_Model->displaytrainingcenter();
            }
            else{
                $user_data = $this->session->get_userdata(); 
                $institute_id = $user_data['TC_ID'];
                $result['data']=$this->Exam_manage_Model->displaytrainingcenterBYTCID($institute_id);
            }

            
           $this->load->view('selectexamView', $result); 
        }
        else{
            $training=$this->input->post();
            $trainingcenter=$training['Training_center'];
            $trainingcourse=$training['course'];
            $semesterNo=$training['semester_no'];

            $result['Exam_ID']=$Exam_ID;
            $result['course_ID']=$trainingcourse;
            $result['training_center']=$trainingcenter;
            $result['semester_no']= $semesterNo;
            

            $result['data']=$this->Exam_manage_Model->displayexamtrainingmodule($trainingcenter,$trainingcourse,$semesterNo,$Exam_ID);
           // print_r($result['data']);exit; 
            $this->load->view('assignexamView',$result);   
        }
    }

    public function assign_std_exam($Exam_course_ID){
       
        

            $ExamID=($this->uri->segment(3));
            $courseID=($this->uri->segment(4)); 
            $centerID=($this->uri->segment(5));  
            $semesterNo=($this->uri->segment(6));  
            

        //if ($this->input->post()!=FALSE){
            $result=$this->input->post();
            
            $response=$this->Exam_manage_Model->insert_course_student_data($result,$ExamID,$courseID,$centerID);
            
            $result['Exam_ID']=$ExamID;
            $result['course_ID']=$courseID;
            $result['training_center']=$centerID;
            $result['semester_no']= $semesterNo;
            

            $result['data']=$this->Exam_manage_Model->displayexamtrainingmodule($centerID,$courseID,$semesterNo,$ExamID);
           // print_r($result['data']);exit; 
            //$this->load->view('assignexamView',$result);
            //print_r($result['data']);exit; 
            //redirect ("Exam_Manage_Controller/select_center/{$ExamID}");
            //if ($response){                       
                $this->session->set_flashdata('msgsuc','Registration Completed');
                $this->load->view('assignexamView',$result);   
                //redirect ("Exam_Manage_Controller/assign_std_exam/{$ExamID}");
            //}
        //}
        //else{
        //    print_r("No Data");
        //}
    }

    public function assign_exam_center($Exam_ID){

        $this->form_validation->set_rules('Training_center','Training center','required');
        //$this->form_validation->set_rules('semester_no','Semester No','required');
        $this->form_validation->set_rules('course','course','required');
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $result['data']=$this->Exam_manage_Model->displaytrainingcenter();
        $result['course']=$this->Exam_manage_Model->displaytrainingcourse();
        $result['Exam_ID']=$Exam_ID;
        $result['exam']=$this->Exam_manage_Model->getCreateExam($Exam_ID);
        $result['exam']=json_decode(json_encode($result['exam']), true);

        if($this->form_validation->run()==FALSE){
            $result['data']=$this->Exam_manage_Model->displaytrainingcenter();
            $result['course']=$this->Exam_manage_Model->displaytrainingcourse();
            $result['Exam_ID']=$Exam_ID;
            
           $this->load->view('selectexamView', $result); 
        }
        else{
            $training=$this->input->post();
            $trainingcenter=$training['Training_center'];
            $trainingcourse=$training['course'];

            $result['Exam_ID']=$Exam_ID;
            $result['course_ID']=$trainingcourse;
            $result['training_center']=$trainingcenter;

            $result['data']=$this->Exam_manage_Model->displayExamCenterStudent($trainingcenter,$trainingcourse,$Exam_ID);
            
            $this->load->view('assignExamCenterView',$result);   
        }
    }

    public function student_exam_center($Exam_course_ID){
       // print_r($result); exit;
        $ExamID=($this->uri->segment(3));
        $courseID=($this->uri->segment(4)); 
        $centerID=($this->uri->segment(5));  

    if ($this->input->post()!=FALSE){
        $result=$this->input->post();
       
        $response=$this->Exam_manage_Model->update_student_exam_center($result,$ExamID,$courseID,$centerID);
        //redirect ("Exam_Manage_Controller/select_center/{$ExamID}");
        if ($response){                       
            $this->session->set_flashdata('msg','Registration Completed');
            redirect ("Exam_Manage_Controller/select_center/{$ExamID}");
        }
    }
    else{
        print_r("No Data");
    }
}



    public function add_student_attendance($Exam_ID){
            
        $this->form_validation->set_rules('Training_center','Training center','required');
        $this->form_validation->set_rules('course','course','required');
        
        $result['data']=$this->Exam_manage_Model->displaytrainingcenter();
        $result['course']=$this->Exam_manage_Model->displaytrainingcourse();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $result['Exam_ID']=$Exam_ID;
        $result['exam']=$this->Exam_manage_Model->getCreateExam($Exam_ID);
        $result['exam']=json_decode(json_encode($result['exam']), true);

        if($this->form_validation->run()==FALSE){
           $this->load->view('selectexamView', $result); 
        }
        else{
            $training=$this->input->post();
            $trainingcenter=$training['Training_center'];
            $trainingcourse=$training['course'];
            $semesterNo=$training['semester_no'];

            $result['Exam_ID']=$Exam_ID;
            $result['course_ID']=$trainingcourse;
            $result['training_center']=$trainingcenter;
            $result['semester_no']= $semesterNo;

            $result['data']=$this->Exam_manage_Model->displayExamAttendanceModule($trainingcenter,$trainingcourse,$Exam_ID,$semesterNo);
            
            $this->load->view('addAttendanceView',$result);   
        }
    }

    public function update_student_attendance(){
        
        $ExamID=($this->uri->segment(3));
        $courseID=($this->uri->segment(4)); 
        $centerID=($this->uri->segment(5));  

        if ($this->input->post()!=FALSE){
            $result=$this->input->post();

            $response=$this->Exam_manage_Model->update_student_attendance($result,$ExamID,$courseID,$centerID);
            //redirect ("Exam_Manage_Controller/select_center/{$ExamID}");
            if ($response){                       
                $this->session->set_flashdata('msg','Student Attendance added Succesfully');
                redirect ("Exam_Manage_Controller/select_center/{$ExamID}");
            }
        }
        else{
            print_r("No Data");
        } 
    }

    public function update_student_exam_index_no($ExamID){
        //$ExamID=($this->uri->segment(3));
        $response=$this->Exam_manage_Model->update_student_exam_index_no($ExamID);
        //redirect ("Exam_Manage_Controller/select_center/{$ExamID}");
        if ($response){                       
            $this->session->set_flashdata('msg','Student Index Nos Created Succesfully');
            redirect ("CreateExamController/createExam");
        }
        else{
            $this->session->set_flashdata('msg','No New Student to create Index Nos');
            redirect ("CreateExamController/createExam");
            //print_r("No Data");
        } 
    }


    public function view_exam_schedule($Exam_ID){    
        //print_r($EX_SCH_ID); exit();
        $this->form_validation->set_rules('Course','Course','required');
        $this->form_validation->set_rules('Module','Module','required');
        $this->form_validation->set_rules('Start_Time','Start Time','required');        
        $this->form_validation->set_rules('End_Time','End Time','required');
        
       
        $result['course']=$this->Exam_manage_Model->displaytrainingcourse();
        $result['module']=$this->Exam_manage_Model->displaytrainingmodule();
        $result['schedule']=$this->Exam_manage_Model->get_exam_schedule($Exam_ID);
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $result['Exam_ID']=$Exam_ID;

        if($this->form_validation->run()==FALSE){
            $result['course_id']=$this->input->post('Course');
            $result['module_id']=$this->input->post('Module');
            $result['Start_Time']=$this->input->post('Start_Time');
            $result['End_Time']=$this->input->post('End_Time');
            //print_r($result); exit();
           $this->load->view('examScheduleView', $result); 
        }
        else{
            $this->form_validation->set_rules('Start_Time', 'Start Time', 'callback_start_date_check');
            $this->form_validation->set_rules('End_Time', 'End Time', 'callback_end_date_check');
            if($this->form_validation->run()!=FALSE){
                $result['data']=$this->Exam_manage_Model->insert_exam_schedule($Exam_ID);
                $result['schedule']=$this->Exam_manage_Model->get_exam_schedule($Exam_ID);
                $result['course_id']='';
                $result['module_id']='';
                $result['Start_Time']='';
                $result['End_Time']='';
                $this->load->view('examScheduleView',$result);   
            }  
            else{
                $result['course_id']=$this->input->post('Course');
                $result['module_id']=$this->input->post('Module');
                $result['Start_Time']=$this->input->post('Start_Time');
                $result['End_Time']=$this->input->post('End_Time');
                $this->load->view('examScheduleView',$result);   
            }                
        }       
    }


    public function start_date_check()
    {
        $date = new DateTime($this->input->post('Start_Time'));
        $now = new DateTime();        
        if($date!=null && $date!='' && $date < $now) {             
            $this->form_validation->set_message('start_date_check', 'date is in the past');
            return FALSE;
        }
        else{
            return TRUE;
        }
        
    }

    public function end_date_check()
    {
        $date = new DateTime($this->input->post('End_Time'));
        $now = new DateTime();
        $end_date= $date->format('m/d/Y');
        $start_date=new DateTime($this->input->post('Start_Time'));
        $start_date= $start_date->format('m/d/Y');        
        //print_r($date); exit;
        if($date!=null && $date!='' && $date < $now) {     
            $this->form_validation->set_message('end_date_check', 'date is in the past');
            return FALSE;
        }
        if($start_date!=$end_date){
            $this->form_validation->set_message('end_date_check', 'Start and end dates should same');
            return FALSE;
        }
        else{
            return TRUE;
        }
        
    }

    function update_exam_schedule($EX_SCH_ID){
       
        $this->form_validation->set_rules('Course','Course','required');
        $this->form_validation->set_rules('Module','Module','required');
        $this->form_validation->set_rules('Start_Time','Start Time','required');
        $this->form_validation->set_rules('End_Time','End Time','required');
       
       
        $result['course']=$this->Exam_manage_Model->displaytrainingcourse();
        $result['module']=$this->Exam_manage_Model->displaytrainingmodule();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $result['schedule']=$this->Exam_manage_Model->get_exam_schedule_by_id($EX_SCH_ID);
        //$result['Exam_ID']=$Exam_ID;
        $data = json_decode(json_encode($result['schedule']), true);
        
        foreach ($result['schedule'] as $key => $object) {
            //print_r(substr_replace($data[0]['Start_Time'] ,"", -3)); exit();
            //echo $object->object_property;
            $result['course_id']=$data[0]['Course_ID'];
            $result['module_id']=$data[0]['Module_ID'];
            
            $result['Start_Time']=str_replace(" ","T",substr_replace($data[0]['Start_Time'] ,"", -3));
            $result['End_Time']=str_replace(" ","T",substr_replace($data[0]['End_Time'] ,"", -3));
            $result['Exam_ID']=$data[0]['Exam_ID'];
            //print_r($result['schedule']); exit();
        }

        if($this->form_validation->run()==FALSE){           
            
           $this->load->view('updateExamScheduleView', $result); 
        }
        else{
            $this->form_validation->set_rules('Start_Time', 'Start Time', 'callback_start_date_check');
            $this->form_validation->set_rules('End_Time', 'End Time', 'callback_end_date_check');
            if($this->form_validation->run()!=FALSE){               
                //print_r($result['Exam_ID']); exit();
                $Exam_ID=$result['Exam_ID'];
                $this->Exam_manage_Model->update_exam_schedule($EX_SCH_ID);
                //$result['schedule']=$this->Exam_manage_Model->get_exam_schedule_by_id($EX_SCH_ID);
                redirect ("Exam_Manage_Controller/view_exam_schedule/$Exam_ID");
            }  
            else{ 
                $result['course_id']=$this->input->post('Course');
                $result['module_id']=$this->input->post('Module');
                $result['Start_Time']=$this->input->post('Start_Time');
                $result['End_Time']=$this->input->post('End_Time');
                $this->load->view('updateExamScheduleView',$result);   
            } 
            
        }   
    }

    function delete_exam_schedule($EX_SCH_ID,$Exam_ID){
         $this->Exam_manage_Model->delete_exam_schedule($EX_SCH_ID);
         redirect ("Exam_Manage_Controller/view_exam_schedule/$Exam_ID");
    }   

    public function download_exam_schedule_pdf($Exam_ID)
    {        
        $result['Exam_ID']=$Exam_ID;
        $result['data']=$this->Exam_manage_Model->get_exam_schedule_by_course_order($Exam_ID);
        $this->load->helper('pdf_helper');            
        $this->load->view('examSchedulePDF', $result);
    }  
/*
    function view_exam_student_count_per_module(){
        $result['data']=$this->Exam_manage_Model->get_exam_student_count_per_module();
        $this->load->helper('pdf_helper');            
        $this->load->view('examStudentCountModulePDF', $result);
    }

    function view_reg_student_by_course_district(){
        $result['data']=$this->Exam_manage_Model->get_reg_student_by_course_district();
        $this->load->helper('pdf_helper');            
        $this->load->view('examStudentCourseDistrictWisePDF', $result);
    }
*/
    function view_exam_student_by_indexno_course($courseID,$excID){
        //print_r($this->input->post());exit;
        $result['data']=$this->Exam_manage_Model->get_exam_student_by_indexno_course($courseID,$excID);
        $this->load->helper('pdf_helper');            
        $this->load->view('examStudentCourseIndexNoPDF', $result);
    }

    // Recorrection Handdling

    public function recorrectionRequest($Exam_ID){

        $this->form_validation->set_rules('Training_center','Training center','required');
        $this->form_validation->set_rules('semester_no','semester no','required');
        $this->form_validation->set_rules('course','course','required');
        
      //  $result['data']=$this->Exam_manage_Model->displaytrainingcenter();
        $result['Add_Student']=$this->UserModel->getUserRoleComponentAccess('Add_Student');
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $result['course']=$this->Exam_manage_Model->displaytrainingcourse();
        $result['Exam_ID']=$Exam_ID;
        $result['exam']=$this->Exam_manage_Model->getCreateExam($Exam_ID);
        $result['exam']=json_decode(json_encode($result['exam']), true);
        if($this->form_validation->run()==FALSE){

            if(!empty($result['Add_Student'])){
                $result['data']=$this->Exam_manage_Model->displaytrainingcenter();
            }
            else{
                $user_data = $this->session->get_userdata(); 
                $institute_id = $user_data['TC_ID'];
                $result['data']=$this->Exam_manage_Model->displaytrainingcenterBYTCID($institute_id);
                
            }
            
            $this->load->view('selectexamView', $result); 
            
           
        }
        else{
            $training=$this->input->post();
            $trainingcenter=$training['Training_center'];
            $trainingcourse=$training['course'];
            $semesterNo=$training['semester_no'];

            $result['Exam_ID']=$Exam_ID;
            $result['course_ID']=$trainingcourse;
            $result['training_center']=$trainingcenter;
            $result['semester_no']= $semesterNo;
            

            $result['data']=$this->Exam_manage_Model->displayexamtrainingmoduleRecorrection($trainingcenter,$trainingcourse,$semesterNo);
            
            $this->load->view('recorrectionRequestView',$result);   
        }
    }
    public function assign_std_recorrection($Exam_course_ID){
       
        $ExamID=($this->uri->segment(3));
        $courseID=($this->uri->segment(4)); 
        $centerID=($this->uri->segment(5));  

    //if ($this->input->post()!=FALSE){
        $result=$this->input->post();

        $response=$this->Exam_manage_Model->insert_recorrection_student_data($result,$ExamID,$courseID,$centerID);
        //redirect ("Exam_Manage_Controller/select_center/{$ExamID}");
        //if ($response){                       
            $this->session->set_flashdata('msg','Registration Completed');
            redirect ("Exam_Manage_Controller/select_center/{$ExamID}");
        //}
    //}
    //else{
       // print_r("No Data to save");
    //}
}
}
?>
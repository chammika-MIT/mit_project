<?php
class ExamFeeController extends CI_Controller{

    public function __construct() {
        parent:: __construct();
       $this->load->model('ExamFeeModel');
        //$this->load->model('View_institute_model');
       // $this->load->model('Add_institute_model');
        $this->load->model('UserModel');
       
    }
    /*
    public function index()
    {
            $this->load->view('upload_form', array('error' => ' ' ));
    }*/
    public function viewExamFee(){
        $Exam_ID=($this->uri->segment(3));        
        $TC_Id=($this->uri->segment(4)); 
        $Course_Id=($this->uri->segment(5));  
        //print_r( $post); exit;
        $result['data']=$this->ExamFeeModel->displayexamfee($TC_Id, $Exam_ID,$Course_Id);
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $result['data']=json_decode(json_encode($result['data']), true);
        $result['Exam_ID']=$Exam_ID;
        //print_r($result['data']); exit;
		$this->load->view('examFeesView',$result);
	}

    public function do_upload(){
            $TC_Id=($this->uri->segment(4)); 
            $RegID=$TC_Id.'_';
            $this->load->helper(array('form', 'url'));
            $this->load->library('upload');
            $new_name = $RegID.time().$_FILES['userfile']['name'];

            
                $config['upload_path']          = './paySlip/';
                $config['allowed_types']        = 'pdf|jpg';
                $config['max_size']             = 0;
                $config['max_width']            = 0;
                $config['max_height']           = 0;
                $config['file_name'] = $new_name;
                

                $this->upload->initialize($config);
                if ( ! $this->upload->do_upload('userfile'))
                {
                        $error = array('error' => $this->upload->display_errors());
                        $this->session->set_flashdata('error', 'Upload is not successfully ..!');
                       redirect ($this->agent->referrer());
                }
                else
                {
                   
                        $data= array('upload_data' => $this->upload->data());

                        $Exam_ID=($this->uri->segment(3));        
                        $TC_Id=($this->uri->segment(4));  
                        $Total_Amount=($this->uri->segment(5)); 
                        $date=date('Y-m-d');
                      //  print_r($Exam_ID);print_r($TC_Id);print_r($Total_Amount); print_r($date);print_r($new_name); exit;
                        $this->ExamFeeModel->addExamFee($Exam_ID,$TC_Id,$Total_Amount,$date,$new_name);
                      
                       $this->session->set_flashdata('msg', '✔ Successfully Uploaded');
                       redirect ($this->agent->referrer());
                }
        }

        //Exam Fee Recorrection
        public function viewExamRecorrectionFee(){
            $Exam_ID=($this->uri->segment(3));        
            $TC_Id=($this->uri->segment(4));
            $Course_Id=($this->uri->segment(5));
            //print_r( $post); exit;
            $result['data']=$this->ExamFeeModel->displayexamrecorrectionfee($TC_Id, $Exam_ID);
            $result['data']=json_decode(json_encode($result['data']), true);
            
           // print_r($result); exit;
            $this->load->view('examRecorrectionFeeView',$result);
        }
        public function do_upload_recorrection(){
            $TC_Id=($this->uri->segment(4)); 
            $RegID=$TC_Id.'_RE_';
            $this->load->helper(array('form', 'url'));
            $this->load->library('upload');
            $new_name = $RegID.time().$_FILES['userfile']['name'];

            
                $config['upload_path']          = './paySlip/';
                $config['allowed_types']        = 'pdf|jpg';
                $config['max_size']             = 0;
                $config['max_width']            = 0;
                $config['max_height']           = 0;
                $config['file_name'] = $new_name;
                

                $this->upload->initialize($config);
                if ( ! $this->upload->do_upload('userfile'))
                {
                        $error = array('error' => $this->upload->display_errors());
                        $this->session->set_flashdata('error', 'Upload is not successfully ..!');
                       redirect ($this->agent->referrer());
                }
                else
                {
                   
                        $data= array('upload_data' => $this->upload->data());

                        $Exam_ID=($this->uri->segment(3));        
                        $TC_Id=($this->uri->segment(4));  
                        $Total_Amount=($this->uri->segment(5)); 
                        $date=date('Y-m-d');
                      //  print_r($Exam_ID);print_r($TC_Id);print_r($Total_Amount); print_r($date);print_r($new_name); exit;
                        $this->ExamFeeModel->addExamRecorrectionFee($Exam_ID,$TC_Id,$Total_Amount,$date,$new_name);
                      
                       $this->session->set_flashdata('msg', '✔ Successfully Uploaded');
                       redirect ($this->agent->referrer());
                }
        }
    
}
?>
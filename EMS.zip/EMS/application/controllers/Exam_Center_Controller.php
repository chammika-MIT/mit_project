<?php
class Exam_Center_Controller extends CI_Controller{

    public function __construct() {
        parent:: __construct();
        $this->load->model('ExamCenterModel');
        $this->load->model('UserModel');
    }

    public function examcenterview(){
        $result['data']=$this->ExamCenterModel->displayexamcenter();
        $result['district']=$this->ExamCenterModel->displayexamcenterdistrict();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $this->load->view('examCenterView', $result);
	}

    public function add_Exam_Center(){
        $result['district']=$this->ExamCenterModel->displayexamcenterdistrict();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
		$this->load->view('addExamcenterView', $result);
	}
	public function add_ExamCneter_validation(){
        $this->form_validation->set_rules('CenterName','CenterName','required');
        $this->form_validation->set_rules('Address','Address','required');
        $this->form_validation->set_rules('District_ID','District_ID','required');
        $this->form_validation->set_rules('Capacity','Capacity','required');

        if($this->form_validation->run()==FALSE){
           $this->load->view('addExamcenterView'); 
        }
        else{
            
            $this->load->model('ExamCenterModel');
            $response = $this->ExamCenterModel->insert_examcenter_data();
            if ($response){

                $this->session->set_flashdata('msg','Registration Completed');
                redirect ('Exam_Center_Controller/examcenterview');
            }
        }
    }
    function deleteexamcenter($EXC_ID){
       // $this->load->model('ExamCenterModel');

        $this->ExamCenterModel->delete_exam_center($EXC_ID);
        redirect ("Exam_Center_Controller/examcenterview");
    }
    function updateexamcenter($EXC_ID){
       // $this->load->model('AddCourseModule_model');
        $result['data']=$this->ExamCenterModel->displayexamcenterbyid($EXC_ID);
        $result['district']=$this->ExamCenterModel->displayexamcenterdistrict();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $this->load->view('updateExamCenterView',$result);

            if($this->input->post('Update')){
                $CenterName=$this->input->post('CenterName');
                $Address=$this->input->post('Address');
                $District_ID=$this->input->post('District_ID');
                $Capacity=$this->input->post('Capacity');
                
                $this->ExamCenterModel->update_exam_center($EXC_ID, $CenterName, $Address, $District_ID, $Capacity);
                redirect ("Exam_Center_Controller/examcenterview");
            }
    }
}
?>
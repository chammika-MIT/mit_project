<?php
class Payment_Management_Controller extends CI_Controller{

    public function __construct() {
        parent:: __construct();
        $this->load->model('Add_institute_model');
    }

    public function paymentManagement(){
        
		$this->load->view('paymentManagementView');
	}
}
?>
<?php
class studentSearchController extends CI_Controller{

    public function __construct() {
        parent:: __construct();
        $this->load->model('studentInfoModel');
    }

    public function studentInfo(){
        //$result['data']=$this->RegisterStudentModel->displaystudents();
        $this->load->view('studentInfoView');
	}
    public function student_NIC_validation(){
        $this->form_validation->set_rules('Std_NIC','Std_NIC','required|min_length[10]|max_length[12]');

        if($this->form_validation->run()==FALSE){
           $this->load->view('home'); 
           
        }
        else{
            $Std_NIC=$this->input->post('Std_NIC');

            $result['stdNIC'] = $this->input->post('Std_NIC');
            $result['stdInfo'] = $this->studentInfoModel->displaystudentbyNIC($Std_NIC);
            $result['TC_Center'] = $this->studentInfoModel->get_TC_ID();
            $result['Course_ID'] = $this->studentInfoModel->get_Course_ID();
            $result['Student_Course_ID'] = $this->studentInfoModel->get_Student_Course_ID();
            $result['module_result'] = $this->studentInfoModel->displaystudentwithresult($Std_NIC);
            $result['time_table'] = $this->studentInfoModel->displaystudenttimetable($Std_NIC);
            $this->load->view('studentInfoView',$result);

        }
    }
}
?>
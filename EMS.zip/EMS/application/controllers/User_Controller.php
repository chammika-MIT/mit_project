<?php
class User_Controller extends CI_Controller{

    public function __construct() {
        parent:: __construct();
        $this->load->model('UserModel');
    }

    public function users(){        
        $result['data']=$this->UserModel->getUser();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $this->load->view('userView', $result);
        //print_r($result);
        //exit();
	}   

    public function add_user(){


/*
        $this->load->config('email');
                $this->load->library('email');
               // $this->email->initialize($config);
                $this->email->set_newline("\r\n");
                $this->email->from('chammikamit@gmail.com');
                $recepient_email='chammika2010@gmail.com';//$staff[0]['Email'];
                $subject='User Id and Password';

                $username='sdsdsd';//$userdata['Username'];
                $password='sdsdsaqaaaa';//$userdata['Password'];
                

                $message='Account Created succesfully. <br></br><b> User Name : </b>'.$username.' <br></br><b> Password :  </b>'.$password;
                // $this->email->to($this->input->post('user_email'));
                // $this->email->to($recepient_email);
                $this->email->to($recepient_email);
                $this->email->subject($subject);
                $this->email->message($message);
                $this->email->send();
                print_r('dd');exit;


        $config['protocol']    = 'smtp';
        $config['smtp_host']    = 'ssl://smtp.googlemail.com';
        $config['smtp_port']    = '465';
        $config['smtp_timeout'] = '7';
        $config['smtp_user']    = 'chammikamit@gmail.com';
        $config['smtp_pass']    = 'MIT2018@ucsc';
        $config['charset']    = 'utf-8';
        $config['newline']    = "\r\n";
           $config['mailtype'] = 'text'; // or html
           $config['validation'] = TRUE; // bool whether to validate email or not 
           */
          
       
           //$this->load->library('email', $config);
          
           
           // if($this->email->send())

        
        $this->form_validation->set_rules('TC_ID','TC_ID','required');
        $this->form_validation->set_rules('STF_ID','Name','required');
        $this->form_validation->set_rules('Username','User Name','required');
        $this->form_validation->set_rules('Password','Password','required');     
        $this->form_validation->set_rules('Confirm_Password', 'Confirm Password', 'required|matches[Password]');     
        $this->form_validation->set_rules('Availability', 'Availability', 'required');    

        $result['TC_ID'] = $this->UserModel->getTrainingCenters();
        $result['STF_ID'] = $this->UserModel->getStaff(); 
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');      
        if($this->form_validation->run()==FALSE){
           $this->load->view('addUserView', $result);            
        }
        else{            
            //$this->load->model('UserModel');
            $userdata = $this->input->post();        
            unset($userdata["Confirm_Password"]);  
            $staff = $this->UserModel->getStaffById($userdata['STF_ID']);  
            $staff=json_decode(json_encode($staff), true); 
           
            
            $response = $this->UserModel->insert_user($userdata);          
            if ($response){
                
                $this->load->config('email');
                $this->load->library('email');
               // $this->email->initialize($config);
                $this->email->set_newline("\r\n");
                $this->email->from('chammikamit@gmail.com');
                $recepient_email=$staff[0]['Email'];
                $subject='User Id and Password';

                $username=$userdata['Username'];
                $password=$userdata['Password'];
                

                $message='Account Created succesfully. <br></br><b> User Name : </b>'.$username.' <br></br><b> Password :  </b>'.$password;
                // $this->email->to($this->input->post('user_email'));
                // $this->email->to($recepient_email);
                $this->email->to($recepient_email);
                $this->email->subject($subject);
                $this->email->message($message);
                $this->email->send();
              //  print_r('dd');exit;;
               // echo $this->email->print_debugger();

                $this->session->set_flashdata('msg','User ID and Password sent to Email');
                redirect ('User_Controller/users/');
            }

        }
    }
   

    function  update_user($User_Id){        
        $this->form_validation->set_rules('TC_ID','TC_ID','required');
        $this->form_validation->set_rules('STF_ID','Name','required');
        $this->form_validation->set_rules('Username','User Name','required');
        $this->form_validation->set_rules('Password','Password','required');     
        $this->form_validation->set_rules('Confirm_Password', 'Confirm Password', 'required|matches[Password]');     
        $this->form_validation->set_rules('Availability', 'Availability', 'required');    

       
        $result['data']=$this->UserModel->getUserById($User_Id);    
        $result['TC_ID'] = $this->UserModel->getTrainingCenters();
        $result['STF_ID'] = $this->UserModel->getStaff();   
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');      
      
        //print_r($this->input->post());
        //exit();
        if($this->form_validation->run()==FALSE){
            $this->load->view('updateUserView', $result);            
        }
        else{            
             $this->load->model('UserModel');
             $userdata = $this->input->post();        
             unset($userdata["Confirm_Password"]);   
             unset($userdata["Update"]);   
             $response = $this->UserModel->update_user($User_Id,$userdata);          
             if ($response){
                 $this->session->set_flashdata('msg','User updated successfully');
                 redirect ('User_Controller/users/');
            }
 
        }
    } 
        
    public function user_role($User_Id){        
        $result['User_Id']=$User_Id;        
        $result['data']=$this->UserModel->getUserRoleById($User_Id); 
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');                
        $this->load->view('userRoleView', $result);
	}

    public function add_user_role($User_Id){
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');  
        
        $this->form_validation->set_rules('Role_ID','Role','required');
       
        $result['Role'] = $this->UserModel->getRole();      
        $result['User_Id']=$User_Id;        
        if($this->form_validation->run()==FALSE){
           $this->load->view('addUserRoleView', $result);            
        }
        else{      
               // print_r($User_Id); exit;
            $this->load->model('UserModel');
            $userRoleExists =  $this->UserModel->getUserByRoleId($User_Id, $this->input->post('Role_ID'));    
           
            if(empty($userRoleExists)){
                $response = $this->UserModel->insert_user_role();                
                if ($response){
                    $this->session->set_flashdata('msg','User role added successfully');
                    redirect ('User_Controller/user_role/'.$User_Id);
                }
            }
            else{                 
                $this->session->set_flashdata('msg','User role already exists');
                redirect ('User_Controller/user_role/'.$User_Id);
            }            
        }
    }

    function  delete_user_role($User_ID,$Role_ID){
        $this->load->model('UserModel');
        $this->UserModel->delete_user_role($User_ID,$Role_ID);
        $this->session->set_flashdata('msg','User role deleted succesfully');
        redirect ('User_Controller/user_role/'.$User_ID);
    }
}
?>
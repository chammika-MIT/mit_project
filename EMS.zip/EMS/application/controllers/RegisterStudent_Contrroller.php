<?php
class RegisterStudent_Contrroller extends CI_Controller{

    public function __construct() {
        parent:: __construct();
        $this->load->model('RegisterStudentModel');
        $this->load->model('UserModel');
    }

    public function registerStudents(){               
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $result['Add_Student']=$this->UserModel->getUserRoleComponentAccess('Add_Student');
        $result['Delete_Student']=$this->UserModel->getUserRoleComponentAccess('Delete_Student');
        //print_r($result['Delete_Student']); exit;
        if(!empty($result['Add_Student'])){
            $result['data']=$this->RegisterStudentModel->displaystudents();
        }
        else{
            $user_data = $this->session->get_userdata(); 
            $institute_id = $user_data['TC_ID'];
            $result['data']=$this->RegisterStudentModel->displaystudentsByInstitute($institute_id);
        }
        $this->load->view('registerStudentView', $result);
	}

    public function add_Students(){
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $result['Add_Student']=$this->UserModel->getUserRoleComponentAccess('Add_Student');
        if(!empty($result['Add_Student'])){
            $result['TC_ID'] = $this->RegisterStudentModel->get_TC_ID();
        }
        else{
            $user_data = $this->session->get_userdata(); 
            $institute_id = $user_data['TC_ID'];
            $result['TC_ID'] = $this->RegisterStudentModel->get_TC_ID_By_Inst($institute_id);
        }
        
        $result['Course_ID'] = $this->RegisterStudentModel->get_Course_ID();
        $this->load->view('add_studentView', $result);
	}
    
	public function reg_student_validation(){
        $this->form_validation->set_rules('Std_NIC','Student NIC','required|is_unique[student_registration.Std_NIC]|min_length[10]|max_length[12]');
        $this->form_validation->set_rules('Name','Student Name','required');
        $this->form_validation->set_rules('Gender','Student Gender','required');
        $this->form_validation->set_rules('Contact_no','Student Contact no','required|is_unique[student_registration.Contact_no]|min_length[10]|max_length[10]');
        $this->form_validation->set_rules('Email','Student Email','required|is_unique[student_registration.Email]');
        $this->form_validation->set_rules('Course_ID','Student Course','required');
        $this->form_validation->set_rules('TC_ID','Student Training Center','required');
        $this->form_validation->set_rules('Std_status','Student Status','required');

        $result['TC_ID'] = $this->RegisterStudentModel->get_TC_ID();
        $result['Course_ID'] = $this->RegisterStudentModel->get_Course_ID();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');

        if($this->form_validation->run()==FALSE){
           $this->load->view('add_studentView', $result); 
           
        }
        else{
            
            $this->load->model('RegisterStudentModel');
            $result = $this->RegisterStudentModel->insert_student_data();
            $response = $this->RegisterStudentModel->insert_student_course($result);
            if ($response){

                $this->session->set_flashdata('msg','Registration Completed');
                redirect ('RegisterStudent_Contrroller/add_Students');
            }

        }
    }
    
    function deletestudent($STD_ID){
      //  $this->load->model('RegisterStudentModel');
      
        $this->RegisterStudentModel->delete_student($STD_ID);
        redirect ("RegisterStudent_Contrroller/registerStudents");       
    }

    function updatestudent($STD_ID){
        //$this->load->model('RegisterStudentModel');
        $result['data']=$this->RegisterStudentModel->displayStudentBySTD_IS($STD_ID);
       // $result['data']=$this->RegisterStudentModel->displaystudentbyid($STD_ID);
        $result['course']=$this->RegisterStudentModel->displaystudentcoursebyid($STD_ID);
        $result['Course_ID'] = $this->RegisterStudentModel->get_Course_ID();
        $result['Add_Student']=$this->UserModel->getUserRoleComponentAccess('Add_Student');
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        
        $this->load->view('updateStudentView',$result);

            if($this->input->post('Update')){
                if(!empty($result['Add_Student'])){
                    // $Std_NIC=$this->input->post('Std_NIC');
                    $Name=$this->input->post('Name');
                    $Gender=$this->input->post('Gender');
                    $Contact_no=$this->input->post('Contact_no');
                    $Email=$this->input->post('Email');
                    // $TC_ID=$this->input->post('Reg_No');
                    $Active=$this->input->post('Std_status');
                    $Course_code=$this->input->post('Course_code');
                    
                    $this->RegisterStudentModel->update_student($STD_ID, $Name, $Gender, $Contact_no, $Email, $Active,$Course_code);
                }else{
                    $Std_NIC=$this->input->post('Std_NIC');
                    $Name=$this->input->post('Name');
                    $Gender=$this->input->post('Gender');
                    $Contact_no=$this->input->post('Contact_no');
                    $Email=$this->input->post('Email');
                    $TC_ID=$this->input->post('Reg_No');
                    $Active=$this->input->post('Std_status');
                    $Course_code=$this->input->post('Course_code');
                    
                    $this->RegisterStudentModel->updateStudentByAdmin($STD_ID,$Std_NIC, $Name, $Gender, $Contact_no, $Email, $TC_ID, $Active,$Course_code);
                }
              
                redirect ("RegisterStudent_Contrroller/registerStudents");
            }
    }
    
}
?>
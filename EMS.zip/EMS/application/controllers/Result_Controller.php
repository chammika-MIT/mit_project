<?php
class Result_Controller extends CI_Controller{

    public function __construct() {
        parent:: __construct();
        $this->load->model('ResultModel');  
        $this->load->model('Exam_manage_Model');  
        $this->load->model('CreateExamModel');  
        $this->load->model('UserModel');
    }

    public function resultView(){
        $result['data']=$this->CreateExamModel->displayexam();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $this->load->view('resultView', $result);
	}

    public function selectCenter($Exam_ID){
        $result['Exam_ID']=$Exam_ID;
        $result['center']=$this->Exam_manage_Model->displaytrainingcenter();
        $result['course']=$this->Exam_manage_Model->displaytrainingcourse();
        $result['module']=$this->Exam_manage_Model->displaytrainingmodule();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $this->load->view('selectResultCenter', $result);

	}

    public function add_student_result($Exam_ID){
            
        $this->form_validation->set_rules('Training_center','Training Center','required');
        $this->form_validation->set_rules('Course','Course','required');
        $this->form_validation->set_rules('Module','Module','required');
        
        $result['center']=$this->Exam_manage_Model->displaytrainingcenter();
        $result['course']=$this->Exam_manage_Model->displaytrainingcourse();
        $result['module']=$this->Exam_manage_Model->displaytrainingmodule();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $result['Exam_ID']=$Exam_ID;

        if($this->form_validation->run()==FALSE){
           $this->load->view('selectResultCenter', $result); 
        }
        else{
            $training=$this->input->post();
            $trainingcenter=$training['Training_center'];
            $trainingcourse=$training['Course'];
            $trainingmodule=$training['Module'];

            $result['Course_ID']=$trainingcourse;
            $result['TC_ID']=$trainingcenter;
            $result['Module_ID']=$trainingmodule;

            $result['data']=$this->ResultModel->displayExamResultModule($trainingcenter,$trainingcourse,$trainingmodule,$Exam_ID);
            
            $this->load->view('addResultView',$result);   
        }
    }

     public function update_student_result(){
        //print_r($this->input->post()); exit();
        $ExamID=($this->uri->segment(3));
        $courseID=($this->uri->segment(4)); 
        $centerID=($this->uri->segment(5));  
        $moduleID=($this->uri->segment(6));  
        //$row->STD_ID.'-'.$row->Module_ID.'-'.$row->ST_EX_CO_ID.'-'.$row->ST_EX_MO_ID;
        if ($this->input->post()!=FALSE){
            $result=$this->input->post();

            $response=$this->ResultModel->insert_student_result($result,$ExamID,$courseID,$centerID,$moduleID);
            //redirect ("Exam_Manage_Controller/select_center/{$ExamID}");
            if ($response){                       
                $this->session->set_flashdata('msg','Student Attendance added Succesfully');
                redirect ("Result_Controller/selectCenter/{$ExamID}");
            }
         }
        else{
             print_r("No Data");
        } 
    }
    // Set Minimum marks
    public function displaymarks(){
        $result['course']=$this->ResultModel->displaytrainingcourse();
        $result['marks']=$this->ResultModel->displaytrainingmodule();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
      //  $result['Exam_ID']=$Exam_ID;
        
        $this->load->view('listModuleMarksView', $result);
	}
    public function dispaymodulemarks(){
        
        $this->form_validation->set_rules('Course','Course','required');
       
        if($this->form_validation->run()==FALSE){
            $result['course']=$this->ResultModel->displaytrainingcourse();
            $result['marks']=$this->ResultModel->displaytrainingmodule();
          //  $result['Exam_ID']=$Exam_ID;
            $this->load->view('listModuleMarksView', $result);
        }else{
            $training=$this->input->post();
            $trainingcourse=$training['Course'];
          //  $result['Exam_ID']=$Exam_ID;

            $result['course']=$this->ResultModel->displaytrainingcourse();
            //$result['module']=$this->ResultModel->displaytrainingmodule($trainingcourse);
            $result['marks']=$this->ResultModel->displaytrainingmodulemarks($trainingcourse);

            $this->load->view('listModuleMarksView', $result);

        }
    }
    function addMinimumPassMark(){
        $result['course']=$this->ResultModel->displaytrainingcourse();
        $result['coursebymoduleid']=$this->ResultModel->displaymodulebycourseid();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
       
        $this->load->view('addPassMarkModuleView', $result);
    }
    function PassMarkvalidation(){

        $this->form_validation->set_rules('Course','Select Course','required');
        $this->form_validation->set_rules('Module','Select Module','required');
        $this->form_validation->set_rules('MinimumPassMark','Minimum Pass Mark','required|greater_than[0]|less_than[100]');

        if($this->form_validation->run()==FALSE){
            $result['coursebymoduleid']=$this->ResultModel->displaymodulebycourseid();
       
            $this->load->view('addPassMarkModuleView', $result);

        }else{

            $response = $this->ResultModel->insert_module_marks();
            
            if ($response){

                $this->session->set_flashdata('msg','Add marks');
                redirect ('Result_Controller/addMinimumPassMark');
            }
        }
        
    }
    Public function loadModulePassMark($MO_PASS_MAR_ID){

        $result['data']=$this->ResultModel->modulePassMark($MO_PASS_MAR_ID);
         //print_r($result); exit;
        $result['course']=$this->ResultModel->displaytrainingcourse();
       
        $result['coursebymoduleid']=$this->ResultModel->displaymodule();

        $this->load->view('updateModulePassMarkView',$result);

        if($this->input->post('Update')){

            $this->form_validation->set_rules('MinimumPassMark','Minimum Pass Mark','required|greater_than[0]|less_than[100]');
            
            if($this->form_validation->run()==FALSE){
                
                $result['data']=$this->ResultModel->modulePassMark($MO_PASS_MAR_ID);
               // $result['course']=$this->ResultModel->displaytrainingcourse();
               // $result['coursebymoduleid']=$this->ResultModel->displaymodule();
                
                $this->load->view('updateModulePassMarkView',$result);
            }else{
                $ModuleMark=$this->input->post('MinimumPassMark');

                $this->ResultModel->updatemodulePassMark($MO_PASS_MAR_ID,$ModuleMark);
                //redirect ($this->agent->referrer());
                $result['course']=$this->ResultModel->displaytrainingcourse();
                $result['marks']=$this->ResultModel->displaytrainingmodule();
                $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
                $this->load->view('listModuleMarksView', $result);
            }   
        }
    }

    // disciplinary actions for students

    public function viewdisciplinary(){
        $result['course']=$this->ResultModel->displaytrainingcourse();
        $result['disciplinary']=$this->ResultModel->viewdisciplinary();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $this->load->view('listdisciplinaryView',$result);
    }
    public function addDisciplinary(){

        $this->form_validation->set_rules('std_NIC','Student NIC','required|min_length[10]|max_length[12]');
        $this->form_validation->set_rules('std_Course','Course','required');
        $this->form_validation->set_rules('MC_Semester','MC_Semester','required');

        if($this->form_validation->run()==FALSE){
        $result['disciplinary']=$this->ResultModel->viewdisciplinary();
        $result['course']=$this->ResultModel->displaytrainingcourse();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $this->load->view('listdisciplinaryView',$result);

        }else{
            
           
            $std_NIC=$this->input->post('std_NIC');
            $std_Course=$this->input->post('std_Course');
            $MC_Semester=$this->input->post('MC_Semester');
            
            $result['data']=$this->ResultModel->displaystudentbyNIC($std_NIC,$std_Course,$MC_Semester);
            if(!empty($result['data'])){
               
                $this->load->view('addDisciplinaryView',$result);
            }else{
                $this->session->set_flashdata('msg', 'Please check the selected data');

                $result['disciplinary']=$this->ResultModel->viewdisciplinary();
                $result['course']=$this->ResultModel->displaytrainingcourse();
                $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
                $this->load->view('listdisciplinaryView',$result);
            }

            //print_r($result); exit;
            
        }
        
    }
    public function adddisciplinarybystudent(){

        $this->form_validation->set_rules('ST_EX_MO_ID','Module','required');
        $this->form_validation->set_rules('Description','Description','required');
        $this->form_validation->set_rules('Action','Action','required');

        if($this->form_validation->run()==FALSE){

           $this->load->view('addDisciplinaryView');
  
            
         }else{
            $response = $this->ResultModel->insert_disciplinary();
            
            if ($response){

                $this->session->set_flashdata('msg','Record added');
                redirect ('Result_Controller/viewdisciplinary');
            }
         }
    }

   
}
?>

<?php
class Report_Controller extends CI_Controller{

    public function __construct() {
        parent:: __construct();
        $this->load->model('ReportModel');
        $this->load->model('UserModel');
    }

    public function reportView(){
        $result['TRcenter']=$this->ReportModel->displaytrainingCenter();
        $result['Excenter']=$this->ReportModel->displayExamCenter();
        $result['course']=$this->ReportModel->displayCourse();
        $result['module']=$this->ReportModel->displayModule();
        $result['district']=$this->ReportModel->displayDistrict();
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');  

		$this->load->view('reportView', $result);
	}
    public function displaydata(){
        
        if($this->input->post('St_Sign')){

            $this->form_validation->set_rules('ExcID','Examination Center','required');
            $this->form_validation->set_rules('Course_ID','Course','required');
            $this->form_validation->set_rules('Moudle_ID','Module','required');

            if($this->form_validation->run()==FALSE){
                $result['TRcenter']=$this->ReportModel->displaytrainingCenter();
                $result['Excenter']=$this->ReportModel->displayExamCenter();
                $result['course']=$this->ReportModel->displayCourse();
                $result['module']=$this->ReportModel->displayModule();
                $result['district']=$this->ReportModel->displayDistrict();
                $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');  

		        $this->load->view('reportView', $result);
            }else{
                $ExcID=$this->input->post('ExcID');
                $Course_ID=$this->input->post('Course_ID');
                $Moudle_ID=$this->input->post('Moudle_ID');
                $result['data']=$this->ReportModel->get_exam_student_by_indexno_course($Course_ID,$ExcID,$Moudle_ID);
                
                //print_r($this->input->post());exit; 
                if(!empty($result['data'])){
                $this->load->helper('pdf_helper');            
                $this->load->view('examStudentCourseIndexNoPDF', $result);
                }else{
                    $this->session->set_flashdata('msg','No data available for selected Course or Module');
                redirect ('Report_Controller/reportView');
                }
            }

        }
        if($this->input->post('STDcountByModule'))
        {
            $this->form_validation->set_rules('Course_ID','Course','required');
            if($this->form_validation->run()==FALSE){
                $result['TRcenter']=$this->ReportModel->displaytrainingCenter();
                $result['Excenter']=$this->ReportModel->displayExamCenter();
                $result['course']=$this->ReportModel->displayCourse();
                $result['module']=$this->ReportModel->displayModule();
                $result['district']=$this->ReportModel->displayDistrict();
                $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');  

		        $this->load->view('reportView', $result);
            }else{
                $Course_ID=$this->input->post('Course_ID');
                $result['data']=$this->ReportModel->get_exam_student_count_per_module($Course_ID);
                $result['course']=$this->ReportModel->displayCoursebyID($Course_ID);
                $result['course']=json_decode(json_encode($result['course']), true);
                if(!empty($result['data'])){
                    $this->load->helper('pdf_helper');            
                    $this->load->view('examStudentCountModulePDF', $result);
                }else{
                    $this->session->set_flashdata('msg','No data available for selected Course');
                redirect ('Report_Controller/reportView');
                }
                
            } 
        }
        if($this->input->post('STDcountBydistrictcourse'))
        {
            $this->form_validation->set_rules('Dt_ID','District','required');
          //  $this->form_validation->set_rules('Course_ID','Course','required');

            if($this->form_validation->run()==FALSE){
                $result['TRcenter']=$this->ReportModel->displaytrainingCenter();
                $result['Excenter']=$this->ReportModel->displayExamCenter();
                $result['course']=$this->ReportModel->displayCourse();
                $result['module']=$this->ReportModel->displayModule();
                $result['district']=$this->ReportModel->displayDistrict();
                $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');  

		        $this->load->view('reportView', $result);
            }else{
           // print_r('Student Count based on the selected district and coused'); exit;
           // $Course_ID=$this->input->post('Course_ID');

            $District_ID=$this->input->post('Dt_ID');
            
            $result['data']=$this->ReportModel->get_student_count_per_course_and_district($District_ID);
            if(!empty($result['data'])){
                $this->load->helper('pdf_helper');            
                $this->load->view('stdCountDistrictandCoursePDF', $result);
            }else{
                $this->session->set_flashdata('msg','No data available for selected district');
                redirect ('Report_Controller/reportView');
            }
            
            
            }
        } 
        if($this->input->post('STDpassRatecourse'))
        {            
            
            $this->form_validation->set_rules('Course_ID','Course','required');

            if($this->form_validation->run()==FALSE){
                $result['TRcenter']=$this->ReportModel->displaytrainingCenter();
                $result['Excenter']=$this->ReportModel->displayExamCenter();
                $result['course']=$this->ReportModel->displayCourse();
                $result['module']=$this->ReportModel->displayModule();
                $result['district']=$this->ReportModel->displayDistrict();
                $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');  
		        $this->load->view('reportView', $result);

            }else{
                $Course_ID=$this->input->post('Course_ID');
                $result['course']=$this->ReportModel->displayCoursebyID($Course_ID);
                $result['data']=$this->ReportModel->studentPassRate($Course_ID);
                $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
                //print_r( $result['course']); exit;
                if (!empty($result['data'])){
                $this->load->helper('pdf_helper');            
                $this->load->view('examStudentPassRatePDF', $result);
            }else{
                $this->session->set_flashdata('msg','No data available for selected Course');
                redirect ('Report_Controller/reportView');
             }
            }  
        } 
        if($this->input->post('STDResults')){

            $this->form_validation->set_rules('TC_ID','Training Center','required');
            $this->form_validation->set_rules('Course_ID','Course','required');
            $this->form_validation->set_rules('Moudle_ID','Module','required');

            if($this->form_validation->run()==FALSE){
                $result['TRcenter']=$this->ReportModel->displaytrainingCenter();
                $result['Excenter']=$this->ReportModel->displayExamCenter();
                $result['course']=$this->ReportModel->displayCourse();
                $result['module']=$this->ReportModel->displayModule();
                $result['district']=$this->ReportModel->displayDistrict();
                $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');  

		        $this->load->view('reportView', $result);
            }else{
                $TC_ID=$this->input->post('TC_ID');
                $Course_ID=$this->input->post('Course_ID');
                $Moudle_ID=$this->input->post('Moudle_ID');

                $result['data']=$this->ReportModel->studentResultcentercourse($TC_ID,$Course_ID,$Moudle_ID);
                if (!empty($result['data'])){
                $this->load->helper('pdf_helper');            
                $this->load->view('examResultCourseModuleCenterPDF', $result);
                 }else{
                    $this->session->set_flashdata('msg','No data available for selected Course and Module');
                    redirect ('Report_Controller/reportView');
                 }
            }
        }
        //New Modification
        if($this->input->post('STDmoduleCourse')){

            
            $this->form_validation->set_rules('Course_ID','Course','required');
            $this->form_validation->set_rules('Moudle_ID','Module','required');

            if($this->form_validation->run()==FALSE){
                $result['TRcenter']=$this->ReportModel->displaytrainingCenter();
                $result['Excenter']=$this->ReportModel->displayExamCenter();
                $result['course']=$this->ReportModel->displayCourse();
                $result['module']=$this->ReportModel->displayModule();
                $result['district']=$this->ReportModel->displayDistrict();
                $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');  

		        $this->load->view('reportView', $result);
            }else{
              
                $Course_ID=$this->input->post('Course_ID');
                $Moudle_ID=$this->input->post('Moudle_ID');

                $result['data']=$this->ReportModel->modulestudentcount($Course_ID,$Moudle_ID);
                if (!empty($result['data'])){
                $this->load->helper('pdf_helper');            
                $this->load->view('studentinModulecountPDF', $result);
                 }else{
                    $this->session->set_flashdata('msg','No data available for selected Course and Module');
                    redirect ('Report_Controller/reportView');
                 }
            }
        }

    }
    function view_reg_student_by_course_district(){
        $result['data']=$this->ReportModel->get_reg_student_by_course_district();
        if (!empty($result['data'])){
        $this->load->helper('pdf_helper');            
        $this->load->view('examStudentCourseDistrictWisePDF', $result);
    }else{
        $this->session->set_flashdata('msg','No data available for selected Course and Module');
        redirect ('Report_Controller/reportView');
     }
    }

    
}
?>

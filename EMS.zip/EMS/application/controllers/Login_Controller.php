<?php
class Login_Controller extends CI_Controller{

    public function __construct() {
        parent:: __construct();

        $this->load->model('LoginManagModel');
        $this->load->model('UserModel');
    }

	public function log_in(){
		$this->load->view('login_view');

	}
    public function dashboard(){
		

		$result['genderdata']=$this->LoginManagModel->stGenderchartdata();
		$result['tcdistrict']=$this->LoginManagModel->TCchartdata();
		$result['stcourse']=$this->LoginManagModel->stCoursechartdata();
        $result['STD_District']=$this->LoginManagModel->distrcitStudentchart();
       $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
		$this->load->view('dashboardView',$result);
	}

    public function userLogin(){
        //Load unit test library in the Codeigniter
        //$this->load->library('unit_test');
       //$result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $this->form_validation->set_rules('Username','Username','required');
        $this->form_validation->set_rules('Password','Password','required');
    
     if($this->form_validation->run()==FALSE){

            $this->load->view('login_view');
        }
        else{
            
            //Set the parameters to the unit test
           /*
            $expected_result=true;
            $test_name='Login function testing';
            $note='Unit test using CodeIgniter unit_test library';
            */
            
            $result=$this->LoginManagModel->Login();

            //Run the unit test and print the result
            /*
            echo "<b>CodeIgniter: Unit Testing Class</b>";
            $this->unit->run($result,$expected_result,$test_name,$note);
            echo $this->unit->report();
            die();
            */
            if($result != false){

                $admin_data=array(

                    'User_ID '=>$result->User_ID ,
                    'TC_ID'=>$result->TC_ID,
                    'STF_ID'=>$result->STF_ID,
					'Username'=>$result->Username,
					'Password'=>$result->Password,
					'Availability'=>$result->Availability,
                    'loggedin'=>TRUE
                );
                $this->session->set_userdata($admin_data);
                $this->session->set_flashdata('welcome','Welcome to the Admin panel');
                redirect ('Login_Controller/dashboard');
               
            }else{
                $this->session->set_flashdata('error_msg','Username or Password incorrect');
                redirect ('Login_Controller/log_in');
            }
         }
    }

    public function LogoutUser(){
        $this->session->unset_userdata('User_ID');
        $this->session->unset_userdata('TC_ID');
        $this->session->unset_userdata('STF_ID');
        $this->session->unset_userdata('Username');
		$this->session->unset_userdata('Password');
		$this->session->unset_userdata('Availability');
		$this->session->unset_userdata('loggedin');
        redirect ('Home');
    }
    
    public function resetPassword(){
		$this->load->view('resetPasswordView');

	}
    public function Do_resetPassword(){

        $this->form_validation->set_rules('Username','Username','trim|required');
        $this->form_validation->set_rules('CurrentPassword','Current Password','trim|required');
        $this->form_validation->set_rules('NewPassword','New Password','trim|required|min_length[5]');
        $this->form_validation->set_rules('RePassword','Password Confirmation','trim|required|matches[NewPassword]');
       
        if ($this->form_validation->run() == FALSE)
        {
                $this->load->view('resetPasswordView');
        }
        else
        {
            $result=$this->LoginManagModel->resetPassword();

            if($result != false){
                $this->session->set_flashdata('msg','Password changed successfully !');
                $this->load->view('resetPasswordView');
            }else{
                $this->session->set_flashdata('msg','Password not changed');
            }
        }
		//$this->load->view('resetPasswordView');

	}
}
?>
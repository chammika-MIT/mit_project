<?php
class CreateExamController extends CI_Controller{

    public function __construct() {
        parent:: __construct();
        $this->load->model('CreateExamModel');
        $this->load->model('UserModel');
    }

    public function createExam(){
        $result['Add_Exam']=$this->UserModel->getUserRoleComponentAccess('Add_Exam');
        $result['Add_Center']=$this->UserModel->getUserRoleComponentAccess('Add_Center');
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $result['data']=$this->CreateExamModel->displayexam();
        $this->load->view('createExamView', $result);
	}

    public function add_Exam(){
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
		$this->load->view('addExamView',$result);
	}

	public function create_exam_validation(){
        $this->form_validation->set_rules('level','level','required');
        $this->form_validation->set_rules('semester','semester','required');
        $this->form_validation->set_rules('AppOpenDate','AppOpenDate','required');
        $this->form_validation->set_rules('AppCloseDate','AppCloseDate','required');
        $this->form_validation->set_rules('ExamStartDate','ExamStartDate','required');
        $this->form_validation->set_rules('ExamEndDate','ExamEndDate','required');

        if($this->form_validation->run()==FALSE){
           $this->load->view('addExamView'); 
        }
        else{
            
            $this->load->model('CreateExamModel');
            $response = $this->CreateExamModel->insert_exam_data();
            if ($response){

                $this->session->set_flashdata('msg','Registration Completed');
                redirect ('CreateExamController/add_Exam');
            }
        }
    }

    function deletExam($Exam_ID){
        $this->load->model('CreateExamModel');

        $this->CreateExamModel-> delete_exam($Exam_ID);
        redirect ("CreateExamController/createExam");
    }
    
    function updateExam($Exam_ID){
        $this->load->model('CreateExamModel');
        $result['data']=$this->CreateExamModel->displayexambyid($Exam_ID);
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course');
        $this->load->view('updateExamView',$result);

            if($this->input->post('Update')){
                $Level=$this->input->post('level');
                $Semester=$this->input->post('semester');
                $Year=$this->input->post('year');
                $Application_start_date=$this->input->post('AppOpenDate');
                $Application_end_date=$this->input->post('AppCloseDate');
                $Exam_start_date=$this->input->post('ExamStartDate');
                $Exam_end_date=$this->input->post('ExamEndDate');
                
                $this->CreateExamModel->update_exam($Exam_ID,$Level, $Semester, $Year, $Application_start_date, $Application_end_date, $Exam_start_date, $Exam_end_date);
                redirect ("CreateExamController/createExam");
            }
    }
}
?>
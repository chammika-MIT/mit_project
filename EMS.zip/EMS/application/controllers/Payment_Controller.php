<?php
class Payment_Controller extends CI_Controller{

    public function __construct() {
        parent:: __construct();
        $this->load->model('Exam_manage_Model');  
        $this->load->model('Payment_Model'); 
        $this->load->model('UserModel');  
    }

    public function view_exam_conduct($Exam_ID){    
        //print_r($EX_SCH_ID); exit();
        $this->form_validation->set_rules('Staff','Staff','required');
        $this->form_validation->set_rules('StaffType','Staff Type','required');
        $this->form_validation->set_rules('ExamCenter','Exam Center','required');        
        $this->form_validation->set_rules('Course','Course','required');
        $this->form_validation->set_rules('Module','Module','required');
        //$this->form_validation->set_rules('PaperMarked','Paper Marked','required');
        //$this->form_validation->set_rules('SecondPaperMarked','Second Paper Marked','required');
        //$this->form_validation->set_rules('RecorrectionPaperMarked','Recorrection Paper Marked','required');

        
        $result['staff']=$this->Payment_Model->getStaff();        
        $result['stafftype']=$this->Payment_Model->getStaffType();
        $result['examcenter']=$this->Exam_manage_Model->displayexamcenter();
        $result['course']=$this->Exam_manage_Model->displaytrainingcourse();
        $result['module']=$this->Exam_manage_Model->displaytrainingmodule();   
        $result['examConduct']=$this->Payment_Model->getStaffConductExamByExamId($Exam_ID);   
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course'); 
        $result['Exam_ID']=$Exam_ID;

        if($this->form_validation->run()==FALSE){            
            $result['staff_id']=$this->input->post('Staff');
            $result['staffType_id']=$this->input->post('StaffType');
            $result['examCenter_id']=$this->input->post('ExamCenter');
            $result['course_id']=$this->input->post('Course');
            $result['module_id']=$this->input->post('Module');
            $result['PaperMarked']=$this->input->post('PaperMarked');            
            $result['SecondPaperMarked']=$this->input->post('SecondPaperMarked');
            $result['RecorrectionPaperMarked']=$this->input->post('RecorrectionPaperMarked');
            //print_r($result); exit();
           $this->load->view('examConductView', $result); 
        }
        else{
            //$this->form_validation->set_rules('PaperMarked', 'Paper Marked should be numeric', 'required|regex_match[/^[0-9]{10}$/]');
            //$this->form_validation->set_rules('SecondPaperMarked', 'Second Paper Marked should be numeric', 'required|regex_match[/^[0-9]{10}$/]');
            //$this->form_validation->set_rules('RecorrectionPaperMarked', 'Recorrection Paper Marked should be numeric', 'required|regex_match[/^[0-9]{10}$/]');
           
            if($this->form_validation->run()!=FALSE){
                $result['data']=$this->Payment_Model->insert_staff_conduct($Exam_ID);
                $result['examConduct']=$this->Payment_Model->getStaffConductExamByExamId($Exam_ID);
                $result['staff_id']='';
                $result['staffType_id']='';
                $result['examCenter_id']='';
                $result['course_id']='';
                $result['module_id']='';
                $result['PaperMarked']=0;
                $result['SecondPaperMarked']=0;
                $result['RecorrectionPaperMarked']=0;
                $this->load->view('examConductView',$result);   
            }  
            else{
                $result['course_id']=$this->input->post('Course');
                $result['module_id']=$this->input->post('Module');
                $result['Start_Time']=$this->input->post('Start_Time');
                $result['End_Time']=$this->input->post('End_Time');
                $this->load->view('examConductView',$result);   
            }                
        }       
    }


    function update_exam_conduct($STF_CON_EXM_ID){     
        
        //$ExamID=($this->uri->segment(3));
        $this->form_validation->set_rules('Staff','Staff','required');
        $this->form_validation->set_rules('StaffType','Staff Type','required');
        $this->form_validation->set_rules('ExamCenter','Exam Center','required');        
        $this->form_validation->set_rules('Course','Course','required');
        $this->form_validation->set_rules('Module','Module','required');
        //$this->form_validation->set_rules('PaperMarked','Paper Marked','required');
        //$this->form_validation->set_rules('SecondPaperMarked','Second Paper Marked','required');
        //$this->form_validation->set_rules('RecorrectionPaperMarked','Recorrection Paper Marked','required');
       
       
        $result['staff']=$this->Payment_Model->getStaff();
        $result['stafftype']=$this->Payment_Model->getStaffType();
        $result['examcenter']=$this->Exam_manage_Model->displayexamcenter();
        $result['course']=$this->Exam_manage_Model->displaytrainingcourse();
        $result['module']=$this->Exam_manage_Model->displaytrainingmodule();  
        $result['Add_Course']=$this->UserModel->getUserRoleComponentAccess('Add_Course'); 
        //$result['examConduct']=$this->PaymentModel->getStaffConductExamByExamId(); 
        $result['examConduct']=$this->Payment_Model->getStaffConductExamById($STF_CON_EXM_ID);
        //$result['Exam_ID']=$Exam_ID;
        //$data = json_decode(json_encode($result['schedule']), true);
        $result['examConduct']=json_decode(json_encode($result['examConduct']), true);
        //print_r($result['examConduct']); exit();
        foreach ($result['examConduct'] as $row) {
            //print_r($row); exit();
            //echo $object->object_property;
            $result['staff_id']=$row['STF_ID'];
            $result['staffType_id']=$row['STF_TY_ID'];
            $result['examCenter_id']=$row['EXC_ID'];
            $result['course_id']=$row['Course_ID'];
            $result['module_id']=$row['Module_ID'];
            $result['PaperMarked']=$row['No_paper_marked'];            
            $result['SecondPaperMarked']=$row['No_second_marked'];
            $result['RecorrectionPaperMarked']=$row['No_recorrection_marked'];
            $result['Exam_ID']=$row['Exam_ID'];         
            //print_r($result); exit();
        }
        //$this->load->view('updateExamConductView',$result);   
        //print_r($result); exit();
        if($this->form_validation->run()==FALSE){           
            
           $this->load->view('updateExamConductView', $result); 
        }
        else{           
            if($this->form_validation->run()!=FALSE){  
                
                $Exam_ID=$result['Exam_ID'];
                $this->Payment_Model->update_staff_conduct($STF_CON_EXM_ID,$Exam_ID);                
                redirect ("Payment_Controller/view_exam_conduct/$Exam_ID");
            }  
            foreach ($result['examConduct'] as $row) {
                //print_r($row); exit();
                //echo $object->object_property;
                $result['staff_id']=$row['STF_ID'];
                $result['staffType_id']=$row['STF_TY_ID'];
                $result['examCenter_id']=$row['EXC_ID'];
                $result['course_id']=$row['Course_ID'];
                $result['module_id']=$row['Module_ID'];
                $result['PaperMarked']=$row['No_paper_marked'];            
                $result['SecondPaperMarked']=$row['No_second_marked'];
                $result['RecorrectionPaperMarked']=$row['No_recorrection_marked'];
                $result['Exam_ID']=$row['Exam_ID'];         
                //print_r($result['schedule']); exit();
            }
            
        }   
    }

    function delete_exam_conduct($STF_CON_EXM_ID,$Exam_ID){
        $this->Payment_Model->delete_exam_conduct($STF_CON_EXM_ID);
        redirect ("Payment_Controller/view_exam_conduct/$Exam_ID");
   }   

}

?>